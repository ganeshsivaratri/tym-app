# TYM — Track Your Mind (React)

A to-do app that is also a planner: tasks with reminders and alarms,
habits, a focus timer, and study tools. Built with React + Vite,
wrapped into an Android app with Capacitor.

## Run it

```
npm install     # once
npm run dev     # website on your computer
npm run build   # final files in dist/
npm test        # logic tests (28 groups)
```

## Where is what — the file map

```
src/
  main.jsx               start point — puts the app on the page
  App.jsx                the shell: sidebar, bottom bar, alarm, theme
  App.css                shell-only styles
  theme.css              the design system (colours, cards, buttons)

  store/
    AppStore.jsx         ALL data lives here + every action
    storage.js           save / load / snapshots / backup text
    defaultData.js       starter lists, routines, habit ideas

  utils/                 pure logic — no screen code, easy to test
    dates.js             dates and repeat maths
    taskLogic.js         create / edit / done / sort / search tasks
    textParse.js         turns "call mom tomorrow 9am" into a task
    reminderLogic.js     when each reminder should ring
    planLogic.js         Plan My Day + "what can I do in X min"
    progressLogic.js     streaks, week summary, XP and levels
    calendarFile.js      builds the .ics calendar export file
    markdown.js          small Markdown renderer for notes
    escapeHtml.js        makes text safe to show

  components/            shared pieces (LEGO blocks)
    TaskCard.jsx         one task as a card
    TaskEditor.jsx       the add / edit task pop-up
    CommandPalette.jsx   Ctrl+K quick jumper
    AlarmOverlay.jsx     full-screen ringing alarm
    Toast.jsx            the small bottom message bar

  services/              talks to the outside world
    notifications.js     phone notifications + browser alarm sound
    voice.js             speak-a-task (phone engine or browser)
    saveFile.js          gives the user a file (share sheet in the app)
    firebaseConfig.js    the Firebase project address (not a secret)
    auth.js              login: email + password, or Google
    cloudSync.js         cloud backup/sync for a signed-in user

  screens/               one folder per screen, always 3 files:
    Today/    Today.jsx (look) · todayLogic.js (brain) · today.css
    ...       15 screens, all the same shape
    Login/               the login screen (email / Google / guest)
    Onboarding/          the 3 first-run welcome slides
    screenList.js        the list of screens (sidebar + bottom bar read it)
```

## The rules of this codebase

1. Data lives in ONE place — the store. Screens ask, never copy.
2. One file, one job. The file name says the job.
3. Every file starts with a comment: what it does.
4. Logic files (utils + *Logic.js) never draw anything,
   so they can be tested without a screen. `npm test` proves them.
5. Look = Screen.jsx · Brain = logic.js · Dress = styles.css.

## Data

All data is one JSON object, saved on the device after every
change (key `tym-state-v1` — same format as TYM v2, so old
backups import cleanly). When the user signs in (Firebase —
project `tym-track-your-mind`), the same JSON is also kept in
Firestore as users/{userId}: the newer copy wins on sign-in,
changes push up after a short pause. Firestore rules let each
user touch only their own document.
