package app.tym.trackyourmind;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
