'use strict';
/* ============================================================
   TYM — Track Your Mind · completed.js
   What this file does: the COMPLETED screen — every task
   marked done, newest first. From here a task can be
   reopened (untick it), deleted forever, or all cleared.
   ============================================================ */

function render() {
  const box = document.getElementById('screenContent');
  const done = state.tasks
    .filter(t => t.status === 'done')
    .sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0));

  if (!done.length) {
    box.innerHTML = '<div class="card empty"><div class="empty-art">✅</div>' +
      '<p>Nothing completed yet. Your finished tasks will collect here.</p></div>';
    return;
  }
  box.innerHTML =
    '<div style="margin-bottom:12px"><button class="btn" id="clearAllBtn">' +
    '🧹 Clear all completed (' + done.length + ')</button></div>' +
    '<div class="stagger">' +
    done.map(t => taskCardHTML(state, t, { compact: true })).join('') + '</div>';

  document.getElementById('clearAllBtn').addEventListener('click', () => {
    const removedAll = state.tasks.filter(t => t.status === 'done');
    state.tasks = state.tasks.filter(t => t.status !== 'done');
    saveState(state);
    render();
    showToast('Cleared ' + removedAll.length + ' completed tasks', 'Undo', () => {
      removedAll.forEach(t => restoreTask(state, t));
      saveState(state);
      render();
    });
  });
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', render);
