'use strict';
/* ============================================================
   TYM — Track Your Mind · review.js
   What this file does: the REVIEW screen — proof of work.
   - This week's completions as bars
   - A GitHub-style year heatmap of completed tasks
   - Focus minutes (from the Focus screen's log)
   - Habit consistency for the last 4 weeks
   All numbers come from real state — nothing is decorative.
   ============================================================ */

function render() {
  const box = document.getElementById('screenContent');
  const now = new Date();
  const stats = dayStats(state, now);
  const week = weekSummary(state.completions, now);
  const weekTotal = week.reduce((a, d) => a + d.count, 0);
  const maxWeek = Math.max(1, ...week.map(d => d.count));
  const focusTotal = state.focusLog.reduce((a, s) => a + s.minutes, 0);
  const focusWeek = state.focusLog
    .filter(s => lastNDays(7, now).includes(s.date))
    .reduce((a, s) => a + s.minutes, 0);

  // Week bars (plain divs — height = the day's count).
  const bars = week.map(d => {
    const dayName = new Date(...d.date.split('-').map((v, i) => i === 1 ? v - 1 : v))
      .toLocaleDateString(undefined, { weekday: 'narrow' });
    return '<div class="bar-col"><div class="bar" style="height:' +
      Math.max(4, Math.round(d.count / maxWeek * 100)) + '%" title="' + d.date + ': ' + d.count + '"></div>' +
      '<span>' + dayName + '</span><b>' + d.count + '</b></div>';
  }).join('');

  // Year heatmap: last 364 days + up to today, in week columns.
  const days = lastNDays(364, now);
  const maxCount = Math.max(1, ...days.map(d => state.completions[d] || 0));
  const cells = days.map(d => {
    const c = state.completions[d] || 0;
    const level = c === 0 ? 0 : Math.min(4, Math.ceil(c / maxCount * 4));
    return '<span class="heat heat-' + level + '" title="' + d + ': ' + c + ' done"></span>';
  }).join('');

  // Habit consistency: per habit, dots for the last 28 days.
  const last28 = lastNDays(28, now);
  const habitRows = state.habits.map(h => {
    const log = state.habitLog[h.id] || {};
    const doneCount = last28.filter(d => log[d]).length;
    return '<div class="habit-review"><span class="habit-review-name">' + escapeHTML(h.name) +
      ' · ' + doneCount + '/28</span><span class="habit-dots">' +
      last28.map(d => '<span class="habit-dot' + (log[d] ? ' on' : '') + '" title="' + d + '"></span>').join('') +
      '</span></div>';
  }).join('');

  const xp = totalXP(state);
  const lvl = levelFor(xp);
  box.innerHTML =
    '<div class="card xp-card" style="margin-bottom:14px"><div class="ring-wrap" style="background:none;border:0;box-shadow:none;padding:0;color:inherit">' +
      '<div><div class="ring-num">' + lvl.current.name + '</div>' +
      '<div style="color:var(--muted)">' + xp + ' XP' +
      (lvl.next ? ' · ' + (lvl.next.xp - xp) + ' XP to ' + lvl.next.name : ' · top level!') + '</div></div></div>' +
      '<div class="progress" style="margin-top:10px"><div style="width:' + lvl.pctToNext + '%"></div></div></div>' +
    '<div class="stat-grid" style="grid-template-columns:repeat(4,1fr)">' +
      '<div class="stat"><b>' + stats.totalDone + '</b><span>tasks done (all time)</span></div>' +
      '<div class="stat"><b>' + weekTotal + '</b><span>done this week</span></div>' +
      '<div class="stat"><b>' + longestStreak(state.completions) + ' 🔥</b><span>longest streak</span></div>' +
      '<div class="stat"><b>' + focusTotal + 'm</b><span>focus time (' + focusWeek + 'm this week)</span></div>' +
    '</div>' +
    '<div class="card" style="margin-top:14px"><h2>This week</h2>' +
      '<div class="bars">' + bars + '</div></div>' +
    '<div class="card" style="margin-top:14px"><h2>Your year of showing up</h2>' +
      '<div class="heat-wrap">' + cells + '</div>' +
      '<p style="color:var(--muted);font-size:12px;margin:8px 0 0">Each square is a day. Darker = more tasks finished.</p></div>' +
    (habitRows
      ? '<div class="card" style="margin-top:14px"><h2>Habits — last 28 days</h2>' + habitRows + '</div>'
      : '');
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', render);
