'use strict';
/* ============================================================
   TYM — Track Your Mind · matrix.js
   What this file does: the MATRIX screen — Eisenhower's
   urgent × important grid.
   Urgent = overdue, or due within 2 days.
   Important = high priority.
   Drag a card to another box to change it: moving into
   "important" sets high priority; into "urgent" pulls the
   due date to today; out of "urgent" pushes it a week out.
   ============================================================ */

function isUrgent(t, now) {
  if (!t.due) return false;
  return daysBetween(todayStr(now), t.due) <= 2;
}

const QUADS = [
  { id: 'do', name: 'Do first', icon: '🔥', urgent: true, important: true },
  { id: 'plan', name: 'Plan', icon: '🗓️', urgent: false, important: true },
  { id: 'quick', name: 'Quick / delegate', icon: '⚡', urgent: true, important: false },
  { id: 'later', name: 'Later', icon: '🧊', urgent: false, important: false }
];

function quadOf(t, now) {
  const u = isUrgent(t, now), i = t.priority === 'high';
  return QUADS.find(q => q.urgent === u && q.important === i).id;
}

function matrixCardHTML(t) {
  return '<div class="board-card" draggable="true" data-mcard="' + t.id + '">' +
    '<div class="board-card-title">' + escapeHTML(t.title) + '</div>' +
    '<div class="task-meta">' +
      (t.due ? '<span class="pill">' + dueLabel(t.due) + '</span>' : '<span class="pill">no date</span>') +
      '<button class="icon-btn" data-edit="' + t.id + '">✏️</button>' +
    '</div></div>';
}

function render() {
  const box = document.getElementById('screenContent');
  const now = new Date();
  const open = state.tasks.filter(t => t.status !== 'done');
  box.innerHTML =
    '<p style="color:var(--muted);margin-top:0">Drag a card to another box — its priority and due date change to match.</p>' +
    '<div class="matrix stagger">' + QUADS.map(q => {
      const tasks = open.filter(t => quadOf(t, now) === q.id);
      return '<div class="matrix-cell" data-quad="' + q.id + '">' +
        '<h3>' + q.icon + ' ' + q.name + ' <span class="badge">' + tasks.length + '</span></h3>' +
        (tasks.map(matrixCardHTML).join('') || '<p class="board-empty">—</p>') +
        '</div>';
    }).join('') + '</div>';

  box.querySelectorAll('[data-mcard]').forEach(card => {
    card.addEventListener('dragstart', e =>
      e.dataTransfer.setData('text/tym-task', card.dataset.mcard));
  });
  box.querySelectorAll('[data-quad]').forEach(cell => {
    cell.addEventListener('dragover', e => e.preventDefault());
    cell.addEventListener('drop', e => {
      e.preventDefault();
      const id = e.dataTransfer.getData('text/tym-task');
      const t = findTask(state, id);
      if (!t) return;
      const q = QUADS.find(x => x.id === cell.dataset.quad);
      const today = todayStr();
      t.priority = q.important ? 'high' : (t.priority === 'high' ? 'med' : t.priority);
      if (q.urgent && (!t.due || t.due > addDaysStr(today, 2))) t.due = today;
      if (!q.urgent && t.due && t.due <= addDaysStr(today, 2)) t.due = addDaysStr(today, 7);
      saveState(state);
      render();
    });
  });
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', render);
