'use strict';
/* ============================================================
   TYM — Track Your Mind · today.js
   What this file does: the TODAY screen — greeting, My Day
   Top-3 focus banner, day progress ring, quick add, and
   today's + overdue task lists.
   Data comes from tasks.js (tasksForToday, dayStats).
   Card clicks (tick, edit, delete, pin) are handled in
   editor.js — this file only draws and quick-adds.
   ============================================================ */

/* The progress ring: an SVG circle that fills to pct%. */
function ringHTML(pct) {
  const r = 34, c = 2 * Math.PI * r;
  const off = c - (pct / 100) * c;
  return '<svg class="ring" width="84" height="84" viewBox="0 0 84 84">' +
    '<defs><linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">' +
    '<stop offset="0%" stop-color="#f6b73c"/><stop offset="100%" stop-color="#f59e0b"/>' +
    '</linearGradient></defs>' +
    '<circle class="ring-bg" cx="42" cy="42" r="' + r + '" fill="none" stroke-width="8"/>' +
    '<circle class="ring-fg" cx="42" cy="42" r="' + r + '" fill="none" stroke-width="8" ' +
    'stroke-dasharray="' + c + '" stroke-dashoffset="' + off + '"/></svg>';
}

function render() {
  const now = new Date();
  const groups = tasksForToday(state, now);
  const stats = dayStats(state, now);
  const box = document.getElementById('screenContent');

  // Greeting line at the top of the screen.
  document.getElementById('greetingLine').textContent =
    greetingText(now) + ' · ' + now.toLocaleDateString(undefined,
      { weekday: 'long', day: 'numeric', month: 'long' });

  // The focus banner: Top-3 pins, or a hint to pin.
  const focusHTML = groups.focus.length
    ? groups.focus.map(t =>
        '<div class="fb-task">📌 ' + escapeHTML(t.title) + '</div>').join('')
    : '<div class="fb-task">Pin up to 3 tasks with 📍 to plan your day.</div>';

  let html =
    '<div class="focus-banner stagger"><h2>🎯 My Day — Top 3</h2>' + focusHTML + '</div>' +
    '<div class="card ring-wrap" style="margin-bottom:6px">' + ringHTML(stats.pctToday) +
      '<div><div class="ring-num">' + stats.pctToday + '% of today done</div>' +
      '<div style="color:var(--muted)">' + stats.doneDueToday + ' of ' +
        stats.dueTodayCount + ' tasks due today complete</div>' +
      '<div style="color:var(--muted);margin-top:2px">🔥 ' + stats.streak + ' day streak · ' +
        stats.openCount + ' open tasks</div></div>' +
    '</div>';

  // Overdue first — it needs attention — then today's list.
  if (groups.overdue.length) {
    html += '<div class="section-title">⚠️ Overdue ' +
      '<button class="btn" id="moveOverdueBtn" style="margin-left:8px;padding:5px 12px;font-size:12.5px">📅 Move all to today</button></div>' +
      '<div class="stagger">' + groups.overdue.map(t => taskCardHTML(state, t)).join('') + '</div>';
  }
  html += '<div class="section-title">📅 Today</div>';
  if (groups.today.length) {
    html += '<div class="stagger">' + groups.today.map(t => taskCardHTML(state, t)).join('') + '</div>';
  } else if (!groups.focus.length && !groups.overdue.length) {
    html += '<div class="card empty"><div class="empty-art">🌅</div>' +
      '<p>Nothing due today. Add a task above, or pin a Top 3.</p></div>';
  } else {
    html += '<div class="card empty"><p>Nothing else due today. 🎉</p></div>';
  }
  box.innerHTML = html;

  // "Move all to today": one tap clears the overdue pile.
  const mv = document.getElementById('moveOverdueBtn');
  if (mv) mv.addEventListener('click', () => {
    const now2 = new Date();
    const ods = state.tasks.filter(t => isOverdueTask(t, now2));
    const old = ods.map(t => ({ id: t.id, due: t.due }));
    ods.forEach(t => { t.due = todayStr(now2); });
    saveState(state);
    render();
    showToast(ods.length + ' tasks moved to today', 'Undo', () => {
      old.forEach(o => { const t = findTask(state, o.id); if (t) t.due = o.due; });
      saveState(state);
      render();
    });
  });

  // Day Complete ritual: the first moment today's plan hits
  // 100%, celebrate once and offer the Review screen.
  if (stats.dueTodayCount > 0 && stats.pctToday === 100 &&
      !state.dayDoneCelebrated[todayStr(now)]) {
    state.dayDoneCelebrated[todayStr(now)] = true;
    saveState(state);
    showDayComplete();
  }
}

/* The Day Complete overlay: a small full-screen moment. */
function showDayComplete() {
  if (document.getElementById('dayComplete')) return;
  const d = document.createElement('div');
  d.className = 'day-complete';
  d.id = 'dayComplete';
  d.innerHTML = '<div class="dc-emoji">🎉</div>' +
    '<div class="dc-title">Day Complete!</div>' +
    '<p>Everything due today is done. That is how streaks are built.</p>' +
    '<div class="alarm-actions">' +
    '<button class="btn btn-primary" id="dcReview">📊 See my Review</button>' +
    '<button class="btn" id="dcClose">Close</button></div>';
  document.body.appendChild(d);
  tymBuzz([150, 60, 150, 60, 300]);
  document.getElementById('dcClose').addEventListener('click', () => d.remove());
  document.getElementById('dcReview').addEventListener('click', () => { window.location.href = 'review.html'; });
}

/* Quick add: type naturally — "Pay fees tomorrow 5pm !high
   #college" — parse.js pulls out date, time, priority, tags.
   No date given = due today. Details via the editor (✏️). */
function quickAdd() {
  const input = document.getElementById('quickInput');
  const raw = input.value.trim();
  if (!raw) return;
  const p = parseQuickAdd(raw, new Date());
  if (!p.title) { showToast('Type the task name too'); return; }
  addTaskToState(state, {
    title: p.title, due: p.due || todayStr(), time: p.time,
    priority: p.priority || 'med', tags: p.tags, listId: 'personal'
  });
  input.value = '';
  saveState(state);
  render();
}

/* Voice input (F5): speak the task instead of typing.
   Uses the browser's speech recognition when available. */
function voiceAdd() {
  // In the phone app, Android's own speech engine does this.
  if (typeof tymVoiceInput === 'function') {
    tymVoiceInput(text => {
      document.getElementById('quickInput').value = text;
      quickAdd();
    }).then(handled => { if (!handled) voiceAddWeb(); });
    return;
  }
  voiceAddWeb();
}
function voiceAddWeb() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { showToast('Voice input is not supported in this browser'); return; }
  const rec = new SR();
  rec.lang = 'en-IN';
  showToast('🎙 Listening… speak your task');
  rec.onresult = e => {
    document.getElementById('quickInput').value = e.results[0][0].transcript;
    quickAdd();
  };
  rec.onerror = () => showToast('Could not hear that — try again');
  rec.start();
}

document.addEventListener('DOMContentLoaded', () => {
  render();
  document.getElementById('quickAddBtn').addEventListener('click', quickAdd);
  document.getElementById('quickInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') quickAdd();
  });
  document.getElementById('newTaskBtn').addEventListener('click', () => openTaskEditor(null));
  const vb = document.getElementById('voiceBtn');
  if (vb) vb.addEventListener('click', voiceAdd);
  const pb = document.getElementById('printBtn');
  if (pb) {
    // Printing does nothing inside the app WebView — hide it there.
    if (typeof tymInApp === 'function' && tymInApp()) pb.style.display = 'none';
    else pb.addEventListener('click', () => window.print());
  }
});

/* Re-draw when the data changes anywhere (editor, cards). */
document.addEventListener('tym:changed', render);
