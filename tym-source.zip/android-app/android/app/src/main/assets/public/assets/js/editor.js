'use strict';
/* ============================================================
   TYM — Track Your Mind · editor.js
   What this file does: the TASK EDITOR popup, shared by all
   screens, plus the shared clicks on task cards.
   Editor fields: title, notes (Markdown ok), list, priority,
   due date + time, repeat (+ from-completion), reminders,
   estimate, tags, subtasks (indent a line with 2 spaces to
   nest it), attachments (small images), Top-3 pin.
   Also: Duplicate button + Save-as-template in the editor.
   On save: writes via tasks.js, saves state, fires
   'tym:changed' — screens re-render on it.
   ============================================================ */

let editorTaskId = null; // null = creating a new task
let editorAttachments = []; // working copy while the popup is open

const REMINDER_CHOICES = [
  { min: 0, label: 'At time' }, { min: 10, label: '10 min before' },
  { min: 60, label: '1 hour before' }, { min: 1440, label: '1 day before' }
];

/* Add the popup's HTML to the page (once). */
function buildEditorHTML() {
  if (document.getElementById('taskEditor')) return;
  const wrap = document.createElement('div');
  wrap.innerHTML =
  '<div class="modal" id="taskEditor"><div class="modal-card">' +
    '<h2 id="edHeading">New Task</h2>' +
    '<div id="edTemplateRow"><label>Start from a template</label>' +
      '<select class="field" id="edTemplate"><option value="">— none —</option></select></div>' +
    '<label>Title *</label>' +
    '<input class="field" id="edTitle" type="text" placeholder="What needs to be done?">' +
    '<label>Notes (Markdown works: **bold**, - list)</label>' +
    '<textarea class="field" id="edNotes" rows="2" placeholder="Any details…"></textarea>' +
    '<div class="row">' +
      '<div><label>List</label><select class="field" id="edList"></select></div>' +
      '<div><label>Priority</label><select class="field" id="edPriority">' +
        '<option value="high">🔴 High</option>' +
        '<option value="med" selected>🟠 Medium</option>' +
        '<option value="low">🟢 Low</option>' +
      '</select></div>' +
    '</div>' +
    '<div class="row">' +
      '<div><label>Due date</label><input class="field" id="edDue" type="date"></div>' +
      '<div><label>Time</label><input class="field" id="edTime" type="time"></div>' +
      '<div><label>Estimate (minutes)</label><input class="field" id="edEst" type="number" min="0" step="5" placeholder="30"></div>' +
    '</div>' +
    '<div class="row">' +
      '<div><label>Repeat</label><select class="field" id="edRepeat">' +
        '<option value="none">Never</option><option value="daily">Daily</option>' +
        '<option value="weekdays">Weekdays</option><option value="weekly">Weekly</option>' +
        '<option value="fortnightly">Every 2 weeks</option><option value="monthly">Monthly</option>' +
      '</select></div>' +
      '<div><label>Next copy from</label><select class="field" id="edRepeatBase">' +
        '<option value="due">Due date</option><option value="completion">Completion day</option>' +
      '</select></div>' +
    '</div>' +
    '<label>Remind me</label><div class="remind-row" id="edReminders">' +
      REMINDER_CHOICES.map(r =>
        '<label class="checkline"><input type="checkbox" value="' + r.min + '"> ' + r.label + '</label>').join('') +
    '</div>' +
    '<label>Tags (comma separated)</label>' +
    '<input class="field" id="edTags" type="text" placeholder="exam, fees, home">' +
    '<label>Subtasks (one per line — indent with 2 spaces to nest)</label>' +
    '<textarea class="field" id="edSubs" rows="3" placeholder="Step one&#10;  Nested step&#10;Step two"></textarea>' +
    '<label>Attach an image (small, under 300 KB)</label>' +
    '<input class="field" id="edAttach" type="file" accept="image/*">' +
    '<div class="attach-row" id="edAttachRow"></div>' +
    '<label class="checkline"><input type="checkbox" id="edFocus"> 📌 Pin to Top 3 (My Day)</label>' +
    '<div class="modal-actions">' +
      '<button class="btn" id="edDup" style="display:none">⧉ Duplicate</button>' +
      '<button class="btn" id="edTemplateSave">💾 As template</button>' +
      '<button class="btn" id="edCancel">Cancel</button>' +
      '<button class="btn btn-primary" id="edSave">Save Task</button>' +
    '</div>' +
  '</div></div>';
  document.body.appendChild(wrap.firstChild);

  document.getElementById('edCancel').addEventListener('click', closeTaskEditor);
  document.getElementById('edSave').addEventListener('click', saveTaskEditor);
  document.getElementById('edDup').addEventListener('click', duplicateFromEditor);
  document.getElementById('edTemplateSave').addEventListener('click', saveAsTemplate);
  document.getElementById('edTemplate').addEventListener('change', applyTemplate);
  document.getElementById('edAttach').addEventListener('change', onAttachPick);
  document.getElementById('taskEditor').addEventListener('click', e => {
    if (e.target.id === 'taskEditor') closeTaskEditor();
  });
}

/* Tell every screen: "the data changed, draw yourself again." */
function announceChange() {
  document.dispatchEvent(new CustomEvent('tym:changed'));
}

/* Read every form field into a fields object. */
function readEditorFields() {
  return {
    title: document.getElementById('edTitle').value.trim(),
    notes: document.getElementById('edNotes').value.trim(),
    listId: document.getElementById('edList').value,
    priority: document.getElementById('edPriority').value,
    due: document.getElementById('edDue').value || null,
    time: document.getElementById('edTime').value || null,
    estMinutes: parseInt(document.getElementById('edEst').value, 10) || 0,
    repeat: document.getElementById('edRepeat').value,
    repeatBase: document.getElementById('edRepeatBase').value,
    reminders: Array.from(document.querySelectorAll('#edReminders input:checked'))
      .map(c => parseInt(c.value, 10)),
    tags: document.getElementById('edTags').value.split(',')
      .map(s => s.trim().toLowerCase()).filter(Boolean),
    focus: document.getElementById('edFocus').checked,
    attachments: editorAttachments.slice(),
    subtasks: document.getElementById('edSubs').value.split('\n')
      .filter(line => line.trim())
      .map(line => ({ title: line.trim(), depth: /^(\s{2,}|\t)/.test(line) ? 1 : 0 }))
  };
}

/* Fill the form from a fields object (task or template). */
function fillEditor(f) {
  document.getElementById('edTitle').value = f.title || '';
  document.getElementById('edNotes').value = f.notes || '';
  document.getElementById('edPriority').value = f.priority || 'med';
  document.getElementById('edDue').value = f.due || '';
  document.getElementById('edTime').value = f.time || '';
  document.getElementById('edEst').value = f.estMinutes || '';
  document.getElementById('edRepeat').value = f.repeat || 'none';
  document.getElementById('edRepeatBase').value = f.repeatBase || 'due';
  document.getElementById('edTags').value = (f.tags || []).join(', ');
  document.getElementById('edFocus').checked = !!f.focus;
  document.getElementById('edSubs').value = (f.subtasks || [])
    .map(s => (s.depth ? '  ' : '') + s.title).join('\n');
  document.querySelectorAll('#edReminders input').forEach(c => {
    c.checked = (f.reminders || []).includes(parseInt(c.value, 10));
  });
  editorAttachments = (f.attachments || []).slice();
  renderAttachRow();
  const listSel = document.getElementById('edList');
  if (f.listId) listSel.value = f.listId;
}

function renderAttachRow() {
  const row = document.getElementById('edAttachRow');
  if (!row) return;
  row.innerHTML = editorAttachments.map((a, i) =>
    '<span class="attach-chip"><img src="' + a.dataUrl + '" alt="">' + escapeHTML(a.name) +
    ' <button type="button" data-detach="' + i + '">✕</button></span>').join('');
}

/* Attach: keep only small images — localStorage is limited. */
function onAttachPick(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  if (file.size > 300 * 1024) { showToast('Image too big — keep it under 300 KB'); return; }
  const r = new FileReader();
  r.onload = () => {
    editorAttachments.push({ name: file.name, dataUrl: r.result });
    renderAttachRow();
  };
  r.readAsDataURL(file);
  e.target.value = '';
}

/* Open the popup. task = null means "new task". */
function openTaskEditor(task) {
  buildEditorHTML();
  editorTaskId = task ? task.id : null;
  document.getElementById('edHeading').textContent = task ? 'Edit Task' : 'New Task';
  document.getElementById('edDup').style.display = task ? '' : 'none';
  document.getElementById('edTemplateRow').style.display = task ? 'none' : '';
  document.getElementById('edList').innerHTML = state.lists.map(l =>
    '<option value="' + l.id + '"' + (task && task.listId === l.id ? ' selected' : '') +
    '>' + escapeHTML(l.name) + '</option>').join('');
  const tsel = document.getElementById('edTemplate');
  tsel.innerHTML = '<option value="">— none —</option>' + state.templates.map(t =>
    '<option value="' + t.id + '">' + escapeHTML(t.name) + '</option>').join('');
  fillEditor(task || {});
  document.getElementById('taskEditor').classList.add('open');
  document.getElementById('edTitle').focus();
}

function closeTaskEditor() {
  const m = document.getElementById('taskEditor');
  if (m) m.classList.remove('open');
  editorTaskId = null;
}

/* Load a saved template into the (new task) form. */
function applyTemplate() {
  const id = document.getElementById('edTemplate').value;
  if (!id) return;
  const t = state.templates.find(x => x.id === id);
  if (t) fillEditor(t.fields);
}

/* Save the current form as a reusable template. */
function saveAsTemplate() {
  const f = readEditorFields();
  if (!f.title) { showToast('Give the task a title first'); return; }
  state.templates.push({ id: makeId(), name: f.title, fields: f });
  saveState(state);
  showToast('Template saved 💾');
}

/* Duplicate: create a copy of the task being edited. */
function duplicateFromEditor() {
  if (!editorTaskId) return;
  const t = findTask(state, editorTaskId);
  if (!t) return;
  const copy = addTaskToState(state, {
    title: t.title + ' (copy)', notes: t.notes, listId: t.listId, priority: t.priority,
    tags: t.tags.slice(), due: t.due, time: t.time, repeat: 'none',
    reminders: t.reminders.slice(), estMinutes: t.estMinutes,
    subtasks: t.subtasks.map(s => ({ title: s.title, depth: s.depth || 0 }))
  });
  saveState(state);
  closeTaskEditor();
  announceChange();
  showToast('Task duplicated ⧉');
}

/* Read the form, write the task, close, announce. */
function saveTaskEditor() {
  const fields = readEditorFields();
  if (!fields.title) { document.getElementById('edTitle').focus(); return; }
  if (fields.focus) {
    const others = state.tasks.filter(t => t.focus && t.id !== editorTaskId && t.status !== 'done');
    if (others.length >= 3) { showToast('Top 3 is full — unpin one first'); return; }
  }
  if (editorTaskId) updateTask(state, editorTaskId, fields);
  else addTaskToState(state, fields);
  saveState(state);
  closeTaskEditor();
  announceChange();
}

/* Escape closes the popup, on any screen that has it. */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeTaskEditor();
});

/* ---------- shared card clicks ----------
   Tick done, tick subtask, pin focus, edit, delete (+Undo),
   remove an attachment chip inside the editor.             */
document.addEventListener('change', e => {
  const chk = e.target.closest('[data-check]');
  if (chk) {
    setTaskDone(state, chk.dataset.check, chk.checked, new Date());
    saveState(state);
    announceChange();
    return;
  }
  const sub = e.target.closest('[data-sub]');
  if (sub) {
    toggleSubtask(state, sub.dataset.task, sub.dataset.sub);
    saveState(state);
    announceChange();
  }
});

document.addEventListener('click', e => {
  const det = e.target.closest('[data-detach]');
  if (det) {
    editorAttachments.splice(parseInt(det.dataset.detach, 10), 1);
    renderAttachRow();
    return;
  }
  const ed = e.target.closest('[data-edit]');
  if (ed) {
    const t = findTask(state, ed.dataset.edit);
    if (t) openTaskEditor(t);
    return;
  }
  const del = e.target.closest('[data-del]');
  if (del) {
    const removed = removeTask(state, del.dataset.del);
    saveState(state);
    announceChange();
    if (removed) showToast('Task deleted', 'Undo', () => {
      restoreTask(state, removed);
      saveState(state);
      announceChange();
    });
    return;
  }
  const foc = e.target.closest('[data-focus]');
  if (foc) {
    const t = findTask(state, foc.dataset.focus);
    if (!t) return;
    if (!t.focus) {
      const pinned = state.tasks.filter(x => x.focus && x.status !== 'done');
      if (pinned.length >= 3) { showToast('Top 3 is full — unpin one first'); return; }
      t.focus = true;
    } else {
      t.focus = false;
    }
    saveState(state);
    announceChange();
  }
});
