'use strict';
/* ============================================================
   TYM — Track Your Mind · taskcard.js
   What this file does: builds the HTML for ONE task card.
   Every screen that shows tasks (Today, All, Completed...)
   uses this, so a task looks the same everywhere.
   Pure string building — no screen state here. Buttons carry
   data-* attributes; the screen files handle the clicks
   (one shared pattern, wired in each screen file).
   Needs: dates.js (due labels) and tasks.js (progress).
   ============================================================ */

/* Find a list's display name/colour from the state lists. */
function listOf(state, listId) {
  return state.lists.find(l => l.id === listId) || { name: '', color: '#999' };
}

/* The HTML for one task card.
   opts.compact = true hides subtask checkboxes (Completed). */
function taskCardHTML(state, t, opts) {
  const o = opts || {};
  const list = listOf(state, t.listId);
  const prog = subtaskProgress(t);
  const overdue = isOverdueTask(t, new Date());
  const subs = (t.subtasks || []).map(s =>
    '<label class="sub"' + (s.depth ? ' style="margin-left:20px"' : '') + '><input type="checkbox" data-sub="' + s.id + '" data-task="' + t.id + '"' +
    (s.done ? ' checked' : '') + (o.compact ? ' disabled' : '') + '> ' +
    '<span class="' + (s.done ? 'sub-done' : '') + '">' + escapeHTML(s.title) + '</span></label>'
  ).join('');

  return '<div class="task' + (t.status === 'done' ? ' done' : '') + (overdue ? ' overdue' : '') +
    '" data-card="' + t.id + '">' +
    '<input type="checkbox" class="check" data-check="' + t.id + '"' +
      (t.status === 'done' ? ' checked' : '') + '>' +
    '<div class="task-main">' +
      '<div class="task-title">' + escapeHTML(t.title) + '</div>' +
      (t.notes ? '<div class="task-notes">' + (typeof mdRender === 'function' ? mdRender(t.notes) : escapeHTML(t.notes)) + '</div>' : '') +
      '<div class="task-meta">' +
        '<span class="pill prio-' + t.priority + '">' +
          (t.priority === 'med' ? 'medium' : t.priority) + '</span>' +
        '<span class="pill"><i class="dot" style="background:' + list.color + '"></i>' +
          escapeHTML(list.name) + '</span>' +
        (t.due ? '<span class="pill">' + dueLabel(t.due) + (t.time ? ' · ' + t.time : '') + '</span>' : '') +
        (t.repeat !== 'none' ? '<span class="pill">🔁 ' + t.repeat + '</span>' : '') +
        (t.focus ? '<span class="pill">📌 focus</span>' : '') +
        (t.estMinutes ? '<span class="pill">⏱ ' + t.estMinutes + 'm</span>' : '') +
        (t.reminders && t.reminders.length ? '<span class="pill">⏰ ' + t.reminders.length + '</span>' : '') +
        (t.tags || []).map(tag => '<span class="pill">#' + escapeHTML(tag) + '</span>').join('') +
        (prog.total ? '<span class="pill">' + prog.done + '/' + prog.total + ' steps</span>' : '') +
      '</div>' +
      (prog.total ? '<div class="progress"><div style="width:' + prog.pct + '%"></div></div>' : '') +
      (subs ? '<div class="subs">' + subs + '</div>' : '') +
      ((t.attachments && t.attachments.length)
        ? '<div class="attach-row">' + t.attachments.map(a =>
            '<img class="attach-img" src="' + a.dataUrl + '" alt="' + escapeHTML(a.name) + '">').join('') + '</div>'
        : '') +
    '</div>' +
    '<div class="task-actions">' +
      '<button class="icon-btn" data-focus="' + t.id + '" title="Pin to Top 3">' +
        (t.focus ? '📌' : '📍') + '</button>' +
      '<button class="icon-btn" data-edit="' + t.id + '" title="Edit">✏️</button>' +
      '<button class="icon-btn" data-del="' + t.id + '" title="Delete">🗑</button>' +
    '</div>' +
  '</div>';
}
