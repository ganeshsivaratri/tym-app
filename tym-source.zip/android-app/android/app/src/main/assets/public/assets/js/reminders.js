'use strict';
/* ============================================================
   TYM — Track Your Mind · reminders.js
   What this file does: REMINDERS + the ALARM.
   - Works out when each task should remind (fire times).
   - A small engine checks every 15 seconds.
   - Browser: shows the full-screen alarm + sound, and a
     system notification if permission was given.
   - Android app: also schedules real phone notifications
     through native.js, so alarms fire with the app closed.
   The pure math (reminderFireTimes, dueReminders) is
   exported for the Node tests.
   ============================================================ */

/* The moment a task is "due": its date + its time.
   A task with a date but no time is due at 09:00. */
function dueMomentMs(task) {
  if (!task.due) return null;
  const p = task.due.split('-').map(Number);
  const t = (task.time || '09:00').split(':').map(Number);
  return new Date(p[0], p[1] - 1, p[2], t[0], t[1]).getTime();
}

/* All the times this task should ring: due moment minus
   each reminder offset (in minutes). Sorted, oldest first. */
function reminderFireTimes(task) {
  const base = dueMomentMs(task);
  if (base === null) return [];
  const offsets = (task.reminders && task.reminders.length) ? task.reminders : [];
  return offsets.map(min => base - min * 60000).sort((a, b) => a - b);
}

/* Which reminders should ring RIGHT NOW?
   Rules: task still open · fire time reached · not rung
   before · not older than 2 hours (no stale rings) ·
   a snoozed task rings again when its snooze ends. */
function dueReminders(state, nowMs) {
  const out = [];
  for (const t of state.tasks) {
    if (t.status === 'done') continue;
    const until = state.snoozed && state.snoozed[t.id];
    if (until) {
      if (nowMs >= until) out.push({ task: t, key: t.id + '@s' + until, snoozeEnd: true });
      continue;
    }
    for (const ft of reminderFireTimes(t)) {
      const key = t.id + '@' + ft;
      if (ft <= nowMs && nowMs - ft < 2 * 3600 * 1000 && !(state.fired && state.fired[key])) {
        out.push({ task: t, key, fireMs: ft });
      }
    }
  }
  return out;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { dueMomentMs, reminderFireTimes, dueReminders };
}

/* ---------- browser-only engine below ---------- */
if (typeof window !== 'undefined' && typeof document !== 'undefined') {

  let audioCtx = null, beepTimer = null, ringingKey = null;

  /* A simple repeating beep, made with WebAudio (no file). */
  function startBeep() {
    stopBeep();
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const beep = () => {
        if (!audioCtx) return;
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = 'sine'; o.frequency.value = 880;
        g.gain.setValueAtTime(0.0001, audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.25, audioCtx.currentTime + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.45);
        o.connect(g); g.connect(audioCtx.destination);
        o.start(); o.stop(audioCtx.currentTime + 0.5);
      };
      beep();
      beepTimer = setInterval(beep, 1200);
    } catch (e) { /* sound blocked — the visual alarm still shows */ }
    tymBuzz([300, 120, 300, 120, 300]);
  }
  function stopBeep() {
    if (beepTimer) { clearInterval(beepTimer); beepTimer = null; }
  }

  /* Build the full-screen alarm view (once). */
  function buildAlarmHTML() {
    if (document.getElementById('alarmView')) return;
    const d = document.createElement('div');
    d.className = 'alarm-view';
    d.id = 'alarmView';
    d.innerHTML =
      '<div class="alarm-emoji">⏰</div>' +
      '<div class="alarm-title" id="alarmTitle"></div>' +
      '<div class="alarm-sub" id="alarmSub"></div>' +
      '<div class="alarm-actions">' +
        '<button class="btn btn-primary" id="alarmDone">✓ Done</button>' +
        '<button class="btn" id="alarmSnooze">😴 Snooze 10 min</button>' +
      '</div>';
    document.body.appendChild(d);
  }

  let alarmTaskId = null;
  function showAlarm(task) {
    buildAlarmHTML();
    alarmTaskId = task.id;
    document.getElementById('alarmTitle').textContent = task.title;
    document.getElementById('alarmSub').textContent =
      'Due ' + dueLabel(task.due) + (task.time ? ' · ' + task.time : '');
    document.getElementById('alarmView').classList.add('show');
    startBeep();
  }
  function hideAlarm() {
    const v = document.getElementById('alarmView');
    if (v) v.classList.remove('show');
    stopBeep();
    alarmTaskId = null;
  }

  document.addEventListener('click', e => {
    if (e.target.id === 'alarmDone' && alarmTaskId) {
      const id = alarmTaskId;
      hideAlarm();
      setTaskDone(state, id, true, new Date());
      saveState(state);
      document.dispatchEvent(new CustomEvent('tym:changed'));
      showToast('Done 🎉');
    }
    if (e.target.id === 'alarmSnooze' && alarmTaskId) {
      state.snoozed[alarmTaskId] = Date.now() + 10 * 60000;
      saveState(state);
      hideAlarm();
      showToast('Snoozed for 10 minutes 😴');
    }
  });

  /* The engine: check every 15 seconds. */
  function engineTick() {
    if (typeof state === 'undefined') return;
    const due = dueReminders(state, Date.now());
    for (const d of due) {
      state.fired[d.key] = true;
      if (d.snoozeEnd) delete state.snoozed[d.task.id];
      saveState(state);
      // System notification too, if the user allowed it.
      try {
        if (window.Notification && Notification.permission === 'granted') {
          new Notification('⏰ TYM Reminder', { body: d.task.title });
        }
      } catch (e) { /* ignore */ }
      if (!ringingKey) { ringingKey = d.key; showAlarm(d.task); }
    }
    if (ringingKey && !document.getElementById('alarmView').classList.contains('show')) {
      ringingKey = null;
    }
    if (!document.getElementById('alarmView') ||
        !document.getElementById('alarmView').classList.contains('show')) ringingKey = null;
  }

  /* In the Android app, mirror upcoming reminders as real
     phone notifications (they fire with the app closed). */
  let nativeTimer = null;
  function syncNative() {
    if (!tymInApp() || typeof state === 'undefined') return;
    clearTimeout(nativeTimer);
    nativeTimer = setTimeout(async () => {
      await tymRequestNotifyPermission();
      const now = Date.now();
      const upcoming = [];
      for (const t of state.tasks) {
        if (t.status === 'done') continue;
        for (const ft of reminderFireTimes(t)) if (ft > now) upcoming.push({ t, ft });
      }
      upcoming.sort((a, b) => a.ft - b.ft);
      for (const u of upcoming.slice(0, 30)) {
        let h = 0; const s = u.t.id + '@' + u.ft;
        for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
        tymScheduleNotification(h % 2000000000, '⏰ TYM Reminder', u.t.title, u.ft);
      }
    }, 600);
  }

  document.addEventListener('DOMContentLoaded', () => {
    setInterval(engineTick, 15000);
    setTimeout(engineTick, 2500);
    syncNative();
  });
  document.addEventListener('tym:changed', syncNative);
}
