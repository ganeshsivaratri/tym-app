'use strict';
/* ============================================================
   TYM — Track Your Mind · dates.js
   What this file does: ALL date math, in one place.
   Dates are plain strings: 'YYYY-MM-DD'. Times: 'HH:MM'.
   Keeping dates as strings makes comparing them easy:
   '2026-11-08' < '2026-11-09' works like numbers.
   Every function here is pure (no storage, no screen),
   so the Node tests can check all of them.
   ============================================================ */

/* 7 -> '07' */
function pad2(n) { return String(n).padStart(2, '0'); }

/* A Date object -> 'YYYY-MM-DD' (local time, not UTC). */
function dateToStr(d) {
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
}

/* Today's date string. Pass a Date in tests to fix "today". */
function todayStr(now) { return dateToStr(now || new Date()); }

/* Add n days to a date string. Handles month/year edges. */
function addDaysStr(str, n) {
  const p = str.split('-').map(Number);
  return dateToStr(new Date(p[0], p[1] - 1, p[2] + n));
}

/* Add n months. The day is clamped: Jan 31 + 1 month -> Feb 28. */
function addMonthsStr(str, n) {
  const p = str.split('-').map(Number);
  const first = new Date(p[0], p[1] - 1 + n, 1);
  const lastDay = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
  first.setDate(Math.min(p[2], lastDay));
  return dateToStr(first);
}

/* Whole days from a to b (b - a). '2026-11-08' -> '2026-11-10' = 2. */
function daysBetween(a, b) {
  const pa = a.split('-').map(Number);
  const pb = b.split('-').map(Number);
  const da = new Date(pa[0], pa[1] - 1, pa[2]);
  const db = new Date(pb[0], pb[1] - 1, pb[2]);
  return Math.round((db - da) / 86400000);
}

/* The next date of a repeating task.
   repeat: 'daily' | 'weekly' | 'monthly' | 'none'          */
function nextRepeatDate(str, repeat) {
  if (!str) return null;
  if (repeat === 'daily') return addDaysStr(str, 1);
  if (repeat === 'weekdays') {           // Mon–Fri only: skip Sat/Sun
    let n = addDaysStr(str, 1);
    let dow = new Date(...n.split('-').map((v, i) => i === 1 ? v - 1 : v)).getDay();
    while (dow === 0 || dow === 6) { n = addDaysStr(n, 1); dow = (dow + 1) % 7; }
    return n;
  }
  if (repeat === 'weekly') return addDaysStr(str, 7);
  if (repeat === 'fortnightly') return addDaysStr(str, 14);
  if (repeat === 'monthly') return addMonthsStr(str, 1);
  return null;
}

/* Short, friendly label for a due date: 'Today', 'Tomorrow',
   or '12 Nov'. Shown on task cards. */
function dueLabel(str, now) {
  if (!str) return '';
  const today = todayStr(now);
  if (str === today) return 'Today';
  if (str === addDaysStr(today, 1)) return 'Tomorrow';
  if (str === addDaysStr(today, -1)) return 'Yesterday';
  const p = str.split('-').map(Number);
  return new Date(p[0], p[1] - 1, p[2])
    .toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

/* Make the functions available to the Node tests. */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    pad2, dateToStr, todayStr, addDaysStr, addMonthsStr,
    daysBetween, nextRepeatDate, dueLabel
  };
}
