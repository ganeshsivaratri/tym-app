'use strict';
/* ============================================================
   TYM — Track Your Mind · timeline.js
   What this file does: the TIMELINE screen — one day laid
   out hour by hour. Includes:
   - "Plan My Day" (plan.js arrangeDay) with Undo
   - "What can I do now?" (plan.js whatCanIDo)
   Pick any date with the date box at the top.
   ============================================================ */

let tlDate = todayStr();

function render() {
  const box = document.getElementById('screenContent');
  const dayTasks = state.tasks.filter(t => t.due === tlDate && t.status !== 'done');
  const timed = dayTasks.filter(t => t.time).sort((a, b) => a.time < b.time ? -1 : 1);
  const untimed = sortTasks(dayTasks.filter(t => !t.time), 'priority');
  const plannedMin = dayTasks.reduce((sum, t) => sum + (t.estMinutes || 30), 0);

  let rows = '';
  for (let h = 6; h <= 22; h++) {
    const hh = pad2(h) + ':00';
    const here = timed.filter(t => t.time.slice(0, 2) === pad2(h));
    rows += '<div class="tl-row"><div class="tl-hour">' + hh + '</div>' +
      '<div class="tl-slot">' +
      (here.length ? here.map(t =>
        '<div class="tl-item prio-border-' + t.priority + '">' +
        '<b>' + t.time + '</b> ' + escapeHTML(t.title) +
        (t.estMinutes ? ' <span class="pill">⏱ ' + t.estMinutes + 'm</span>' : '') +
        ' <button class="icon-btn" data-edit="' + t.id + '">✏️</button></div>').join('')
        : '<span class="tl-free">free</span>') +
      '</div></div>';
  }

  box.innerHTML =
    '<div class="toolbar">' +
      '<input class="field" type="date" id="tlDate" value="' + tlDate + '" style="flex:0 1 190px">' +
      '<button class="btn btn-primary" id="tlPlan">✨ Plan My Day</button>' +
      '<span class="pill" style="align-self:center">Planned: ' +
        Math.floor(plannedMin / 60) + 'h ' + (plannedMin % 60) + 'm</span>' +
    '</div>' +
    '<div class="card" style="margin-bottom:14px"><h2>⏱ What can I do now?</h2>' +
      '<div class="toolbar" style="margin:0">' +
        '<input class="field" id="wcFree" type="number" min="5" step="5" value="30" style="flex:0 1 130px">' +
        '<span style="align-self:center;color:var(--muted)">free minutes · energy</span>' +
        '<select class="field" id="wcEnergy" style="flex:0 1 150px">' +
          '<option value="high">High 🔋</option><option value="med" selected>Medium</option>' +
          '<option value="low">Low 🪫</option></select>' +
        '<button class="btn" id="wcGo">Find</button>' +
      '</div><div id="wcResults" style="margin-top:10px"></div></div>' +
    (untimed.length
      ? '<div class="section-title">No time set</div><div style="margin-bottom:8px">' +
        untimed.map(t => taskCardHTML(state, t)).join('') + '</div>'
      : '') +
    '<div class="card">' + rows + '</div>';

  document.getElementById('tlDate').addEventListener('change', e => {
    tlDate = e.target.value || todayStr(); render();
  });
  document.getElementById('tlPlan').addEventListener('click', planMyDay);
  document.getElementById('wcGo').addEventListener('click', () => {
    const free = parseInt(document.getElementById('wcFree').value, 10) || 30;
    const energy = document.getElementById('wcEnergy').value;
    const picks = whatCanIDo(state.tasks, free, energy).slice(0, 5);
    document.getElementById('wcResults').innerHTML = picks.length
      ? picks.map(t => taskCardHTML(state, t)).join('')
      : '<p style="color:var(--muted)">Nothing fits that slot — enjoy the break. ☕</p>';
  });
}

/* Plan My Day: assign times to untimed tasks. Undo included. */
function planMyDay() {
  const placed = arrangeDay(state.tasks, tlDate, '09:00');
  if (!placed.length) { showToast('Nothing to arrange — all tasks have times'); return; }
  const old = placed.map(p => ({ id: p.id, time: findTask(state, p.id).time }));
  for (const p of placed) findTask(state, p.id).time = p.time;
  saveState(state);
  render();
  showToast('Day planned ✨', 'Undo', () => {
    for (const o of old) findTask(state, o.id).time = o.time;
    saveState(state);
    render();
  });
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', render);
