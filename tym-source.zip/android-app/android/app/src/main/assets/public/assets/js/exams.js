'use strict';
/* ============================================================
   TYM — Track Your Mind · exams.js
   What this file does: the EXAMS screen — countdown cards
   for every exam, and a one-tap REVISION PLAN: creates
   spaced revision tasks at exam−7, exam−3 and exam−1 days.
   Exams live in state.exams: [{ id, subject, date }]
   ============================================================ */

function render() {
  const box = document.getElementById('screenContent');
  const today = todayStr();
  const upcoming = state.exams.slice().sort((a, b) => a.date < b.date ? -1 : 1);

  box.innerHTML =
    '<div class="toolbar">' +
      '<input class="field" id="examSubject" type="text" placeholder="Subject — e.g. Compiler Design">' +
      '<input class="field" id="examDate" type="date" style="flex:0 1 190px">' +
      '<button class="btn btn-primary" id="examAdd">Add exam</button>' +
    '</div>' +
    (upcoming.length ? '<div class="exam-grid stagger">' + upcoming.map(x => {
      const days = daysBetween(today, x.date);
      const label = days < 0 ? 'done' : days === 0 ? 'TODAY 🔥' : days === 1 ? 'tomorrow' : days + ' days to go';
      return '<div class="card exam-card">' +
        '<div class="exam-days">' + (days < 0 ? '✓' : days) + '</div>' +
        '<div class="exam-label">' + (days >= 0 ? 'days' : '') + '</div>' +
        '<h2 style="margin:6px 0 2px">' + escapeHTML(x.subject) + '</h2>' +
        '<p style="color:var(--muted);margin:0 0 10px">' +
          new Date(...x.date.split('-').map((v, i) => i === 1 ? v - 1 : v))
            .toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }) +
          ' · ' + label + '</p>' +
        '<button class="btn" data-exam-plan="' + x.id + '">🗓 Revision plan</button> ' +
        '<button class="icon-btn" data-exam-del="' + x.id + '">🗑</button>' +
      '</div>';
    }).join('') + '</div>'
    : '<div class="card empty"><div class="empty-art">⏳</div><p>No exams yet. Add one above and the countdown begins.</p></div>');

  document.getElementById('examAdd').addEventListener('click', () => {
    const subject = document.getElementById('examSubject').value.trim();
    const date = document.getElementById('examDate').value;
    if (!subject || !date) { showToast('Add a subject and a date'); return; }
    state.exams.push({ id: makeId(), subject, date });
    saveState(state);
    render();
  });
}

document.addEventListener('click', e => {
  const plan = e.target.closest('[data-exam-plan]');
  if (plan) {
    const x = state.exams.find(v => v.id === plan.dataset.examPlan);
    if (!x) return;
    const today = todayStr();
    const rounds = [
      { at: addDaysStr(x.date, -7), name: 'Round 1 — full revision' },
      { at: addDaysStr(x.date, -3), name: 'Round 2 — weak areas' },
      { at: addDaysStr(x.date, -1), name: 'Final — formulas & key points' }
    ].filter(r => r.at >= today);
    if (!rounds.length) { showToast('Exam is too close — revise today 💪'); return; }
    rounds.forEach(r => addTaskToState(state, {
      title: x.subject + ': ' + r.name, due: r.at, listId: 'study',
      priority: 'high', tags: ['revision', 'exam']
    }));
    saveState(state);
    showToast('Revision plan created: ' + rounds.length + ' tasks 🗓');
    return;
  }
  const del = e.target.closest('[data-exam-del]');
  if (del) {
    state.exams = state.exams.filter(v => v.id !== del.dataset.examDel);
    saveState(state);
    render();
  }
});

document.addEventListener('DOMContentLoaded', render);
