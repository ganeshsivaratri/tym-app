'use strict';
/* ============================================================
   TYM — Track Your Mind · parse.js
   What this file does: understands quick-add text like
   "Pay fees tomorrow 5pm !high #college" and pulls out the
   due date, time, priority and tags, leaving a clean title.
   Pure function — the Node tests check it.
   Needs dates.js loaded before it.
   ============================================================ */

const DAY_NAMES = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

/* parseQuickAdd(text, now) -> { title, due, time, priority, tags }
   Anything not understood stays in the title. */
function parseQuickAdd(text, now) {
  const n = now || new Date();
  const today = todayStr(n);
  let rest = ' ' + String(text || '') + ' ';
  const out = { title: '', due: null, time: null, priority: null, tags: [] };

  // Tags: #word
  rest = rest.replace(/#(\w+)/g, (m, tag) => { out.tags.push(tag); return ' '; });

  // Priority: !high / !med / !low  (also !1 !2 !3)
  rest = rest.replace(/!(high|med|medium|low|1|2|3)\b/i, (m, p) => {
    const k = p.toLowerCase();
    out.priority = (k === 'high' || k === '1') ? 'high'
      : (k === 'low' || k === '3') ? 'low' : 'med';
    return ' ';
  });

  // Time: 5pm, 5:30pm, 17:30, "at 5 pm"
  const timeRe = /\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i;
  const timeRe24 = /\b([01]?\d|2[0-3]):([0-5]\d)\b/;
  let m = rest.match(timeRe);
  if (m) {
    let h = parseInt(m[1], 10) % 12;
    if (/pm/i.test(m[3])) h += 12;
    out.time = pad2(h) + ':' + (m[2] || '00');
    rest = rest.replace(timeRe, ' ');
  } else if ((m = rest.match(timeRe24))) {
    out.time = pad2(parseInt(m[1], 10)) + ':' + m[2];
    rest = rest.replace(timeRe24, ' ');
  }

  // Dates, most specific first.
  const lower = rest.toLowerCase();
  if (/\btomorrow\b/.test(lower)) {
    out.due = addDaysStr(today, 1);
    rest = rest.replace(/tomorrow/i, ' ');
  } else if (/\btoday\b/.test(lower)) {
    out.due = today;
    rest = rest.replace(/today/i, ' ');
  } else if ((m = lower.match(/\bin\s+(\d+)\s+days?\b/))) {
    out.due = addDaysStr(today, parseInt(m[1], 10));
    rest = rest.replace(/\bin\s+\d+\s+days?\b/i, ' ');
  } else if ((m = lower.match(/\bnext\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/)) ||
             (m = lower.match(/\b(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/))) {
    const target = DAY_NAMES.indexOf(m[1]);
    let delta = (target - n.getDay() + 7) % 7;
    if (delta === 0 || /^next/.test(m[0])) delta += 7; // "monday" said on Monday = next week
    out.due = addDaysStr(today, delta);
    rest = rest.replace(m[0], ' ');
  } else if ((m = lower.match(/\b(\d{4})-(\d{2})-(\d{2})\b/))) {
    out.due = m[0];
    rest = rest.replace(m[0], ' ');
  }

  out.title = rest.replace(/\s+/g, ' ').trim();
  return out;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { parseQuickAdd };
}
