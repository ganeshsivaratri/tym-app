'use strict';
/* ============================================================
   TYM — Track Your Mind · timetable.js
   What this file does: the TIMETABLE screen — the weekly
   class schedule as a 7-column grid. Entries live in
   state.timetable: [{ id, day, start, end, name, room }]
   day: 0 = Monday ... 6 = Sunday.
   ============================================================ */

const TT_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function render() {
  const box = document.getElementById('screenContent');
  const todayIdx = (new Date().getDay() + 6) % 7; // Monday = 0

  box.innerHTML =
    '<div class="toolbar">' +
      '<select class="field" id="ttDay" style="flex:0 1 150px">' +
        TT_DAYS.map((d, i) => '<option value="' + i + '"' + (i === todayIdx ? ' selected' : '') + '>' + d + '</option>').join('') +
      '</select>' +
      '<input class="field" id="ttStart" type="time" value="09:00" style="flex:0 1 120px">' +
      '<input class="field" id="ttEnd" type="time" value="10:00" style="flex:0 1 120px">' +
      '<input class="field" id="ttName" type="text" placeholder="Class / subject">' +
      '<input class="field" id="ttRoom" type="text" placeholder="Room" style="flex:0 1 110px">' +
      '<button class="btn btn-primary" id="ttAdd">Add</button>' +
    '</div>' +
    '<div class="tt-grid">' + TT_DAYS.map((d, i) => {
      const entries = state.timetable.filter(t => t.day === i)
        .sort((a, b) => a.start < b.start ? -1 : 1);
      return '<div class="tt-col' + (i === todayIdx ? ' tt-today' : '') + '">' +
        '<h4>' + d.slice(0, 3) + (i === todayIdx ? ' ·' : '') + '</h4>' +
        (entries.map(t =>
          '<div class="tt-block"><b>' + t.start + '–' + t.end + '</b><br>' +
          escapeHTML(t.name) + (t.room ? '<br><span>' + escapeHTML(t.room) + '</span>' : '') +
          ' <button class="icon-btn" data-tt-del="' + t.id + '">✕</button></div>').join('') ||
          '<p class="board-empty">—</p>') +
        '</div>';
    }).join('') + '</div>';

  document.getElementById('ttAdd').addEventListener('click', () => {
    const name = document.getElementById('ttName').value.trim();
    if (!name) { showToast('Add the class name'); return; }
    state.timetable.push({
      id: makeId(),
      day: parseInt(document.getElementById('ttDay').value, 10),
      start: document.getElementById('ttStart').value || '09:00',
      end: document.getElementById('ttEnd').value || '10:00',
      name, room: document.getElementById('ttRoom').value.trim()
    });
    saveState(state);
    render();
  });
}

document.addEventListener('click', e => {
  const del = e.target.closest('[data-tt-del]');
  if (del) {
    state.timetable = state.timetable.filter(t => t.id !== del.dataset.ttDel);
    saveState(state);
    render();
  }
});

document.addEventListener('DOMContentLoaded', render);
