'use strict';
/* ============================================================
   TYM — Track Your Mind · habits.js
   What this file does: the HABITS screen.
   - Habits: tick today's box, watch the 🔥 streak grow.
     Ticks live in state.habitLog = { habitId: {date: true} }.
   - Routines: morning/night checklists that start fresh
     every day (state.routineLog is keyed by date, so a new
     day automatically shows an untouched list).
   ============================================================ */

function render() {
  const box = document.getElementById('screenContent');
  const now = new Date();
  const today = todayStr(now);
  const last7 = lastNDays(7, now);

  // --- Habits ---
  const habitRows = state.habits.map(h => {
    const log = state.habitLog[h.id] || {};
    const streak = habitStreak(log, now);
    const dots = last7.map(d =>
      '<span class="habit-dot' + (log[d] ? ' on' : '') + '" title="' + d + '"></span>').join('');
    return '<div class="task"><div class="task-main">' +
      '<div class="task-title">' + escapeHTML(h.name) +
      ' <span class="pill">🔥 ' + streak + ' day streak</span></div>' +
      '<div class="habit-dots">' + dots + '<span class="habit-week">last 7 days</span></div>' +
      '</div>' +
      '<button class="btn' + (log[today] ? ' btn-primary' : '') + '" data-habit-tick="' + h.id + '">' +
      (log[today] ? '✓ Done today' : 'Mark today') + '</button>' +
      '<button class="icon-btn" data-habit-del="' + h.id + '" title="Delete habit">🗑</button></div>';
  }).join('');

  // --- Routines ---
  const routineCards = state.routines.map(r => {
    const doneIdx = ((state.routineLog[today] || {})[r.id]) || [];
    const pct = r.items.length ? Math.round(doneIdx.length / r.items.length * 100) : 0;
    return '<div class="card" style="margin-bottom:12px"><h2>' + escapeHTML(r.name) +
      ' <span class="badge">' + pct + '%</span></h2>' +
      '<div class="progress" style="margin-bottom:10px"><div style="width:' + pct + '%"></div></div>' +
      r.items.map((item, i) =>
        '<label class="sub"><input type="checkbox" data-routine="' + r.id + '" data-idx="' + i + '"' +
        (doneIdx.includes(i) ? ' checked' : '') + '> <span class="' +
        (doneIdx.includes(i) ? 'sub-done' : '') + '">' + escapeHTML(item) + '</span></label>').join('') +
      '<div style="margin-top:8px"><button class="icon-btn" data-routine-del="' + r.id + '">🗑 Remove routine</button></div></div>';
  }).join('');

  const startButtons = ROUTINE_TEMPLATES
    .filter(t => !state.routines.some(r => r.id === t.id))
    .map(t => '<button class="btn" data-routine-start="' + t.id + '">＋ ' + t.name + '</button>').join(' ');

  box.innerHTML =
    '<div class="toolbar"><input class="field" id="habitInput" type="text" placeholder="New habit — e.g. Read 10 pages">' +
    '<button class="btn btn-primary" id="habitAdd">Add habit</button></div>' +
    '<div class="toolbar">' + HABIT_IDEAS.map(i =>
      '<button class="btn" data-habit-idea="' + escapeHTML(i) + '">' + escapeHTML(i) + '</button>').join('') + '</div>' +
    (habitRows || '<div class="card empty"><div class="empty-art">🔥</div><p>No habits yet. Add one above — small and daily wins.</p></div>') +
    '<div class="section-title">Daily routines</div>' +
    (routineCards || '') +
    (startButtons ? '<div class="toolbar">' + startButtons + '</div>'
      : '<p style="color:var(--muted)">Routines reset fresh every morning, automatically.</p>');

  document.getElementById('habitAdd').addEventListener('click', addHabitFromInput);
  document.getElementById('habitInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') addHabitFromInput();
  });
}

function addHabit(name) {
  const clean = (name || '').trim();
  if (!clean) return;
  state.habits.push({ id: makeId(), name: clean, createdAt: Date.now() });
  saveState(state);
  render();
}
function addHabitFromInput() {
  addHabit(document.getElementById('habitInput').value);
}

/* Screen clicks (delegated — rows are re-drawn often). */
document.addEventListener('click', e => {
  const tick = e.target.closest('[data-habit-tick]');
  if (tick) {
    const id = tick.dataset.habitTick;
    const today = todayStr();
    state.habitLog[id] = state.habitLog[id] || {};
    if (state.habitLog[id][today]) delete state.habitLog[id][today];
    else state.habitLog[id][today] = true;
    saveState(state);
    render();
    return;
  }
  const idea = e.target.closest('[data-habit-idea]');
  if (idea) { addHabit(idea.dataset.habitIdea); return; }
  const del = e.target.closest('[data-habit-del]');
  if (del) {
    state.habits = state.habits.filter(h => h.id !== del.dataset.habitDel);
    delete state.habitLog[del.dataset.habitDel];
    saveState(state);
    render();
    return;
  }
  const start = e.target.closest('[data-routine-start]');
  if (start) {
    const t = ROUTINE_TEMPLATES.find(x => x.id === start.dataset.routineStart);
    if (t) state.routines.push({ id: t.id, name: t.name, items: t.items.slice() });
    saveState(state);
    render();
    return;
  }
  const rdel = e.target.closest('[data-routine-del]');
  if (rdel) {
    state.routines = state.routines.filter(r => r.id !== rdel.dataset.routineDel);
    saveState(state);
    render();
  }
});

document.addEventListener('change', e => {
  const box2 = e.target.closest('[data-routine]');
  if (!box2) return;
  const today = todayStr();
  state.routineLog[today] = state.routineLog[today] || {};
  const arr = state.routineLog[today][box2.dataset.routine] || [];
  const idx = parseInt(box2.dataset.idx, 10);
  state.routineLog[today][box2.dataset.routine] =
    box2.checked ? Array.from(new Set(arr.concat(idx))) : arr.filter(i => i !== idx);
  saveState(state);
  render();
});

document.addEventListener('DOMContentLoaded', render);
