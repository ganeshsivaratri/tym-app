/* ============================================================
   TYM — Track Your Mind · data.js
   What this file does: holds DEFAULT DATA only — the starter
   lists and templates a fresh app begins with.
   No logic lives here. Logic that uses this data sits in the
   screen files and in store.js.
   ============================================================ */

/* The three lists every new user starts with.
   The user can rename, recolour, add and delete lists later. */
const DEFAULT_LISTS = [
  { id: 'personal', name: 'Personal', color: '#6d5cff' },
  { id: 'work',     name: 'Work',     color: '#0ea5e9' },
  { id: 'study',    name: 'Study',    color: '#f59e0b' }
];

/* A ready-made morning routine. Routines reset fresh every day
   (built in Stage 5 — Habits screen). */
const ROUTINE_TEMPLATES = [
  {
    id: 'morning',
    name: 'Morning Routine',
    items: ['Wake up', 'Drink water', 'Exercise / walk', 'Shower', 'Plan Top 3 for today']
  },
  {
    id: 'night',
    name: 'Night Routine',
    items: ['Review today', 'Move unfinished tasks', 'Set tomorrow Top 3', 'No phone 30 min', 'Sleep on time']
  }
];

/* Starter habits a user can pick from (Stage 5). */
const HABIT_IDEAS = ['Read 10 pages', 'Exercise', 'Meditate 5 min', 'No sugar', 'Study 1 hour', 'Write journal'];

/* Make the defaults available to the Node tests. */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DEFAULT_LISTS, ROUTINE_TEMPLATES, HABIT_IDEAS };
}
