/* TYM service worker — caches the app shell so TYM opens
   offline and installs to the home screen. Bump the version
   when files change so phones pick up the new build. */
const TYM_CACHE = 'tym-v2';
const TYM_FILES = [
    './',
    'index.html',
    'all.html',
    'calendar.html',
    'board.html',
    'matrix.html',
    'timeline.html',
    'habits.html',
    'focus.html',
    'review.html',
    'study.html',
    'exams.html',
    'timetable.html',
    'completed.html',
    'settings.html',
    '404.html',
    'assets/css/styles.css',
    'assets/js/all.js',
    'assets/js/board.js',
    'assets/js/calendar.js',
    'assets/js/completed.js',
    'assets/js/data.js',
    'assets/js/dates.js',
    'assets/js/editor.js',
    'assets/js/exams.js',
    'assets/js/focus.js',
    'assets/js/habits.js',
    'assets/js/matrix.js',
    'assets/js/md.js',
    'assets/js/native.js',
    'assets/js/parse.js',
    'assets/js/plan.js',
    'assets/js/progress.js',
    'assets/js/reminders.js',
    'assets/js/review.js',
    'assets/js/settings.js',
    'assets/js/site.js',
    'assets/js/store.js',
    'assets/js/study.js',
    'assets/js/taskcard.js',
    'assets/js/tasks.js',
    'assets/js/timeline.js',
    'assets/js/timetable.js',
    'assets/js/today.js'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(TYM_CACHE).then(c => c.addAll(TYM_FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== TYM_CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)));
});
