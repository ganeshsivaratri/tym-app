'use strict';
/* ============================================================
   TYM — Track Your Mind · calendar.js
   What this file does: the CALENDAR screen — a month grid
   with task counts per day. Click a day to see its tasks.
   Drag a task card onto another day to reschedule it.
   ============================================================ */

const calStart = new Date();
let calYear = calStart.getFullYear();
let calMonth = calStart.getMonth();       // 0 = January
let calSelected = todayStr();

function render() {
  const box = document.getElementById('screenContent');
  const first = new Date(calYear, calMonth, 1);
  const monthName = first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  const leadBlanks = (first.getDay() + 6) % 7; // weeks start on Monday
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const today = todayStr();

  // Count open tasks per day of this month.
  const counts = {};
  for (const t of state.tasks) {
    if (t.status === 'done' || !t.due) continue;
    counts[t.due] = (counts[t.due] || 0) + 1;
  }

  let cells = '';
  for (let i = 0; i < leadBlanks; i++) cells += '<div class="cal-cell cal-blank"></div>';
  for (let d = 1; d <= daysInMonth; d++) {
    const ds = calYear + '-' + pad2(calMonth + 1) + '-' + pad2(d);
    const n = counts[ds] || 0;
    cells += '<button class="cal-cell' + (ds === today ? ' cal-today' : '') +
      (ds === calSelected ? ' cal-sel' : '') + '" data-day="' + ds + '">' +
      '<span class="cal-num">' + d + '</span>' +
      (n ? '<span class="cal-dots">' + '●'.repeat(Math.min(n, 5)) +
        '<span class="cal-count">' + n + '</span></span>' : '') + '</button>';
  }

  const dayTasks = sortTasks(
    state.tasks.filter(t => t.due === calSelected && t.status !== 'done'), 'due');
  const doneCount = state.tasks.filter(t => t.due === calSelected && t.status === 'done').length;

  box.innerHTML =
    '<div class="cal-head">' +
      '<button class="btn" id="calPrev">‹</button>' +
      '<h2 style="margin:0">' + monthName + '</h2>' +
      '<button class="btn" id="calNext">›</button>' +
      '<button class="btn" id="calToday">Today</button>' +
    '</div>' +
    '<div class="cal-grid cal-week">' +
      ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => '<div>' + d + '</div>').join('') +
    '</div>' +
    '<div class="cal-grid stagger">' + cells + '</div>' +
    '<div class="section-title">' + dueLabel(calSelected) + ' — ' +
      new Date(...calSelected.split('-').map((v, i) => i === 1 ? v - 1 : v))
        .toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' }) +
      (doneCount ? ' · ' + doneCount + ' done' : '') + '</div>' +
    (dayTasks.length
      ? '<div id="calDayList">' + dayTasks.map(t => taskCardHTML(state, t)).join('') + '</div>'
      : '<div class="card empty"><p>No open tasks this day. Click any task\'s ✏️ elsewhere, or drag one here.</p></div>');

  // Month navigation + day picking.
  document.getElementById('calPrev').addEventListener('click', () => {
    calMonth -= 1; if (calMonth < 0) { calMonth = 11; calYear -= 1; } render();
  });
  document.getElementById('calNext').addEventListener('click', () => {
    calMonth += 1; if (calMonth > 11) { calMonth = 0; calYear += 1; } render();
  });
  document.getElementById('calToday').addEventListener('click', () => {
    const n = new Date(); calYear = n.getFullYear(); calMonth = n.getMonth();
    calSelected = todayStr(); render();
  });
  box.querySelectorAll('[data-day]').forEach(c =>
    c.addEventListener('click', () => { calSelected = c.dataset.day; render(); }));

  // Drag a task card onto a day cell to move it there.
  box.querySelectorAll('#calDayList .task').forEach(card => {
    card.draggable = true;
    card.addEventListener('dragstart', e =>
      e.dataTransfer.setData('text/tym-task', card.dataset.card));
  });
  box.querySelectorAll('[data-day]').forEach(cell => {
    cell.addEventListener('dragover', e => e.preventDefault());
    cell.addEventListener('drop', e => {
      e.preventDefault();
      const id = e.dataTransfer.getData('text/tym-task');
      const t = findTask(state, id);
      if (t && t.due !== cell.dataset.day) {
        t.due = cell.dataset.day;
        saveState(state);
        render();
        showToast('Moved to ' + dueLabel(t.due));
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', render);
