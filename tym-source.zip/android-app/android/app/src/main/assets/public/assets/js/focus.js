'use strict';
/* ============================================================
   TYM — Track Your Mind · focus.js
   What this file does: the FOCUS screen — a Pomodoro timer
   tied to a task. Work 25 min → break 5 min. Finished work
   sessions are written to state.focusLog (Review reads it).
   Extras: rain/noise ambience (made with WebAudio, no file)
   and a full-screen mode.
   ============================================================ */

let fMode = 'work';            // 'work' | 'break'
let fWorkMin = 25, fBreakMin = 5;
let fLeft = fWorkMin * 60;     // seconds left in this round
let fRunning = false;
let fTimer = null;
let fTaskId = '';
let noiseNodes = null;         // ambience sound graph

function fmt(sec) {
  return pad2(Math.floor(sec / 60)) + ':' + pad2(sec % 60);
}

function render() {
  const box = document.getElementById('screenContent');
  const open = state.tasks.filter(t => t.status !== 'done');
  const todayLog = state.focusLog.filter(s => s.date === todayStr());
  const minsToday = todayLog.reduce((a, s) => a + s.minutes, 0);

  box.innerHTML =
    '<div class="focus-wrap card">' +
      '<div class="focus-modes">' +
        '<button class="btn' + (fMode === 'work' ? ' btn-primary' : '') + '" id="fmWork">🍅 Work ' + fWorkMin + 'm</button>' +
        '<button class="btn' + (fMode === 'break' ? ' btn-primary' : '') + '" id="fmBreak">☕ Break ' + fBreakMin + 'm</button>' +
      '</div>' +
      '<div class="focus-modes" style="margin-top:8px">' +
        [15, 25, 50].map(m =>
          '<button class="btn' + (fWorkMin === m ? ' btn-primary' : '') + '" data-fpreset="' + m + '">' + m + ' min</button>').join('') +
      '</div>' +
      '<div class="focus-clock" id="fClock">' + fmt(fLeft) + '</div>' +
      '<label style="color:var(--muted);font-size:13px;font-weight:700">Focusing on</label>' +
      '<select class="field" id="fTask" style="max-width:420px;margin:6px auto 14px">' +
        '<option value="">— no task, just focus —</option>' +
        open.map(t => '<option value="' + t.id + '"' + (t.id === fTaskId ? ' selected' : '') + '>' +
          escapeHTML(t.title) + '</option>').join('') +
      '</select>' +
      '<div class="focus-actions">' +
        '<button class="btn btn-primary" id="fToggle" style="font-size:16px;padding:12px 26px">' +
          (fRunning ? '⏸ Pause' : '▶ Start') + '</button>' +
        '<button class="btn" id="fReset">↺ Reset</button>' +
        '<button class="btn" id="fNoise">🌧 Ambience: off</button>' +
        '<button class="btn" id="fFull">⛶ Full screen</button>' +
      '</div>' +
      '<p style="color:var(--muted);margin-top:16px">Today: ' + todayLog.length +
        ' sessions · ' + minsToday + ' focus minutes</p>' +
    '</div>';

  box.querySelectorAll('[data-fpreset]').forEach(b =>
    b.addEventListener('click', () => {
      if (fRunning) { showToast('Pause first to change length'); return; }
      fWorkMin = parseInt(b.dataset.fpreset, 10);
      fBreakMin = Math.max(3, Math.round(fWorkMin / 5));
      if (fMode === 'work') fLeft = fWorkMin * 60;
      render();
    }));
  document.getElementById('fmWork').addEventListener('click', () => switchMode('work'));
  document.getElementById('fmBreak').addEventListener('click', () => switchMode('break'));
  document.getElementById('fToggle').addEventListener('click', toggleRun);
  document.getElementById('fReset').addEventListener('click', () => { stopTimer(); fLeft = (fMode === 'work' ? fWorkMin : fBreakMin) * 60; render(); });
  document.getElementById('fTask').addEventListener('change', e => { fTaskId = e.target.value; });
  document.getElementById('fNoise').addEventListener('click', toggleNoise);
  document.getElementById('fFull').addEventListener('click', () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen();
  });
}

function switchMode(mode) {
  stopTimer();
  fMode = mode;
  fLeft = (mode === 'work' ? fWorkMin : fBreakMin) * 60;
  render();
}

function stopTimer() {
  fRunning = false;
  if (fTimer) { clearInterval(fTimer); fTimer = null; }
  document.title = 'TYM · Track Your Mind';
}

function toggleRun() {
  if (fRunning) { stopTimer(); render(); return; }
  fRunning = true;
  document.getElementById('fToggle').textContent = '⏸ Pause';
  fTimer = setInterval(() => {
    fLeft -= 1;
    const clock = document.getElementById('fClock');
    if (clock) clock.textContent = fmt(fLeft);
    document.title = fmt(fLeft) + ' · TYM Focus';
    if (fLeft <= 0) roundDone();
  }, 1000);
}

/* A round finished: log work sessions, buzz, switch mode. */
function roundDone() {
  stopTimer();
  tymBuzz([200, 80, 200, 80, 400]);
  if (fMode === 'work') {
    state.focusLog.push({ date: todayStr(), minutes: fWorkMin, taskId: fTaskId || null });
    saveState(state);
    showToast('Session done 🎉 Logged ' + fWorkMin + ' focus minutes');
    fMode = 'break'; fLeft = fBreakMin * 60;
  } else {
    showToast('Break over — back to it 💪');
    fMode = 'work'; fLeft = fWorkMin * 60;
  }
  render();
}

/* Rain-like ambience: filtered noise, generated live.
   No audio file is shipped with the app. */
function toggleNoise(e) {
  if (noiseNodes) {
    noiseNodes.src.stop(); noiseNodes = null;
    e.target.textContent = '🌧 Ambience: off';
    return;
  }
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { // brown-ish noise = soft rain
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      data[i] = last * 3.2;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf; src.loop = true;
    const gain = ctx.createGain(); gain.gain.value = 0.16;
    src.connect(gain); gain.connect(ctx.destination);
    src.start();
    noiseNodes = { src, ctx };
    e.target.textContent = '🌧 Ambience: on';
  } catch (err) { showToast('Ambience is not available here'); }
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', () => { if (!fRunning) render(); });
