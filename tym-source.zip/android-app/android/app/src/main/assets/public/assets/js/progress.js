'use strict';
/* ============================================================
   TYM — Track Your Mind · progress.js
   What this file does: PROGRESS MATH as pure functions —
   habit streaks, longest streak, last-N-days lists, week
   summaries. Used by the Habits and Review screens.
   Needs dates.js loaded before it.
   ============================================================ */

/* Date strings for the last n days, oldest first. */
function lastNDays(n, now) {
  const today = todayStr(now);
  const out = [];
  for (let i = n - 1; i >= 0; i--) out.push(addDaysStr(today, -i));
  return out;
}

/* Current streak of one habit. log = { 'YYYY-MM-DD': true }.
   A streak survives "today not done yet" — it breaks only
   when a full day passes with no tick. */
function habitStreak(log, now) {
  let streak = 0;
  let cursor = todayStr(now);
  if (!log[cursor]) cursor = addDaysStr(cursor, -1);
  while (log[cursor]) { streak += 1; cursor = addDaysStr(cursor, -1); }
  return streak;
}

/* Longest run of consecutive days with count > 0 in a
   { dateStr: count } map (used for task completions). */
function longestStreak(dayCounts) {
  const days = Object.keys(dayCounts).filter(d => dayCounts[d] > 0).sort();
  let best = 0, run = 0, prev = null;
  for (const d of days) {
    run = (prev && addDaysStr(prev, 1) === d) ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return best;
}

/* Completions for the last 7 days: [{ date, count }]. */
function weekSummary(completions, now) {
  return lastNDays(7, now).map(date => ({
    date, count: completions[date] || 0
  }));
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { lastNDays, habitStreak, longestStreak, weekSummary };
}
