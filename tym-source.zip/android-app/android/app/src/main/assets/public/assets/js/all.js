'use strict';
/* ============================================================
   TYM — Track Your Mind · all.js
   What this file does: the ALL TASKS screen — every open
   task with search, a sort picker, and a list filter.
   Card clicks are handled in editor.js (shared pattern).
   Drag-to-reorder works when sort = "My order".
   ============================================================ */

let allQuery = '';       // current search text
let allList = 'all';     // current list filter ('all' or a list id)
let allSort = 'group';   // 'group' = sections by when; else a sortTasks mode

function render() {
  const box = document.getElementById('screenContent');
  let tasks = state.tasks.filter(isOpenTask);
  if (allList !== 'all') tasks = tasks.filter(t => t.listId === allList);
  tasks = searchTasks(tasks, allQuery);
  const grouped = allSort === 'group' && !allQuery;
  if (!grouped) tasks = sortTasks(tasks, allSort);

  // List filter chips, built from the state's lists.
  const chips = ['<button class="btn' + (allList === 'all' ? ' btn-primary' : '') +
    '" data-list="all">All lists</button>'].concat(
    state.lists.map(l => '<button class="btn' + (allList === l.id ? ' btn-primary' : '') +
      '" data-list="' + l.id + '">' + escapeHTML(l.name) + '</button>')).join(' ');
  document.getElementById('listChips').innerHTML = chips;

  if (!tasks.length) {
    box.innerHTML = '<div class="card empty"><div class="empty-art">🗂️</div>' +
      '<p>' + (allQuery ? 'No tasks match your search.' : 'No open tasks here.') + '</p></div>';
    return;
  }
  if (grouped) {
    // Sections by WHEN: overdue, today, tomorrow, this week, later, no date.
    const now = new Date();
    const today = todayStr(now);
    const buckets = [
      { name: '⚠️ Overdue', items: tasks.filter(t => isOverdueTask(t, now)) },
      { name: '📅 Today', items: tasks.filter(t => t.due === today && !isOverdueTask(t, now)) },
      { name: '🌅 Tomorrow', items: tasks.filter(t => t.due === addDaysStr(today, 1)) },
      { name: '🗓 This week', items: tasks.filter(t => t.due && t.due > addDaysStr(today, 1) && t.due <= addDaysStr(today, 7)) },
      { name: '🔭 Later', items: tasks.filter(t => t.due && t.due > addDaysStr(today, 7)) },
      { name: '📥 No date', items: tasks.filter(t => !t.due) }
    ];
    box.innerHTML = buckets.filter(b => b.items.length).map(b =>
      '<div class="section-title">' + b.name + ' · ' + b.items.length + '</div>' +
      '<div class="stagger">' + sortTasks(b.items, 'due').map(t => taskCardHTML(state, t)).join('') + '</div>'
    ).join('') || '<div class="card empty"><p>Nothing here.</p></div>';
    return;
  }
  box.innerHTML = '<div class="stagger">' +
    tasks.map(t => taskCardHTML(state, t)).join('') + '</div>';

  // Drag to reorder — only meaningful in "My order" sort.
  if (allSort === 'manual' && !allQuery) {
    box.querySelectorAll('.task').forEach(card => {
      card.draggable = true;
      card.addEventListener('dragstart', () => { card.classList.add('dragging'); });
      card.addEventListener('dragend', () => {
        card.classList.remove('dragging');
        // Save the new order from the card positions on screen.
        const ids = Array.from(box.querySelectorAll('.task')).map(c => c.dataset.card);
        ids.forEach((id, i) => { const t = findTask(state, id); if (t) t.order = i + 1; });
        saveState(state);
      });
      card.addEventListener('dragover', e => {
        e.preventDefault();
        const dragging = box.querySelector('.dragging');
        if (!dragging || dragging === card) return;
        const rect = card.getBoundingClientRect();
        const after = (e.clientY - rect.top) > rect.height / 2;
        card.parentNode.insertBefore(dragging, after ? card.nextSibling : card);
      });
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  render();
  document.getElementById('searchInput').addEventListener('input', e => {
    allQuery = e.target.value; render();
  });
  document.getElementById('sortSel').addEventListener('change', e => {
    allSort = e.target.value; render();
  });
  document.getElementById('listChips').addEventListener('click', e => {
    const b = e.target.closest('[data-list]');
    if (b) { allList = b.dataset.list; render(); }
  });
  document.getElementById('newTaskBtn').addEventListener('click', () => openTaskEditor(null));
});

document.addEventListener('tym:changed', render);
