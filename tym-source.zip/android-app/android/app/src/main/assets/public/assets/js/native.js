'use strict';
/* ============================================================
   TYM — Track Your Mind · native.js
   What this file does: the ONLY file that talks to the
   phone. Inside the Android app (Capacitor) it schedules
   real notifications that fire even when TYM is closed.
   In a plain browser it does nothing — the browser alarm
   engine in reminders.js handles that case.
   ============================================================ */

/* Are we running inside the wrapped mobile app? */
function tymInApp() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform &&
    window.Capacitor.isNativePlatform());
}

/* Ask the phone for notification permission (app only). */
async function tymRequestNotifyPermission() {
  if (!tymInApp()) return false;
  try {
    const LN = window.Capacitor.Plugins.LocalNotifications;
    const res = await LN.requestPermissions();
    return res.display === 'granted';
  } catch (e) { return false; }
}

/* Schedule one phone notification. id must be a number. */
async function tymScheduleNotification(id, title, body, atMs) {
  if (!tymInApp()) return false;
  try {
    const LN = window.Capacitor.Plugins.LocalNotifications;
    await LN.schedule({ notifications: [{ id, title, body, schedule: { at: new Date(atMs), allowWhileIdle: true } }] });
    return true;
  } catch (e) { return false; }
}

/* Short vibration — alarm and button feedback on phones. */
function tymBuzz(pattern) {
  try { if (navigator.vibrate) navigator.vibrate(pattern || 200); } catch (e) { /* no vibrate */ }
}

/* ---------- voice input through Android (v2.3) ----------
   The browser's speech recognition does not exist inside
   the app WebView, so the app uses the phone's own speech
   engine (SpeechRecognition plugin). Resolves true when the
   native path handled the tap (success or error toast),
   false in a browser, where the web path runs instead. */
function tymVoiceInput(onText) {
  const SR = tymInApp() && window.Capacitor.Plugins.SpeechRecognition;
  if (!SR) return Promise.resolve(false);
  const ask = SR.requestPermissions ? SR.requestPermissions()
    : (SR.requestPermission ? SR.requestPermission() : Promise.resolve(null));
  return Promise.resolve(ask)
    .then(perm => {
      if (perm && perm.speechRecognition && perm.speechRecognition !== 'granted') {
        throw new Error('permission');
      }
      showToast('🎙 Listening… speak your task');
      return SR.start({ language: 'en-IN', maxResults: 1, partialResults: false, popup: false });
    })
    .then(res => {
      if (res && res.matches && res.matches[0]) onText(res.matches[0]);
      return true;
    })
    .catch(() => { showToast('Voice not available — allow mic permission and try again'); return true; });
}

/* ---------- save a file inside the app (v2.3) ----------
   Blob downloads do nothing inside the app WebView, so in
   the app the file is written and handed to the Android
   share sheet (save it, send it, keep it). Resolves false
   in a browser, where the normal download runs instead. */
function tymSaveAndShare(filename, text) {
  if (!tymInApp()) return Promise.resolve(false);
  const FS = window.Capacitor.Plugins.Filesystem;
  const SH = window.Capacitor.Plugins.Share;
  if (!FS || !SH) return Promise.resolve(false);
  return FS.writeFile({ path: filename, data: text, directory: 'CACHE', encoding: 'utf8' })
    .then(w => SH.share({ title: filename, url: w.uri, dialogTitle: 'Save ' + filename }))
    .then(() => true)
    .catch(() => false);
}
