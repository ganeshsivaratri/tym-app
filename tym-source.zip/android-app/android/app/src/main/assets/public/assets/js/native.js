'use strict';
/* ============================================================
   TYM — Track Your Mind · native.js
   What this file does: the ONLY file that talks to the
   phone. Inside the Android app (Capacitor) it schedules
   real notifications that fire even when TYM is closed.
   In a plain browser it does nothing — the browser alarm
   engine in reminders.js handles that case.
   ============================================================ */

/* Are we running inside the wrapped mobile app? */
function tymInApp() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform &&
    window.Capacitor.isNativePlatform());
}

/* Ask the phone for notification permission (app only). */
async function tymRequestNotifyPermission() {
  if (!tymInApp()) return false;
  try {
    const LN = window.Capacitor.Plugins.LocalNotifications;
    const res = await LN.requestPermissions();
    return res.display === 'granted';
  } catch (e) { return false; }
}

/* Schedule one phone notification. id must be a number. */
async function tymScheduleNotification(id, title, body, atMs) {
  if (!tymInApp()) return false;
  try {
    const LN = window.Capacitor.Plugins.LocalNotifications;
    await LN.schedule({ notifications: [{ id, title, body, schedule: { at: new Date(atMs), allowWhileIdle: true } }] });
    return true;
  } catch (e) { return false; }
}

/* Short vibration — alarm and button feedback on phones. */
function tymBuzz(pattern) {
  try { if (navigator.vibrate) navigator.vibrate(pattern || 200); } catch (e) { /* no vibrate */ }
}
