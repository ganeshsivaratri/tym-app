'use strict';
/* ============================================================
   TYM — Track Your Mind · study.js
   What this file does: the STUDY screen — subjects with
   chapters, and a progress % per subject.
   Spaced revision: when you tick a chapter done, TYM
   auto-creates a "Revise: <chapter>" task due in 3 days
   (the forgetting curve is real — one review beats it).
   Subjects live in state.subjects:
   [{ id, name, chapters: [{ id, title, done }] }]
   ============================================================ */

function subjectPct(s) {
  if (!s.chapters.length) return 0;
  return Math.round(s.chapters.filter(c => c.done).length / s.chapters.length * 100);
}

function render() {
  const box = document.getElementById('screenContent');
  const overall = state.subjects.length
    ? Math.round(state.subjects.reduce((a, s) => a + subjectPct(s), 0) / state.subjects.length)
    : 0;

  box.innerHTML =
    '<div class="toolbar"><input class="field" id="subjInput" type="text" placeholder="New subject — e.g. Operating Systems">' +
    '<button class="btn btn-primary" id="subjAdd">Add subject</button>' +
    (state.subjects.length ? '<span class="pill" style="align-self:center">Overall: ' + overall + '%</span>' : '') +
    '</div>' +
    (state.subjects.length ? '' :
      '<div class="card empty"><div class="empty-art">📚</div><p>No subjects yet. Add your first subject above, then its chapters.</p></div>') +
    state.subjects.map(s =>
      '<div class="card" style="margin-bottom:12px">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px">' +
          '<h2 style="margin:0">' + escapeHTML(s.name) + '</h2>' +
          '<span><span class="badge">' + subjectPct(s) + '% · ' +
            s.chapters.filter(c => c.done).length + '/' + s.chapters.length + ' chapters</span> ' +
          '<button class="icon-btn" data-subj-del="' + s.id + '">🗑</button></span>' +
        '</div>' +
        '<div class="progress" style="margin:10px 0"><div style="width:' + subjectPct(s) + '%"></div></div>' +
        s.chapters.map(c =>
          '<label class="sub"><input type="checkbox" data-chapter="' + c.id + '" data-subject="' + s.id + '"' +
          (c.done ? ' checked' : '') + '> <span class="' + (c.done ? 'sub-done' : '') + '">' +
          escapeHTML(c.title) + '</span></label>').join('') +
        '<div class="toolbar" style="margin:10px 0 0">' +
          '<input class="field" type="text" placeholder="Add a chapter…" data-chapter-input="' + s.id + '">' +
          '<button class="btn" data-chapter-add="' + s.id + '">Add chapter</button>' +
        '</div>' +
      '</div>').join('');

  document.getElementById('subjAdd').addEventListener('click', () => {
    const v = document.getElementById('subjInput').value.trim();
    if (!v) return;
    state.subjects.push({ id: makeId(), name: v, chapters: [] });
    saveState(state);
    render();
  });
}

document.addEventListener('click', e => {
  const add = e.target.closest('[data-chapter-add]');
  if (add) {
    const sid = add.dataset.chapterAdd;
    const input = document.querySelector('[data-chapter-input="' + sid + '"]');
    const v = input.value.trim();
    if (!v) return;
    const s = state.subjects.find(x => x.id === sid);
    s.chapters.push({ id: makeId(), title: v, done: false });
    saveState(state);
    render();
    return;
  }
  const del = e.target.closest('[data-subj-del]');
  if (del) {
    state.subjects = state.subjects.filter(x => x.id !== del.dataset.subjDel);
    saveState(state);
    render();
  }
});

document.addEventListener('change', e => {
  const cb = e.target.closest('[data-chapter]');
  if (!cb) return;
  const s = state.subjects.find(x => x.id === cb.dataset.subject);
  const c = s && s.chapters.find(x => x.id === cb.dataset.chapter);
  if (!c) return;
  c.done = cb.checked;
  saveState(state);
  render();
  // Spaced revision: a finished chapter gets a +3 day review task.
  if (c.done) {
    addTaskToState(state, {
      title: 'Revise: ' + c.title + ' (' + s.name + ')',
      due: addDaysStr(todayStr(), 3), listId: 'study',
      priority: 'med', tags: ['revision']
    });
    saveState(state);
    showToast('Chapter done 🎉 Revision task set for +3 days');
  }
});

document.addEventListener('DOMContentLoaded', render);
