'use strict';
/* ============================================================
   TYM — Track Your Mind · md.js
   What this file does: a TINY Markdown renderer for task
   notes. Supports **bold**, *italic*, `code`, - lists and
   lines. The text is HTML-escaped FIRST, so notes can never
   inject markup — only our own formatting is added after.
   ============================================================ */

function mdRender(text) {
  const esc = escapeHTML(text || '');
  return esc.split('\n').map(line => {
    let l = line
      .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
      .replace(/\*([^*]+)\*/g, '<i>$1</i>')
      .replace(/`([^`]+)`/g, '<code>$1</code>');
    if (/^\s*-\s+/.test(l)) l = '• ' + l.replace(/^\s*-\s+/, '');
    return l;
  }).join('<br>');
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { mdRender };
}
