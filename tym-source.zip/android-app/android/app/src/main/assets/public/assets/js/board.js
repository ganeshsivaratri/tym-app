'use strict';
/* ============================================================
   TYM — Track Your Mind · board.js
   What this file does: the BOARD screen — Kanban columns
   To do / Doing / Done. Drag a card to another column to
   move it. Dropping into Done completes the task properly
   (via tasks.js, so streaks and repeats still work).
   ============================================================ */

const BOARD_COLS = [
  { id: 'todo', name: 'To do', icon: '📝' },
  { id: 'doing', name: 'Doing', icon: '🚧' },
  { id: 'done', name: 'Done', icon: '✅' }
];

/* A small card for the board (the full card lives on the
   Today/All screens — the board stays light to drag). */
function boardCardHTML(t) {
  return '<div class="board-card" draggable="true" data-bcard="' + t.id + '">' +
    '<div class="board-card-title">' + escapeHTML(t.title) + '</div>' +
    '<div class="task-meta">' +
      '<span class="pill prio-' + t.priority + '">' + t.priority + '</span>' +
      (t.due ? '<span class="pill">' + dueLabel(t.due) + '</span>' : '') +
      '<button class="icon-btn" data-edit="' + t.id + '">✏️</button>' +
    '</div></div>';
}

function render() {
  const box = document.getElementById('screenContent');
  box.innerHTML = '<div class="board stagger">' + BOARD_COLS.map(col => {
    const tasks = sortTasks(state.tasks.filter(t => t.status === col.id), 'priority');
    return '<div class="board-col" data-col="' + col.id + '">' +
      '<h3>' + col.icon + ' ' + col.name + ' <span class="badge">' + tasks.length + '</span></h3>' +
      (tasks.map(boardCardHTML).join('') ||
        '<p class="board-empty">Drop tasks here</p>') +
      '</div>';
  }).join('') + '</div>';

  // Drag between columns.
  box.querySelectorAll('[data-bcard]').forEach(card => {
    card.addEventListener('dragstart', e =>
      e.dataTransfer.setData('text/tym-task', card.dataset.bcard));
  });
  box.querySelectorAll('[data-col]').forEach(col => {
    col.addEventListener('dragover', e => { e.preventDefault(); col.classList.add('dragover'); });
    col.addEventListener('dragleave', () => col.classList.remove('dragover'));
    col.addEventListener('drop', e => {
      e.preventDefault();
      col.classList.remove('dragover');
      const id = e.dataTransfer.getData('text/tym-task');
      const t = findTask(state, id);
      if (!t || t.status === col.dataset.col) return;
      if (col.dataset.col === 'done') setTaskDone(state, id, true, new Date());
      else if (t.status === 'done') { setTaskDone(state, id, false, new Date()); t.status = col.dataset.col; }
      else t.status = col.dataset.col;
      saveState(state);
      render();
    });
  });
}

document.addEventListener('DOMContentLoaded', render);
document.addEventListener('tym:changed', render);
