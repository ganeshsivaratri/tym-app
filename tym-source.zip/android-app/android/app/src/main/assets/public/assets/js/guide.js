'use strict';
/* ============================================================
   TYM — Track Your Mind · guide.js
   What this file does: the Guide screen. Every feature in
   simple words, one small example each, and a button that
   opens that feature. Written for a first-time user.
   ============================================================ */

const GUIDE = [
  { icon: '🧠', name: 'How TYM works', file: null,
    what: '1. You write the task. 2. The app reminds you at the time. 3. You do it.',
    ex: 'That is all. The app is your memory — you only do the work.' },
  { icon: '☀️', name: 'Today', file: 'index.html',
    what: 'Your day on one screen: today\'s tasks, your Top 3, and your progress ring.',
    ex: 'Open it every morning. You will know what today is.' },
  { icon: '✍️', name: 'Quick add', file: 'index.html',
    what: 'Type the task in simple words. The app understands date, time and priority.',
    ex: 'Type: Pay fees tomorrow 5pm !high — date, time, priority set automatically.' },
  { icon: '📌', name: 'Top 3 (My Day)', file: 'index.html',
    what: 'Pin only 3 tasks. These are today\'s most important work.',
    ex: 'Exam week: 1) Revise Unit 3  2) Print hall ticket  3) Sleep early.' },
  { icon: '⏰', name: 'Reminder + Alarm', file: 'index.html',
    what: 'Open a task → Edit → Reminders. At the time, the app rings like an alarm.',
    ex: 'Task "Print hall ticket" at 3 PM — the app rings at 3 PM. You cannot forget.' },
  { icon: '🔁', name: 'Repeat tasks', file: 'index.html',
    what: 'In Edit → Repeat: daily, weekdays, weekly. The task comes back itself.',
    ex: '"Pay hostel fee" every month — no need to write it again.' },
  { icon: '🗂', name: 'All Tasks', file: 'all.html',
    what: 'Every open task, in groups: Overdue, Today, Tomorrow, This week, Later.',
    ex: 'Too many tasks in your head? See all of them here, in order.' },
  { icon: '📅', name: 'Calendar', file: 'calendar.html',
    what: 'The whole month. Drag a task to another day to change its date.',
    ex: 'Exam postponed? Drag the revision task to the new day.' },
  { icon: '🕐', name: 'Plan My Day (Timeline)', file: 'timeline.html',
    what: 'Press "Plan My Day" — the app arranges today\'s tasks hour by hour.',
    ex: 'No plan for today? One press — full day plan ready.' },
  { icon: '🍅', name: 'Focus', file: 'focus.html',
    what: 'Pick a task, press Start. 25 minutes only work — phone away. The app counts your focus time.',
    ex: 'Studying Physics? Focus 25 min × 4 = 100 minutes of real study, counted.' },
  { icon: '🔥', name: 'Habits', file: 'habits.html',
    what: 'Small daily things. Tick every day — your streak grows. Do not break the streak.',
    ex: '"Read 10 pages" — tick daily. Day 5 streak feels too good to break.' },
  { icon: '📚', name: 'Study', file: 'study.html',
    what: 'Add subject + chapters. Finish a chapter — after 3 days the app reminds you: revise it.',
    ex: 'OS Unit 3 done today → on day 3, a "Revise Unit 3" task comes itself.' },
  { icon: '⏳', name: 'Exams', file: 'exams.html',
    what: 'Add the exam date. The app shows days left. Press "Create revision plan" — revision tasks come for 7, 3 and 1 days before.',
    ex: 'Physics exam 15 Nov → tasks on 8, 12 and 14 Nov, automatically.' },
  { icon: '📊', name: 'Review + XP', file: 'review.html',
    what: 'See your week: tasks done, focus minutes, habit dots, and your XP level.',
    ex: 'XP grows with every finished task: Starter → Builder → Legend.' },
  { icon: '👉', name: 'Swipe', file: null,
    what: 'On any task card: swipe right = done. Swipe left = delete (Undo comes, do not worry).',
    ex: 'Fast way to clear finished tasks on the phone.' },
  { icon: '💾', name: 'Backup (important)', file: 'settings.html',
    what: 'Settings → Export backup saves all your data in one file. Do it every week.',
    ex: 'Phone changed? Import the file — all your tasks come back.' },
  { icon: '🌱', name: 'Sample day', file: 'settings.html',
    what: 'Settings → "Load sample day" fills the app with demo tasks, so you can try every screen.',
    ex: 'Best way to learn the app in 2 minutes. Remove it any time in Settings.' }
];

function render() {
  const box = document.getElementById('screenContent');
  box.innerHTML = '<div class="stagger">' + GUIDE.map(g =>
    '<div class="card" style="margin-bottom:12px">' +
      '<h2>' + g.icon + ' ' + g.name + '</h2>' +
      '<p style="margin:6px 0">' + g.what + '</p>' +
      '<p style="color:var(--muted);margin:6px 0">💡 ' + g.ex + '</p>' +
      (g.file ? '<a class="btn" href="' + g.file + '" data-goto="' + g.file + '">Open →</a>' : '') +
    '</div>').join('') + '</div>';
}
document.addEventListener('DOMContentLoaded', render);
