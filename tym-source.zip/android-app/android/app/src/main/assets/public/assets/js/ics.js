'use strict';
/* ============================================================
   TYM — Track Your Mind · ics.js
   What this file does: builds an .ics calendar file from
   tasks that have a due date, so the user can import their
   plan into Google Calendar / any calendar app.
   Reminders become calendar alarms (VALARM).
   Pure string building — the Node tests check it.
   ============================================================ */

function icsEscape(text) {
  return String(text || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;')
    .replace(/,/g, '\\,').replace(/\n/g, '\\n');
}

/* 'YYYY-MM-DD' + 'HH:MM' -> 'YYYYMMDDTHHMMSS' (floating local time) */
function icsDateTime(due, time) {
  return due.replace(/-/g, '') + 'T' + (time || '09:00').replace(':', '') + '00';
}

function buildICS(tasks) {
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//TYM//Track Your Mind//EN'];
  for (const t of tasks) {
    if (!t.due) continue;
    lines.push('BEGIN:VEVENT');
    lines.push('UID:' + t.id + '@tym');
    lines.push('DTSTART:' + icsDateTime(t.due, t.time));
    lines.push('SUMMARY:' + icsEscape(t.title));
    if (t.notes) lines.push('DESCRIPTION:' + icsEscape(t.notes));
    for (const min of (t.reminders || [])) {
      lines.push('BEGIN:VALARM', 'ACTION:DISPLAY',
        'TRIGGER:-PT' + min + 'M', 'DESCRIPTION:' + icsEscape(t.title), 'END:VALARM');
    }
    lines.push('END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { buildICS, icsEscape, icsDateTime };
}
