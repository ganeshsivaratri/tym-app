# Building the TYM Android app (APK)

The Android project is READY in this folder — Capacitor is set up,
the web app is synced in, and the Local Notifications plugin (real
alarms with the app closed) is registered. What remains is the
one-time compile, which needs Android Studio (free) on the Mac.
This VM has no Android SDK, so the APK itself is built there.

## One-time setup (Mac)
1. Install **Android Studio** from https://developer.android.com/studio
   (free; it installs the Android SDK with it).
2. Copy this whole `android-app` folder to the Mac.

## Build the APK
1. Open Android Studio → **Open** → select the `android-app/android` folder.
   Wait for the first Gradle sync to finish (needs internet once).
2. (Optional, branding) Replace the app icon: right-click `app` →
   **New → Image Asset** → pick `../www/assets/icons/icon-512.png`.
3. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. When done, click **locate** — the file is
   `android/app/build/outputs/apk/debug/app-debug.apk`.

## Install on your phone
1. Copy the APK to the phone (USB / WhatsApp-to-self / Drive).
2. Tap it → allow "install from this source" once → Install.
3. Open **TYM**. Add a task with a reminder 2 minutes ahead,
   close the app fully, and wait — the phone notification must
   arrive. That is the Stage 8 acceptance test.

## After changing the web app
Run `npm run sync` in this folder, then rebuild the APK (step 2 above).

## Later (only if wanted)
- A signed release build + Play Store listing needs a Google Play
  developer account: one-time $25. Not needed to use/share the APK.
