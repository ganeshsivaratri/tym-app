// ==========================================
// FILE: vite.config.js
// WHAT: Build settings for Vite.
// It takes the React code and makes the
// final website files in the dist/ folder.
// ==========================================
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Relative paths, so the app works on GitHub Pages
  // and inside the phone app (Capacitor) too.
  base: './'
});
