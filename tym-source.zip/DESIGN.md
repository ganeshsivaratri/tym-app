# TYM — Track Your Mind · DESIGN DOCUMENT (v2, 2026-11-08)

Status: DESIGN ONLY — user said "dont build the app yet" (2026-11-08).
v2 changes (user, 2026-11-08): v1 felt "noob" → high-quality features added,
look upgraded to impressive/modern/animated; **Trader pack REMOVED for now —
build for traders LATER** (parked at the bottom of this doc); code style rule
added: every file simple, divided, and commented so the user can read and
change the code himself.
Brand: **TYM — Track Your Mind**. Standalone product. No other brand names
anywhere in the app, screens, or copy.
Goal: the best to-do list app — for everyday work and students.

## PLATFORM (user decided 2026-11-08: "i want a mobile app")
TYM is a **mobile app — Android first.**
- The app is built as a clean web core (HTML/CSS/JS, the divided codebase
  below) and wrapped with **Capacitor** into a real Android app (APK).
  Same code, two doors: test in a browser, run as a real app on the phone.
- Why this route: it keeps HIS codebase style (simple, divided, commented,
  files he can read and fix himself) AND unlocks real phone powers a pure
  web page cannot do — **true alarms that ring even when the app is closed,
  background reminders, home-screen presence.**
- iOS: later. It needs the Apple developer fee ($99/year) for the App Store;
  Android direct-APK sharing costs ₹0.
- Play Store: optional, later. Publishing needs a one-time $25 developer
  fee — only if/when the user approves spend. Until then the APK is
  shared directly (zero investment rule holds).
- Native bridge: one small file, `native.js`, is the ONLY place that talks
  to phone features (notifications, alarm, haptics). Everything else stays
  plain web code. If a feature works in the browser, it works in the app.
Codebase style: same divided, structured style as his SXC website —
static HTML/CSS/JS, no framework, no build step; one file per screen;
shared assets; data separated from logic; page-specific JS per screen.

---

## 1. FEATURES

### Core tasks (the base)
- C1 Quick add (one line, Enter) + full task editor
- C2 Subtasks with progress bar
- C3 Priorities (High / Medium / Low)
- C4 Lists (custom, colour-coded)
- C5 Notes on tasks
- C6 Search, sort (due / priority / newest / my order), drag to reorder
- C7 Dark / light theme
- C8 Backup export / import (JSON)
- C9 Stats: done today, day streak, open count

### Reminders & time (the #1 reason users stay)
- F1 Multiple reminders per task (at time · 30 min before · 1 day before · custom)
- F2 Alarm mode — keeps ringing until the task is marked done
- F3 Snooze — 10 min / 1 hour / tomorrow
- F4 Natural-language add — "assignment tomorrow 5pm, every Monday"
- F5 Voice input for quick add
- F6 Calendar views — day / week / month
- F7 Time blocking — start + end time per task, shown on the day timeline
- F8 Pomodoro focus timer, tied to a task, sessions counted
- F9 Countdowns — "exam in 12 days" cards

### Task power
- F10 Nested subtasks (subtask inside subtask)
- F11 Tags / labels + filter by tag
- F12 Photo / file attachments on tasks
- F13 Custom repeat rules — every 2 weeks, first Monday, repeat from completion day
- F14 Task templates (one tap to reuse a structure)
- F15 Duplicate task
- F16 Multi-select batch actions (complete / delete / move list / set priority)

### Views
- F17 Kanban board view (To do → Doing → Done columns, drag cards)
- F18 Eisenhower matrix (Urgent × Important, 4 boxes)
- F19 Day timeline planner (hour-by-hour schedule of the day)
- F20 Saved smart filters (my own views, saved)
- F21 Archive (done long ago, hidden but kept)

### Everyday
- F22 Habit tracker with per-habit streaks
- F23 Daily routines — a routine list that resets fresh every morning
- F24 My Day — Top-3 focus, pinned at the top of Today

### Students
- F25 Subjects & chapters — per-subject % progress
- F26 Exam countdown per subject (days left vs chapters left)
- F27 Spaced revision — finished chapters return after 3 / 7 days
- F28 Weekly timetable (class schedule grid)

### High-quality / Pro (v2 — what makes it not feel "noob")
- Q1 **Plan My Day** — one tap: the app arranges today's tasks into the
  timeline by priority, due time, and duration (rule-based auto-planning)
- Q2 **"What can I do now?"** — smart filter: give it your free minutes +
  energy (high/low) → it shows only matching tasks
- Q3 **Command palette (Ctrl+K)** — keyboard-first: jump anywhere, add a
  task, run any action without touching the mouse
- Q4 **Full keyboard shortcuts** — j/k move, Enter open, e edit, x done, ? shows all
- Q5 **Undo everywhere** — every delete/complete shows a toast with Undo
- Q6 **Review screen** — week graph (tasks done per day), focus minutes,
  GitHub-style **year heatmap** of completions, habit heatmap
- Q7 **Rich notes** — Markdown in task notes (bold, lists, links), rendered clean
- Q8 **Time estimates** — each task/subtask can carry minutes; task shows
  total; Today shows "≈ X hrs planned"
- Q9 **Calendar drag-reschedule** — drag a task onto a new date in Calendar
- Q10 **Focus ambience** — Pomodoro with optional white-noise/rain sound,
  full-screen calm mode
- Q11 **Day Complete ritual** — finishing Today triggers a small celebration
  + end-of-day review prompt (what got done, what moves to tomorrow)
- Q12 **Installable PWA** — add to phone home screen, works fully offline,
  own icon (same manifest pattern as the SXC site)
- Q13 **Import** — bring tasks in from a CSV (Todoist/TickTick exports)
- Q14 **Print my day** — clean printable day plan

### PARKED — Traders (user: "we later build for them", 2026-11-08)
- P1 Daily-reset checklists — pre-market / post-market, fresh daily
- P2 Trade journal — entry/exit/qty → auto P&L, day P&L, win rate, max-loss guard
Not in any screen or stage below. Reopen only when the user says so.

---

## 2. SCREENS TO DEVELOP

One HTML file per screen (SXC style). Shared sidebar (desktop) / bottom bar (mobile).

| # | Screen | File | Holds |
|---|--------|------|-------|
| S1 | Today | index.html | My Day Top-3, today's tasks, overdue strip, day progress ring |
| S2 | All Tasks | all.html | every open task, filters, batch select |
| S3 | Calendar | calendar.html | month grid + day/week toggle, tasks on dates |
| S4 | Board | board.html | Kanban columns, drag cards |
| S5 | Matrix | matrix.html | Eisenhower 4 boxes, drag between boxes |
| S6 | Timeline | timeline.html | today's hour-by-hour blocks, Pomodoro start |
| S7 | Habits | habits.html | habit cards, streaks, routine checklists (daily reset) |
| S8 | Focus | focus.html | big Pomodoro ring, current task, session log |
| S9 | Study | study.html | subjects, chapter checklists, % bars |
| S10 | Exams | exams.html | countdown cards, revision-due list |
| S11 | Timetable | timetable.html | weekly class grid |
| S12 | Review | review.html | week graph, year heatmap, focus minutes, habit heatmap |
| S13 | Completed | completed.html | done history, archive, clear |
| S14 | Settings | settings.html | theme, lists manager, tags manager, shortcuts list, backup export/import, CSV import |

Global (on every screen): Command palette (Ctrl+K), Quick Add bar, Undo toast.
Popups (not full screens): Task Editor modal, Alarm popup
(full-screen ringing view with Done / Snooze buttons).

---

## 3. DEVELOPMENT PLAN — STAGE WISE

Build only after the user says "build". One stage at a time; each stage is
tested before the next starts (Node logic tests + local serve + HTTP check,
same method as the base app).

- **Stage 0 — Skeleton.** Folder structure, shared CSS design system,
  store.js (state load/save), navigation shell on all 14 screens (empty states).
  Done when: every screen opens, nav works, theme toggles, no 404s.
- **Stage 1 — Core tasks.** S1 + S2 + editor modal: add/edit/delete, subtasks,
  priorities, lists, search, sort, drag reorder, stats.
  Done when: the 9 base logic tests pass + editor round-trip test.
- **Stage 2 — Reminders & Alarm.** F1–F5: multiple reminders, alarm mode,
  snooze, natural-language add, voice input.
  Done when: reminder-time math tests pass; a 1-minute test alarm rings,
  snoozes, and stops on Done.
- **Stage 3 — Time views.** S3 + S6 + F6–F9 + Q1 + Q9: calendar (with drag-
  reschedule), timeline, time blocking, Pomodoro (S8), countdowns, Plan My Day.
  Done when: calendar places tasks on the right dates in tests; Plan My Day
  orders a sample day correctly; timer logs a session.
- **Stage 4 — Power & views.** F10–F21 + Q3 + Q4 + Q5: nested subtasks, tags,
  attachments, custom repeats, templates, duplicate, batch actions, board,
  matrix, smart filters, archive, command palette, shortcuts, undo.
  Done when: repeat-rule tests (2-week, first-Monday, from-completion) pass;
  every destructive action can be undone in a click-through test.
- **Stage 5 — Everyday + Review.** S7 + S12 + F22–F24 + Q6: habits, streaks,
  daily-reset routines, My Day, Review screen with graphs + heatmaps.
  Done when: simulated-date tests — routine resets at midnight, streak breaks
  on a missed day; heatmap cell counts match completion data.
- **Stage 6 — Students.** S9 + S10 + S11 + F25–F28.
  Done when: chapter % math, countdown math, revision (+3/+7 day) tests pass.
- **Stage 7 — Quality pass.** Q7 rich notes, Q8 estimates, Q10 focus ambience,
  Q11 day-complete ritual, Q12 PWA install, Q13 CSV import, Q14 print.
  Motion pass (see §4 design direction) + reduced-motion support.
  Done when: CSV sample from a real TickTick export imports without loss.
- **Stage 8 — Mobile app wrap (Android).** Capacitor wrap of the finished web
  core; native.js wired to real phone notifications + alarms; app icon +
  splash; APK built and installed on the user's own phone.
  Done when: the APK installs and opens on his phone; a test alarm rings at
  the set time with the app fully closed; reminders fire in the background.
- **Stage 9 — Final QA.** Empty states, full click-through on every screen
  (in the app, on the phone), BUILD-SUMMARY.md with honest limits.
  Done when: every screen passes the audit; summary written.

---

## 4. ARCHITECTURE PLAN

### Folder structure (SXC style — divided, one job per file)
```
tym/
  DESIGN.md            ← this file
  PLAN.md              ← written at build start (stage checklist)
  BUILD-SUMMARY.md     ← written at the end (verification, honest limits)
  index.html           ← S1 Today
  all.html  calendar.html  board.html  matrix.html  timeline.html
  habits.html  focus.html  study.html  exams.html  timetable.html
  review.html  completed.html  settings.html
  404.html
  site.webmanifest     ← PWA install (Q12)
  assets/
    css/
      styles.css       ← shared design system (theme, layout, components, motion)
    js/
      data.js          ← default data: starter lists, routine templates
      store.js         ← state: load/save (localStorage), migrations, backup in/out
      dates.js         ← all date math (repeat rules, countdowns, revision timing)
      plan.js          ← Plan My Day + "What can I do now?" logic (pure, testable)
      reminders.js     ← reminder scheduling, alarm loop, snooze
      parse.js         ← natural-language quick-add parser
      native.js        ← ONLY file that talks to the phone (alarms, notifications,
                         haptics) via Capacitor; in a browser it quietly does nothing
      site.js          ← shared chrome: nav, theme, modals, toasts/undo, palette, gestures
      today.js         ← page JS per screen (one file per screen, like SXC)
      all.js  calendar.js  board.js  matrix.js  timeline.js
      habits.js  focus.js  study.js  exams.js  timetable.js
      review.js  completed.js  settings.js
    img/               ← logo, icons, empty-state art
```

### Data model (one state object, saved by store.js)
```
state = {
  tasks:    [{ id, title, notes, listId, priority, tags[], due, time,
               durationMin, remind[], alarm, repeat{...}, subtasks[](nested),
               status(todo|doing|done), focus(bool), attachments[],
               createdAt, completedAt, order }],
  lists:    [{ id, name, color }],
  habits:   [{ id, name, days{}, streak, best }],
  routines: [{ id, name, items[], checkedByDate{} }],
  subjects: [{ id, name, examDate, chapters[{ id, title, done, doneAt }] }],
  timetable:[{ day, start, end, subject, room }],
  focusLog: [{ date, minutes }]          ← Pomodoro history (Review screen)
  settings: { theme, sortDefault }
  completions: { 'YYYY-MM-DD': count }   ← streaks/stats
}
```

### Rules (carried from the SXC build)
- Static, dependency-free: plain HTML/CSS/JS, no framework, no build step —
  deploys as a simple file upload, every screen loads directly by URL.
- Data lives on the phone (local storage inside the app). No login, no
  server, no tracking.
- data.js holds data/templates only; logic never hides inside data files.
- Alarm honesty, now solved by the app route: inside the Android app,
  native.js schedules real phone alarms — they ring even when TYM is
  closed. In a plain browser tab the alarm still only works while the
  page is open; the app is the real product, the browser is for testing.

### Code style rules (user, 2026-11-08 — non-negotiable)
The user must be able to read, change, and fix every file himself
(his "basics + AI" learning rule). So:
- **One job per file.** A file that does two jobs gets split.
- **Simple code only.** Plain functions, plain names (`markTaskDone`,
  not `hndlTskCmp`). No clever one-line tricks, no framework magic.
- **Comments in simple English.** Every file starts with a header comment:
  what this file does, in 2–3 lines. Every non-obvious function gets a
  one-line comment saying what it does and why.
- **Small functions.** If a function does not fit on one screen, split it.
- **Same patterns everywhere.** Every screen's JS follows the same shape:
  load state → render → handle clicks. Learn one file, know all files.
- CSS is grouped and commented by section (layout / cards / buttons / motion).
- When a stage delivers code, Muse also gives a 5-line "how this file
  works" note per new file, so the user can learn it as it grows.

### Interactive design direction ("best interactive" — impressive, modern)
- **Look:** premium modern — soft layered depth (cards float on a calm
  background), one strong accent colour with a subtle animated gradient,
  big display type for the current task, glass-style panels on the Focus
  and Alarm screens, rounded corners everywhere, dark mode at equal quality.
- **Motion everywhere, with purpose:** screens slide/fade in with a stagger;
  cards lift on hover/drag with a real shadow; checkbox tick draws itself;
  progress rings sweep; heatmap cells pop in row by row; numbers count up.
  All motion uses spring-like easing; full **prefers-reduced-motion** support.
- **Gestures:** swipe right = done, swipe left = snooze/delete (mobile);
  drag to reorder; drag cards on Board/Matrix; drag tasks onto Calendar
  dates; long-press = multi-select.
- **Feedback moments:** tick a task → small burst + pulse; finish all of
  Today → "Day Complete" celebration + review prompt; streak flame grows
  with the count; alarm screen pulses until acted on.
- **Focus first:** Today opens on My Day Top-3 + the single next task,
  big and calm — the app always answers "what now?" in one glance.
- **Speed:** everything local = instant; no spinners anywhere.

### Testing (per stage)
- Pure logic (dates, repeats, P&L, streaks, parser) → Node tests, must pass.
- Every screen → local serve, HTTP 200 + link audit.
- No rendered-browser QA exists in this environment — visual check is the
  user's pass on his phone/Mac; said plainly in BUILD-SUMMARY.md.
