# TYM — Build Plan (started 2026-11-08)

Design of record: DESIGN.md (v2). Build runs stage by stage; a stage is
finished only when its "done when" tests pass. Results recorded here.

- [x] **Stage 0 — Skeleton.** DONE 2026-11-08. 14 screens + 404, shared
      styles.css design system, data.js / store.js / site.js, one JS file
      per screen. Verified: all JS syntax OK, store tests pass (defaults,
      backup round-trip, broken-save recovery), all 15 pages + assets
      serve HTTP 200. Nav + theme verified by code path (no rendered-
      browser QA in this environment — user's visual pass still to come).
- [x] **Stage 1 — Core tasks** (S1 Today + S2 All + editor modal) DONE 2026-11-08.
      New files: dates.js, tasks.js, taskcard.js, editor.js. Today = greeting,
      Top-3 focus banner, progress ring, stats, quick add, overdue + today
      lists. All = search, 4 sorts (incl. drag reorder), list filter chips.
      Completed = reopen / delete / clear-all with Undo. Verified: 9 Node
      test groups pass, all wired pages + assets HTTP 200, reference audit
      clean. Per-file notes: dates.js = all date math; tasks.js = all task
      logic; taskcard.js = one card's HTML; editor.js = the shared editor
      popup + shared card clicks (tick/edit/delete/pin with Undo).
- [x] **Stage 2 — Reminders & Alarm** (F1–F5)
- [x] **Stage 3 — Time views** (Calendar, Timeline, Pomodoro, Plan My Day)
- [x] **Stage 4 — Power & views** (Board, Matrix, tags, repeats, palette, undo)
- [x] **Stage 5 — Everyday + Review** (Habits, routines, My Day, heatmaps)
- [x] **Stage 6 — Students** (Study, Exams, Timetable)
- [x] **Stage 7 — Quality pass** (rich notes, PWA, CSV import, print, motion)
- [x] **Stage 8 — Mobile app wrap** (Capacitor → Android APK, real alarms)
- [x] **Stage 9 — Final QA** (BUILD-SUMMARY.md)

Code rules (from DESIGN.md): one job per file · simple code · a header
comment on every file · comments in simple English · same pattern in every
screen's JS (load state → render → handle clicks).

How to run locally: `python3 -m http.server` in this folder, open
http://localhost:8000/index.html
