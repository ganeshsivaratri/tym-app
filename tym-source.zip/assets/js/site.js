'use strict';
/* ============================================================
   TYM — Track Your Mind · site.js
   What this file does: the SHARED CHROME on every screen —
   builds the sidebar (desktop) and bottom bar (phone),
   applies the saved theme, and provides the toast message.
   Every screen loads this file. Screen-specific work lives
   in that screen's own JS file (today.js, habits.js, ...).
   Pattern on every screen: load state → render → clicks.
   ============================================================ */

/* Every screen of the app, in sidebar order.
   id must match the page's <body data-screen="...">. */
const TYM_SCREENS = [
  { id: 'today',     name: 'Today',     icon: '☀️', file: 'index.html',     group: 'Plan' },
  { id: 'all',       name: 'All Tasks', icon: '🗂️', file: 'all.html',       group: 'Plan' },
  { id: 'calendar',  name: 'Calendar',  icon: '📅', file: 'calendar.html',  group: 'Plan' },
  { id: 'board',     name: 'Board',     icon: '📋', file: 'board.html',     group: 'Views' },
  { id: 'matrix',    name: 'Matrix',    icon: '🎯', file: 'matrix.html',    group: 'Views' },
  { id: 'timeline',  name: 'Timeline',  icon: '🕐', file: 'timeline.html',  group: 'Views' },
  { id: 'habits',    name: 'Habits',    icon: '🔥', file: 'habits.html',    group: 'Grow' },
  { id: 'focus',     name: 'Focus',     icon: '🍅', file: 'focus.html',     group: 'Grow' },
  { id: 'review',    name: 'Review',    icon: '📊', file: 'review.html',    group: 'Grow' },
  { id: 'study',     name: 'Study',     icon: '📚', file: 'study.html',     group: 'Students' },
  { id: 'exams',     name: 'Exams',     icon: '⏳', file: 'exams.html',     group: 'Students' },
  { id: 'timetable', name: 'Timetable', icon: '🏫', file: 'timetable.html', group: 'Students' },
  { id: 'completed', name: 'Completed', icon: '✅', file: 'completed.html', group: 'More' },
  { id: 'settings',  name: 'Settings',  icon: '⚙️', file: 'settings.html',  group: 'More' }
];

/* The five screens shown in the phone bottom bar. */
const TYM_BOTTOM_BAR = ['today', 'calendar', 'habits', 'focus', 'settings'];

/* The one shared state object for this page.
   store.js loads it; every screen file reads and changes it,
   then calls saveState(state) after a change. */
let state = loadState();
maybeSnapshot(state, new Date());

/* ---------- theme ----------
   settings.theme is 'light', 'dark', or 'auto'.
   Auto = dark from 19:00 to 07:00, light the rest of the day. */
function resolvedTheme() {
  const pref = state.settings.theme || 'light';
  if (pref !== 'auto') return pref;
  const h = new Date().getHours();
  return (h >= 19 || h < 7) ? 'dark' : 'light';
}
function applyTheme() {
  document.documentElement.dataset.theme = resolvedTheme();
}
function toggleTheme() {
  state.settings.theme = resolvedTheme() === 'dark' ? 'light' : 'dark';
  saveState(state);
  applyTheme();
}

/* ---------- navigation ---------- */
function buildSidebar() {
  const box = document.getElementById('sidebarNav');
  if (!box) return;
  const current = document.body.dataset.screen;
  const groups = [];
  for (const s of TYM_SCREENS) if (!groups.includes(s.group)) groups.push(s.group);
  box.innerHTML = groups.map(g =>
    '<div class="nav-group"><h4>' + g + '</h4>' +
    TYM_SCREENS.filter(s => s.group === g).map(s =>
      '<button class="nav-item' + (s.id === current ? ' active' : '') +
      '" data-goto="' + s.file + '"><span>' + s.icon + ' ' + s.name + '</span></button>'
    ).join('') + '</div>'
  ).join('');
}

function buildBottomBar() {
  const bar = document.getElementById('bottomBar');
  if (!bar) return;
  const current = document.body.dataset.screen;
  bar.innerHTML = TYM_BOTTOM_BAR.map(id => {
    const s = TYM_SCREENS.find(x => x.id === id);
    return '<a href="' + s.file + '"' + (s.id === current ? ' class="active"' : '') +
      '><span class="bb-icon">' + s.icon + '</span>' + s.name + '</a>';
  }).join('');
}

/* ---------- toast: small message at the bottom ----------
   showToast('Task deleted', 'Undo', function(){ ... })     */
let toastTimer = null;
function showToast(message, actionLabel, actionFn) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.innerHTML = '<span></span>';
  el.firstChild.textContent = message;
  if (actionLabel && actionFn) {
    const b = document.createElement('button');
    b.textContent = actionLabel;
    b.addEventListener('click', () => { hideToast(); actionFn(); });
    el.appendChild(b);
  }
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, 4200);
}
function hideToast() {
  const el = document.getElementById('toast');
  if (el) el.classList.remove('show');
}

/* ---------- small shared helpers ---------- */
function escapeHTML(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* A friendly greeting by time of day, for the Today screen. */
function greetingText(now) {
  const h = (now || new Date()).getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

/* ---------- runs on every screen ---------- */
document.addEventListener('DOMContentLoaded', () => {
  applyTheme();
  setInterval(applyTheme, 60000); // auto theme flips itself at 19:00 / 07:00
  buildSidebar();
  buildBottomBar();
  // Sidebar buttons navigate between screens.
  document.body.addEventListener('click', e => {
    const go = e.target.closest('[data-goto]');
    if (go) window.location.href = go.dataset.goto;
    if (e.target.closest('[data-theme-toggle]')) toggleTheme();
  });
});

/* ---------- command palette + keyboard shortcuts ----------
   Ctrl+K (or Cmd+K) opens the palette: type to jump to any
   screen, add a task, or toggle the theme.
   Shortcuts on list screens: n = new task, t = theme,
   1–9 jump screens. '?' in the palette lists them.        */
function buildPaletteHTML() {
  if (document.getElementById('palette')) return;
  const d = document.createElement('div');
  d.className = 'modal';
  d.id = 'palette';
  d.innerHTML =
    '<div class="modal-card palette-card">' +
      '<input class="field" id="palInput" type="text" placeholder="Type a screen or action… (e.g. habits, new task, dark)">' +
      '<div id="palList"></div>' +
      '<p class="pal-hint">Shortcuts: Ctrl+K palette · n new task · t theme · 1–9 go to screen · Esc close</p>' +
    '</div>';
  document.body.appendChild(d);
  d.addEventListener('click', e => { if (e.target.id === 'palette') closePalette(); });
  document.getElementById('palInput').addEventListener('input', renderPalette);
  document.getElementById('palInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const first = document.querySelector('#palList [data-pal]');
      if (first) first.click();
    }
  });
}

function paletteActions() {
  const acts = TYM_SCREENS.map(s => ({
    label: s.icon + '  Go to ' + s.name, run: () => { window.location.href = s.file; }
  }));
  acts.push({ label: '＋  New task', run: () => { if (typeof openTaskEditor === 'function') openTaskEditor(null); } });
  acts.push({ label: '🌙  Toggle dark / light', run: toggleTheme });
  return acts;
}

function renderPalette() {
  const q = document.getElementById('palInput').value.trim().toLowerCase();
  const list = document.getElementById('palList');
  const acts = paletteActions().filter(a => !q || a.label.toLowerCase().includes(q));
  // Tasks are searchable too: pick one to open its editor.
  if (q && typeof searchTasks === 'function' && typeof findTask === 'function') {
    const hits = searchTasks(state.tasks.filter(t => t.status !== 'done'), q).slice(0, 5);
    for (const t of hits) {
      acts.push({ label: '✏️  Task: ' + t.title, run: () => {
        if (typeof openTaskEditor === 'function') openTaskEditor(findTask(state, t.id));
      }});
    }
  }
  list.innerHTML = acts
    .map((a, i) => '<button class="pal-item" data-pal="' + i + '">' + escapeHTML(a.label.replace(/^\S+\s+/, '')) + '</button>')
    .join('') || '<p class="pal-hint">No matches.</p>';
  list.querySelectorAll('[data-pal]').forEach((b, i) =>
    b.addEventListener('click', () => { closePalette(); acts[i].run(); }));
}

function openPalette() {
  buildPaletteHTML();
  document.getElementById('palette').classList.add('open');
  const input = document.getElementById('palInput');
  input.value = '';
  renderPalette();
  input.focus();
}
function closePalette() {
  const p = document.getElementById('palette');
  if (p) p.classList.remove('open');
}

document.addEventListener('keydown', e => {
  const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName);
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    openPalette();
    return;
  }
  if (e.key === 'Escape') closePalette();
  if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key === 'n' && typeof openTaskEditor === 'function') { e.preventDefault(); openTaskEditor(null); }
  else if (e.key === 't') toggleTheme();
  else if (/^[1-9]$/.test(e.key)) {
    const s = TYM_SCREENS[parseInt(e.key, 10) - 1];
    if (s) window.location.href = s.file;
  }
});

/* Register the service worker (offline + installable).
   Only on http/https — opening files directly skips it. */
if ('serviceWorker' in navigator && /^https?:$/.test(window.location.protocol)) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => { /* offline mode unavailable */ });
  });
}
