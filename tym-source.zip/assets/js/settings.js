'use strict';
/* ============================================================
   TYM — Track Your Mind · settings.js
   What this file does: the SETTINGS screen.
   - Theme (light/dark)
   - Lists manager: add, rename, recolour, delete
     (deleting a list moves its tasks to Personal)
   - Notifications: ask the browser/app for permission
   - Backup: export the whole state as a JSON file,
     import it back
   - CSV import: bring tasks in from Todoist / TickTick
     exports (title + date columns are picked up)
   - Danger zone: erase everything
   ============================================================ */

function render() {
  const box = document.getElementById('screenContent');

  const listRows = state.lists.map(l => {
    const count = state.tasks.filter(t => t.listId === l.id).length;
    return '<div class="task"><span class="dot" style="background:' + l.color + ';width:14px;height:14px"></span>' +
      '<div class="task-main"><div class="task-title">' + escapeHTML(l.name) + '</div>' +
      '<div style="color:var(--muted);font-size:12.5px">' + count + ' tasks</div></div>' +
      '<input type="color" value="' + l.color + '" data-list-color="' + l.id + '" title="Colour">' +
      '<button class="icon-btn" data-list-rename="' + l.id + '">✏️</button>' +
      '<button class="icon-btn" data-list-del="' + l.id + '">🗑</button></div>';
  }).join('');

  box.innerHTML =
    '<div class="card" style="margin-bottom:12px"><h2>🎨 Appearance</h2>' +
      '<p style="color:var(--muted)">Auto = dark from 7 PM to 7 AM, light the rest of the day.</p>' +
      '<div class="toolbar" style="margin:0"><select class="field" id="themeSel" style="flex:0 1 200px">' +
        '<option value="light"' + (state.settings.theme === 'light' ? ' selected' : '') + '>☀️ Light</option>' +
        '<option value="dark"' + (state.settings.theme === 'dark' ? ' selected' : '') + '>🌙 Dark</option>' +
        '<option value="auto"' + (state.settings.theme === 'auto' ? ' selected' : '') + '>🌓 Auto (by time)</option>' +
      '</select><button class="btn" data-theme-toggle>Toggle now</button></div></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>🔔 Notifications</h2>' +
      '<p style="color:var(--muted)">Browser reminders need permission. In the Android app, alarms ring even when TYM is closed.</p>' +
      '<button class="btn" id="notifyBtn">Enable notifications</button>' +
      '<span class="pill" id="notifyState" style="margin-left:8px"></span></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>🗂 My lists</h2>' + listRows +
      '<div class="toolbar" style="margin:10px 0 0"><input class="field" id="listInput" type="text" placeholder="New list name">' +
      '<button class="btn btn-primary" id="listAdd">Add list</button></div></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>💾 Backup</h2>' +
      '<p style="color:var(--muted)">Your data lives only on this device. Export a backup file regularly.</p>' +
      '<button class="btn" id="exportBtn">⬇ Export backup (JSON)</button> ' +
      '<label class="btn" style="display:inline-block">⬆ Import backup <input type="file" id="importFile" accept=".json" hidden></label></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>🛡 Automatic snapshots</h2>' +
      '<p style="color:var(--muted)">TYM quietly saves one snapshot per day (last 3 kept). Restore one if something ever goes wrong.</p>' +
      '<div id="snapList">' +
      (readSnapshots().length
        ? readSnapshots().slice().reverse().map(sn =>
            '<div class="task"><div class="task-main"><div class="task-title">📸 ' + sn.day + '</div></div>' +
            '<button class="btn" data-snap="' + sn.day + '">Restore</button></div>').join('')
        : '<p style="color:var(--muted)">No snapshots yet — the first one is taken today.</p>') +
      '</div></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>📆 Calendar export</h2>' +
      '<p style="color:var(--muted)">Download your dated tasks as an .ics file and import it into Google Calendar (Settings → Import calendar there).</p>' +
      '<button class="btn" id="icsBtn">⬇ Export tasks (.ics)</button></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>🌱 Sample day</h2>' +
      '<p style="color:var(--muted)">New here? Load a small sample day to see TYM alive — remove it any time with one tap.</p>' +
      '<button class="btn" id="sampleBtn">Load sample day</button> ' +
      '<button class="btn" id="sampleDelBtn">Remove sample data</button></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>📥 Import tasks from CSV</h2>' +
      '<p style="color:var(--muted)">Works with Todoist and TickTick exports — the title and due-date columns are picked up; other columns are ignored.</p>' +
      '<label class="btn" style="display:inline-block">Choose CSV file <input type="file" id="csvFile" accept=".csv" hidden></label>' +
      '<span class="pill" id="csvResult" style="margin-left:8px"></span></div>' +

    '<div class="card" style="margin-bottom:12px"><h2>⌨️ Shortcuts</h2>' +
      '<p style="color:var(--muted);line-height:1.9">Ctrl+K — command palette<br>' +
      'n — new task · t — theme · 1–9 — jump to a screen · Esc — close popups</p></div>' +

    '<div class="card"><h2>⚠️ Danger zone</h2>' +
      '<p style="color:var(--muted)">Erase every task, habit and setting on this device. Export a backup first if unsure.</p>' +
      '<button class="btn" id="eraseBtn" style="border-color:var(--high);color:var(--high)">Erase everything</button></div>';

  updateNotifyState();
  document.getElementById('notifyBtn').addEventListener('click', enableNotifications);
  document.getElementById('listAdd').addEventListener('click', () => {
    const v = document.getElementById('listInput').value.trim();
    if (!v) return;
    state.lists.push({ id: makeId(), name: v, color: '#6d5cff' });
    saveState(state);
    render();
  });
  document.getElementById('themeSel').addEventListener('change', e => {
    state.settings.theme = e.target.value;
    saveState(state);
    applyTheme();
    showToast('Theme: ' + e.target.value);
  });
  document.getElementById('icsBtn').addEventListener('click', () => {
    const blob = new Blob([buildICS(state.tasks)], { type: 'text/calendar' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'tym-tasks.ics';
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('Calendar file downloaded 📆');
  });
  document.getElementById('sampleBtn').addEventListener('click', loadSampleDay);
  document.getElementById('sampleDelBtn').addEventListener('click', removeSampleDay);
  document.getElementById('exportBtn').addEventListener('click', exportBackup);
  document.getElementById('importFile').addEventListener('change', importBackup);
  document.getElementById('csvFile').addEventListener('change', importCSV);
  document.getElementById('eraseBtn').addEventListener('click', () => {
    if (!confirm('Erase EVERYTHING in TYM on this device? This cannot be undone.')) return;
    localStorage.removeItem(TYM_STORAGE_KEY);
    state = createDefaultState();
    saveState(state);
    render();
    showToast('Fresh start — everything erased');
  });
}

function updateNotifyState() {
  const el = document.getElementById('notifyState');
  if (!el) return;
  if (tymInApp()) el.textContent = 'app mode — phone notifications';
  else if (!window.Notification) el.textContent = 'not supported in this browser';
  else el.textContent = 'permission: ' + Notification.permission;
}

async function enableNotifications() {
  if (tymInApp()) { await tymRequestNotifyPermission(); }
  else if (window.Notification) { await Notification.requestPermission(); }
  updateNotifyState();
  showToast('Notifications setting updated 🔔');
}

/* Download the whole state as tym-backup.json. */
function exportBackup() {
  const blob = new Blob([stateToBackupText(state)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'tym-backup.json';
  a.click();
  URL.revokeObjectURL(a.href);
}

/* Load a backup file back in (parseState guards bad files). */
function importBackup(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const r = new FileReader();
  r.onload = () => {
    state = parseState(String(r.result));
    saveState(state);
    applyTheme();
    render();
    showToast('Backup imported 💾');
  };
  r.readAsText(file);
}

/* A tiny CSV reader: handles quoted commas.
   Finds a title column (TASK/content/title/name) and a
   date column (DATE/due/scheduled) if they exist. */
function parseCSV(text) {
  const rows = [];
  let row = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
    else if (ch !== '\r') cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

function importCSV(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const r = new FileReader();
  r.onload = () => {
    const rows = parseCSV(String(r.result));
    if (!rows.length) return;
    const head = rows[0].map(h => h.trim().toLowerCase());
    const ti = head.findIndex(h => ['task', 'content', 'title', 'name'].includes(h));
    const di = head.findIndex(h => ['date', 'due', 'due date', 'scheduled'].includes(h));
    let added = 0;
    for (const row of rows.slice(1)) {
      const title = (ti >= 0 ? row[ti] : row[0] || '').trim();
      if (!title) continue;
      let due = null;
      if (di >= 0 && /^\d{4}-\d{2}-\d{2}/.test((row[di] || '').trim())) due = row[di].trim().slice(0, 10);
      addTaskToState(state, { title, due, listId: 'personal' });
      added++;
    }
    saveState(state);
    document.getElementById('csvResult').textContent = added + ' tasks imported';
    showToast('Imported ' + added + ' tasks 📥');
  };
  r.readAsText(file);
}

/* Snapshot restore (delegated — the list is re-drawn). */
document.addEventListener('click', e => {
  const btn = e.target.closest('[data-snap]');
  if (!btn) return;
  const sn = readSnapshots().find(x => x.day === btn.dataset.snap);
  if (!sn) return;
  if (!confirm('Restore the snapshot from ' + sn.day + '? Current data will be replaced.')) return;
  state = parseState(sn.data);
  saveState(state);
  applyTheme();
  render();
  showToast('Snapshot restored 📸');
});

/* A tiny ready-made day so a new user sees TYM alive.
   Everything sample carries the 'sample' tag for removal. */
function loadSampleDay() {
  const today = todayStr();
  addTaskToState(state, { title: 'Pay the electricity bill', due: today, time: '18:00',
    priority: 'high', listId: 'personal', reminders: [0, 60], tags: ['sample'] });
  addTaskToState(state, { title: 'Revise Unit 3 — Operating Systems', due: today,
    priority: 'med', listId: 'study', estMinutes: 50, tags: ['sample'],
    subtasks: [{ title: 'Read notes' }, { title: 'Solve 5 previous questions' }] });
  addTaskToState(state, { title: 'Evening walk 20 minutes', due: today,
    priority: 'low', listId: 'personal', tags: ['sample'] });
  addTaskToState(state, { title: 'Submit assignment', due: addDaysStr(today, 1),
    priority: 'high', listId: 'study', tags: ['sample'] });
  state.habits.push({ id: makeId(), name: '🌱 Read 10 pages', createdAt: Date.now() });
  saveState(state);
  render();
  showToast('Sample day loaded 🌱 — see the Today screen');
}
function removeSampleDay() {
  state.tasks = state.tasks.filter(t => !(t.tags || []).includes('sample'));
  state.habits = state.habits.filter(h => !h.name.startsWith('🌱'));
  saveState(state);
  render();
  showToast('Sample data removed');
}

/* List manager clicks (delegated). */
document.addEventListener('click', e => {
  const ren = e.target.closest('[data-list-rename]');
  if (ren) {
    const l = state.lists.find(x => x.id === ren.dataset.listRename);
    const name = prompt('Rename list', l ? l.name : '');
    if (l && name && name.trim()) { l.name = name.trim(); saveState(state); render(); }
    return;
  }
  const del = e.target.closest('[data-list-del]');
  if (del) {
    const id = del.dataset.listDel;
    if (state.lists.length <= 1) { showToast('Keep at least one list'); return; }
    const fallback = state.lists.find(x => x.id !== id);
    state.tasks.forEach(t => { if (t.listId === id) t.listId = fallback.id; });
    state.lists = state.lists.filter(x => x.id !== id);
    saveState(state);
    render();
    showToast('List deleted — its tasks moved to ' + fallback.name);
  }
});
document.addEventListener('change', e => {
  const col = e.target.closest('[data-list-color]');
  if (col) {
    const l = state.lists.find(x => x.id === col.dataset.listColor);
    if (l) { l.color = col.value; saveState(state); }
  }
});

document.addEventListener('DOMContentLoaded', render);
