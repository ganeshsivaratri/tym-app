'use strict';
const assert = require('assert');
const PL = require('../assets/js/plan.js');
let passed = 0;
function ok(name, fn) { fn(); passed++; console.log('PASS', name); }

ok('arrangeDay: importance first, skips busy slot', () => {
  const tasks = [
    { id: 'fixed', status: 'todo', due: '2026-11-08', time: '09:00', estMinutes: 60, priority: 'low' },
    { id: 'big', status: 'todo', due: '2026-11-08', time: null, estMinutes: 30, priority: 'high' },
    { id: 'small', status: 'todo', due: '2026-11-08', time: null, estMinutes: 30, priority: 'low' },
    { id: 'other-day', status: 'todo', due: '2026-11-09', time: null, estMinutes: 30, priority: 'high' }
  ];
  const placed = PL.arrangeDay(tasks, '2026-11-08', '09:00');
  assert.deepStrictEqual(placed, [
    { id: 'big', time: '10:00' },   // after the fixed 09:00-10:00 block
    { id: 'small', time: '10:30' }
  ]);
});

ok('whatCanIDo: fits the slot, energy steers order', () => {
  const tasks = [
    { id: 'long-high', status: 'todo', estMinutes: 60, priority: 'high' },
    { id: 'quick-low', status: 'todo', estMinutes: 10, priority: 'low' },
    { id: 'mid', status: 'todo', estMinutes: 20, priority: 'med' }
  ];
  const lowEnergy = PL.whatCanIDo(tasks, 30, 'low').map(t => t.id);
  assert.deepStrictEqual(lowEnergy, ['quick-low', 'mid']); // 60-min task cannot fit
  const highEnergy = PL.whatCanIDo(tasks, 90, 'high').map(t => t.id);
  assert.strictEqual(highEnergy[0], 'long-high');
});

console.log('\nAll ' + passed + ' plan test groups passed.');
