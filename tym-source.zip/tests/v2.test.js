'use strict';
/* TYM v2 feature tests — run: node tests/v2.test.js */
const assert = require('assert');
Object.assign(global, require('../assets/js/dates.js'));
const S = require('../assets/js/store.js');
const PR = require('../assets/js/progress.js');
const ICS = require('../assets/js/ics.js');
let passed = 0;
function ok(name, fn) { fn(); passed++; console.log('PASS', name); }

ok('snapshots: rotation keeps newest 3, one per day', () => {
  let snaps = [];
  for (const day of ['2026-11-06', '2026-11-07', '2026-11-08', '2026-11-09']) {
    snaps = S.rotateSnapshots(snaps, { day, at: 1, data: '{}' });
  }
  assert.deepStrictEqual(snaps.map(x => x.day), ['2026-11-07', '2026-11-08', '2026-11-09']);
  snaps = S.rotateSnapshots(snaps, { day: '2026-11-09', at: 2, data: '{"new":1}' });
  assert.strictEqual(snaps.length, 3);
  assert.strictEqual(snaps[2].data, '{"new":1}'); // same day replaced, not duplicated
});

ok('xp: tasks + focus + habits add up; levels resolve', () => {
  const state = { tasks: [{ status: 'done' }, { status: 'done' }, { status: 'todo' }],
    focusLog: [{ minutes: 25 }, { minutes: 25 }],
    habitLog: { h1: { '2026-11-08': true, '2026-11-07': true } } };
  assert.strictEqual(PR.totalXP(state), 20 + 50 + 10);
  const lvl = PR.levelFor(80);
  assert.strictEqual(lvl.current.name, 'Starter 🌱');
  assert.strictEqual(lvl.next.name, 'Mover 🚶');
  assert.strictEqual(PR.levelFor(260).current.name, 'Builder 🔨');
  assert.strictEqual(PR.levelFor(99999).next, null);
});

ok('ics: events, alarms, escaping', () => {
  const out = ICS.buildICS([
    { id: 'a', title: 'Pay fees; bring card', due: '2026-11-10', time: '17:00', reminders: [60, 0], notes: 'Line1\nLine2' },
    { id: 'b', title: 'No date task', due: null }
  ]);
  assert.ok(out.includes('BEGIN:VCALENDAR'));
  assert.strictEqual((out.match(/BEGIN:VEVENT/g) || []).length, 1); // no-date task skipped
  assert.ok(out.includes('DTSTART:20261110T170000'));
  assert.ok(out.includes('SUMMARY:Pay fees\\; bring card'));
  assert.ok(out.includes('TRIGGER:-PT60M'));
  assert.strictEqual((out.match(/BEGIN:VALARM/g) || []).length, 2);
});

console.log('\nAll ' + passed + ' v2 test groups passed.');
