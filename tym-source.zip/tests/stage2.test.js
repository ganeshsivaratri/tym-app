'use strict';
/* TYM Stage 2 tests — run: node tests/stage2.test.js */
const assert = require('assert');
Object.assign(global, require('../assets/js/dates.js'));
const P = require('../assets/js/parse.js');
const R = require('../assets/js/reminders.js');
const S = require('../assets/js/store.js');
const T = require('../assets/js/tasks.js');
Object.assign(global, T); // reminders tests use plain state objects anyway

let passed = 0;
function ok(name, fn) { fn(); passed++; console.log('PASS', name); }
const NOW = new Date(2026, 10, 8, 12, 0); // Sun 8 Nov 2026 noon

ok('parse: tomorrow + 5pm + !high + #tag', () => {
  const p = P.parseQuickAdd('Pay fees tomorrow 5pm !high #college', NOW);
  assert.strictEqual(p.title, 'Pay fees');
  assert.strictEqual(p.due, '2026-11-09');
  assert.strictEqual(p.time, '17:00');
  assert.strictEqual(p.priority, 'high');
  assert.deepStrictEqual(p.tags, ['college']);
});

ok('parse: in 3 days + 24h time', () => {
  const p = P.parseQuickAdd('Submit form in 3 days 17:30', NOW);
  assert.strictEqual(p.due, '2026-11-11');
  assert.strictEqual(p.time, '17:30');
  assert.strictEqual(p.title, 'Submit form');
});

ok('parse: weekday name (monday from sunday = +1)', () => {
  const p = P.parseQuickAdd('Gym monday', NOW);
  assert.strictEqual(p.due, '2026-11-09');
  assert.strictEqual(p.title, 'Gym');
});

ok('parse: plain text stays whole', () => {
  const p = P.parseQuickAdd('Buy milk', NOW);
  assert.strictEqual(p.title, 'Buy milk');
  assert.strictEqual(p.due, null);
});

ok('reminders: fire times from offsets', () => {
  const t = { due: '2026-11-08', time: '17:00', reminders: [0, 60], status: 'todo' };
  const base = new Date(2026, 10, 8, 17, 0).getTime();
  assert.deepStrictEqual(R.reminderFireTimes(t), [base - 3600000, base]);
});

ok('reminders: no time = 09:00 base', () => {
  const t = { due: '2026-11-08', time: null, reminders: [1440], status: 'todo' };
  assert.strictEqual(R.reminderFireTimes(t)[0], new Date(2026, 10, 7, 9, 0).getTime());
});

ok('reminders: due now, fired once, done tasks skipped, stale skipped', () => {
  const base = new Date(2026, 10, 8, 12, 0).getTime();
  const state = { tasks: [{ id: 'a', title: 'A', due: '2026-11-08', time: '12:00', reminders: [0], status: 'todo' },
                          { id: 'b', title: 'B', due: '2026-11-08', time: '12:00', reminders: [0], status: 'done' }],
                  fired: {}, snoozed: {} };
  let due = R.dueReminders(state, base + 60000);
  assert.strictEqual(due.length, 1);
  assert.strictEqual(due[0].task.id, 'a');
  state.fired[due[0].key] = true;
  assert.strictEqual(R.dueReminders(state, base + 120000).length, 0);
  // 3 hours late = stale, no ring
  const state2 = { tasks: [{ id: 'c', title: 'C', due: '2026-11-08', time: '09:00', reminders: [0], status: 'todo' }], fired: {}, snoozed: {} };
  assert.strictEqual(R.dueReminders(state2, base).length, 0);
});

ok('reminders: snooze ends -> rings again', () => {
  const base = Date.now();
  const state = { tasks: [{ id: 'a', title: 'A', due: '2026-11-08', time: '12:00', reminders: [0], status: 'todo' }],
                  fired: {}, snoozed: { a: base - 1000 } };
  const due = R.dueReminders(state, base);
  assert.strictEqual(due.length, 1);
  assert.strictEqual(due[0].snoozeEnd, true);
});

ok('repeats: weekdays skip the weekend, fortnightly +14', () => {
  assert.strictEqual(nextRepeatDate('2026-11-06', 'weekdays'), '2026-11-09'); // Fri -> Mon
  assert.strictEqual(nextRepeatDate('2026-11-08', 'fortnightly'), '2026-11-22');
});

console.log('\nAll ' + passed + ' Stage 2 test groups passed.');
