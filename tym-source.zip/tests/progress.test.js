'use strict';
const assert = require('assert');
Object.assign(global, require('../assets/js/dates.js'));
const PR = require('../assets/js/progress.js');
let passed = 0;
function ok(name, fn) { fn(); passed++; console.log('PASS', name); }
const NOW = new Date(2026, 10, 8); // 8 Nov 2026

ok('habit streak: today + yesterday done = continues', () => {
  const log = { '2026-11-08': true, '2026-11-07': true, '2026-11-06': true, '2026-11-04': true };
  assert.strictEqual(PR.habitStreak(log, NOW), 3);
});
ok('habit streak: today pending still counts from yesterday', () => {
  const log = { '2026-11-07': true, '2026-11-06': true };
  assert.strictEqual(PR.habitStreak(log, NOW), 2);
});
ok('habit streak: full missed day breaks it', () => {
  const log = { '2026-11-06': true };
  assert.strictEqual(PR.habitStreak(log, NOW), 0);
});
ok('longest streak over completions', () => {
  const c = { '2026-11-01': 2, '2026-11-02': 1, '2026-11-03': 5, '2026-11-05': 1, '2026-11-06': 1 };
  assert.strictEqual(PR.longestStreak(c), 3);
});
ok('week summary shape', () => {
  const w = PR.weekSummary({ '2026-11-08': 4 }, NOW);
  assert.strictEqual(w.length, 7);
  assert.strictEqual(w[6].count, 4);
  assert.strictEqual(w[6].date, '2026-11-08');
});
console.log('\nAll ' + passed + ' progress test groups passed.');
