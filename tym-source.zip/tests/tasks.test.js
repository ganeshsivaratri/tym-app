'use strict';
/* TYM logic tests — run: node tests/tasks.test.js */
const assert = require('assert');
Object.assign(global, require('../assets/js/dates.js'));
const T = require('../assets/js/tasks.js');
const S = require('../assets/js/store.js');

let passed = 0;
function ok(name, fn) { fn(); passed++; console.log('PASS', name); }
const NOW = new Date(2026, 10, 8, 12, 0); // 8 Nov 2026, noon

ok('dates: add/next/labels', () => {
  assert.strictEqual(addDaysStr('2026-11-08', 7), '2026-11-15');
  assert.strictEqual(addMonthsStr('2026-01-31', 1), '2026-02-28');
  assert.strictEqual(nextRepeatDate('2026-11-08', 'weekly'), '2026-11-15');
  assert.strictEqual(daysBetween('2026-11-08', '2026-11-10'), 2);
  assert.strictEqual(dueLabel('2026-11-08', NOW), 'Today');
  assert.strictEqual(dueLabel('2026-11-09', NOW), 'Tomorrow');
});

ok('create: defaults + subtask normalising', () => {
  const t = T.createTask({ title: '  X  ', subtasks: [{ title: 'step' }] });
  assert.strictEqual(t.title, 'X');
  assert.strictEqual(t.priority, 'med');
  assert.strictEqual(t.status, 'todo');
  assert.ok(t.subtasks[0].id && t.subtasks[0].done === false);
});

ok('complete: counts the day + repeat spawns rolled-forward copy', () => {
  const s = S.createDefaultState();
  const t = T.addTaskToState(s, { title: 'Rent', due: '2026-11-01', repeat: 'weekly' });
  T.setTaskDone(s, t.id, true, NOW);
  assert.strictEqual(s.completions['2026-11-08'], 1);
  const open = s.tasks.filter(x => x.status !== 'done');
  assert.strictEqual(open.length, 1);
  assert.strictEqual(open[0].due, '2026-11-08');
  assert.strictEqual(open[0].title, 'Rent');
});

ok('uncomplete: restores + uncounts', () => {
  const s = S.createDefaultState();
  const t = T.addTaskToState(s, { title: 'One' });
  T.setTaskDone(s, t.id, true, NOW);
  T.setTaskDone(s, t.id, false, NOW);
  assert.strictEqual(T.findTask(s, t.id).status, 'todo');
  assert.strictEqual(s.completions['2026-11-08'], undefined);
});

ok('update: subtask ticks survive a title edit', () => {
  const s = S.createDefaultState();
  const t = T.addTaskToState(s, { title: 'A', subtasks: [{ title: 's1' }, { title: 's2' }] });
  T.toggleSubtask(s, t.id, t.subtasks[0].id);
  T.updateTask(s, t.id, { title: 'A2', subtasks: [{ title: 's1' }, { title: 's3' }] });
  const u = T.findTask(s, t.id);
  assert.strictEqual(u.title, 'A2');
  assert.strictEqual(u.subtasks.length, 2);
  assert.strictEqual(u.subtasks[0].done, true);   // s1 kept its tick
  assert.strictEqual(u.subtasks[1].title, 's3');
});

ok('remove + restore (undo path)', () => {
  const s = S.createDefaultState();
  const t = T.addTaskToState(s, { title: 'Del' });
  const removed = T.removeTask(s, t.id);
  assert.strictEqual(s.tasks.length, 0);
  T.restoreTask(s, removed);
  assert.strictEqual(s.tasks.length, 1);
});

ok('today groups: focus / overdue / today', () => {
  const s = S.createDefaultState();
  T.addTaskToState(s, { title: 'F', due: '2026-11-08', focus: true });
  T.addTaskToState(s, { title: 'O', due: '2026-11-05' });
  T.addTaskToState(s, { title: 'T', due: '2026-11-08' });
  T.addTaskToState(s, { title: 'Future', due: '2026-11-20' });
  const g = T.tasksForToday(s, NOW);
  assert.deepStrictEqual(g.focus.map(x => x.title), ['F']);
  assert.deepStrictEqual(g.overdue.map(x => x.title), ['O']);
  assert.deepStrictEqual(g.today.map(x => x.title), ['T']);
});

ok('stats: pct + streak', () => {
  const s = S.createDefaultState();
  const a = T.addTaskToState(s, { title: 'a', due: '2026-11-08' });
  T.addTaskToState(s, { title: 'b', due: '2026-11-08' });
  T.setTaskDone(s, a.id, true, NOW);
  s.completions['2026-11-07'] = 1;
  const st = T.dayStats(s, NOW);
  assert.strictEqual(st.pctToday, 50);
  assert.strictEqual(st.doneToday, 1);
  assert.strictEqual(st.streak, 2);
  assert.strictEqual(st.openCount, 1);
});

ok('sort + search', () => {
  const s = S.createDefaultState();
  T.addTaskToState(s, { title: 'low later', priority: 'low', due: '2026-11-20' });
  T.addTaskToState(s, { title: 'high sooner', priority: 'high', due: '2026-11-10' });
  assert.deepStrictEqual(T.sortTasks(s.tasks, 'priority').map(x => x.title),
    ['high sooner', 'low later']);
  assert.deepStrictEqual(T.searchTasks(s.tasks, 'HIGH').map(x => x.title), ['high sooner']);
});

console.log('\nAll ' + passed + ' test groups passed.');
