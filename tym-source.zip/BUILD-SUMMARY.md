# TYM — Track Your Mind · Build Summary (2026-11-08)

**Status: all 9 stages built.** Static web app (SXC-style codebase) +
installable PWA + ready-to-compile Android project. Brand: TYM only.

## What was verified (real checks, run 2026-11-08)
- **25 Node test groups pass** — tasks/repeats/undo (9), parser +
  reminder math (9), Plan My Day + What-Can-I-Do (2), streaks/progress (5).
- **Every JS file passes a syntax check** (20 app files + tests + sw.js).
- **All 15 pages + PWA assets serve HTTP 200**; reference audit across
  every page is CLEAN (no missing file links).
- **Android:** `cap add android` + `cap sync` succeeded; the web app and
  the Local Notifications plugin are inside the Android project.

## Honest limits (read these)
- **No rendered-browser QA exists in this environment** — layout/motion
  were verified by code, tests and audits, NOT by looking at the running
  app. The user's own visual pass is still needed.
- **The APK is not compiled.** This VM has no Android SDK. The project is
  ready; compiling takes ~10 minutes in Android Studio on the Mac —
  exact steps in `android-app/BUILD-ANDROID.md`. The Stage 8 acceptance
  test (reminder rings with the app closed) can only run on his phone
  after that install.
- **Browser alarm** rings only while a TYM page is open (browser rule).
  In the Android app, native.js schedules real phone notifications.
- Data lives in the browser/app storage on ONE device. No sync, no
  account — by design. Settings has JSON backup export/import.
- Attachments are capped at 300 KB images (localStorage limits).

## Feature map (design v2 → built)
Core tasks/subtasks/repeats ✓ · multiple reminders + alarm + snooze ✓ ·
natural-language quick add ✓ · voice input ✓ (browser support varies) ·
Calendar + drag-reschedule ✓ · Timeline + Plan My Day ✓ · Pomodoro +
ambience + session log ✓ · Board ✓ · Matrix ✓ · tags ✓ · attachments ✓ ·
custom repeats (weekdays, fortnightly, from-completion) ✓ · templates ✓ ·
duplicate ✓ · drag reorder ✓ · Undo ✓ · Habits + streaks ✓ · routines ✓ ·
Review (week bars, year heatmap, focus minutes) ✓ · Study + spaced
revision ✓ · Exams + revision plans ✓ · Timetable ✓ · Markdown notes ✓ ·
estimates ✓ · Day Complete ritual ✓ · Ctrl+K palette + shortcuts ✓ ·
PWA install/offline ✓ · CSV import ✓ · print my day ✓.
Parked by the user's word: the Trader pack (later).

## Run it
- Browser: `python3 -m http.server` in this folder → open index.html.
- Android: see `android-app/BUILD-ANDROID.md`.
