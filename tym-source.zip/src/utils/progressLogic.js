// ==========================================
// FILE: src/utils/progressLogic.js
// WHAT: Pure logic — no screen code here.
// These functions only take data and give
// data back, so they are easy to test.
// (Proven logic, carried over from TYM v2.)
// ==========================================
import { addDaysStr, todayStr } from './dates.js';
/* ============================================================
   TYM — Track Your Mind · progress.js
   What this file does: PROGRESS MATH as pure functions —
   habit streaks, longest streak, last-N-days lists, week
   summaries. Used by the Habits and Review screens.
   Needs dates.js loaded before it.
   ============================================================ */

/* Date strings for the last n days, oldest first. */
function lastNDays(n, now) {
  const today = todayStr(now);
  const out = [];
  for (let i = n - 1; i >= 0; i--) out.push(addDaysStr(today, -i));
  return out;
}

/* Current streak of one habit. log = { 'YYYY-MM-DD': true }.
   A streak survives "today not done yet" — it breaks only
   when a full day passes with no tick. */
function habitStreak(log, now) {
  let streak = 0;
  let cursor = todayStr(now);
  if (!log[cursor]) cursor = addDaysStr(cursor, -1);
  while (log[cursor]) { streak += 1; cursor = addDaysStr(cursor, -1); }
  return streak;
}

/* Longest run of consecutive days with count > 0 in a
   { dateStr: count } map (used for task completions). */
function longestStreak(dayCounts) {
  const days = Object.keys(dayCounts).filter(d => dayCounts[d] > 0).sort();
  let best = 0, run = 0, prev = null;
  for (const d of days) {
    run = (prev && addDaysStr(prev, 1) === d) ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return best;
}

/* Completions for the last 7 days: [{ date, count }]. */
function weekSummary(completions, now) {
  return lastNDays(7, now).map(date => ({
    date, count: completions[date] || 0
  }));
}

/* ---------- XP + levels (Review screen) ----------
   XP = 10 per completed task + 1 per focus minute
   + 5 per habit tick. Levels grow x1.6 each time. */
const LEVELS = [
  { xp: 0, name: 'Starter 🌱' }, { xp: 100, name: 'Mover 🚶' },
  { xp: 250, name: 'Builder 🔨' }, { xp: 500, name: 'Streaker 🔥' },
  { xp: 900, name: 'Focused 🎯' }, { xp: 1500, name: 'Machine ⚙️' },
  { xp: 2400, name: 'Master 🧠' }, { xp: 4000, name: 'Legend 👑' }
];

function totalXP(state) {
  const tasksXP = state.tasks.filter(t => t.status === 'done').length * 10;
  const focusXP = state.focusLog.reduce((a, s) => a + s.minutes, 0);
  const habitXP = Object.values(state.habitLog || {})
    .reduce((a, log) => a + Object.keys(log).length * 5, 0);
  return tasksXP + focusXP + habitXP;
}

function levelFor(xp) {
  let cur = LEVELS[0], next = null;
  for (let i = 0; i < LEVELS.length; i++) {
    if (xp >= LEVELS[i].xp) { cur = LEVELS[i]; next = LEVELS[i + 1] || null; }
  }
  return { current: cur, next,
    pctToNext: next ? Math.round((xp - cur.xp) / (next.xp - cur.xp) * 100) : 100 };
}

export { lastNDays, habitStreak, longestStreak, weekSummary, LEVELS, totalXP, levelFor };
