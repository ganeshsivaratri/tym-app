// ==========================================
// FILE: src/utils/escapeHtml.js
// WHAT: Makes text safe to show on a page.
// It turns < > & into harmless characters,
// so user text can never break the screen.
// ==========================================
export function escapeHTML(text) {
  return String(text == null ? '' : text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
