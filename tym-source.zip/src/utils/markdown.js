// ==========================================
// FILE: src/utils/markdown.js
// WHAT: Pure logic — no screen code here.
// These functions only take data and give
// data back, so they are easy to test.
// (Proven logic, carried over from TYM v2.)
// ==========================================
import { escapeHTML } from './escapeHtml.js';
/* ============================================================
   TYM — Track Your Mind · md.js
   What this file does: a TINY Markdown renderer for task
   notes. Supports **bold**, *italic*, `code`, - lists and
   lines. The text is HTML-escaped FIRST, so notes can never
   inject markup — only our own formatting is added after.
   ============================================================ */

function mdRender(text) {
  const esc = escapeHTML(text || '');
  return esc.split('\n').map(line => {
    let l = line
      .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
      .replace(/\*([^*]+)\*/g, '<i>$1</i>')
      .replace(/`([^`]+)`/g, '<code>$1</code>');
    if (/^\s*-\s+/.test(l)) l = '• ' + l.replace(/^\s*-\s+/, '');
    return l;
  }).join('<br>');
}

export { mdRender };
