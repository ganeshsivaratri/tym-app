// ==========================================
// FILE: src/utils/reminderLogic.js
// WHAT: Pure reminder maths — when should
// each task ring? No sound, no screen here.
// (Proven logic, carried over from TYM v2.)
// ==========================================
/* ============================================================
   TYM — Track Your Mind · reminders.js
   What this file does: REMINDERS + the ALARM.
   - Works out when each task should remind (fire times).
   - A small engine checks every 15 seconds.
   - Browser: shows the full-screen alarm + sound, and a
     system notification if permission was given.
   - Android app: also schedules real phone notifications
     through native.js, so alarms fire with the app closed.
   The pure math (reminderFireTimes, dueReminders) is
   exported for the Node tests.
   ============================================================ */

/* The moment a task is "due": its date + its time.
   A task with a date but no time is due at 09:00. */
function dueMomentMs(task) {
  if (!task.due) return null;
  const p = task.due.split('-').map(Number);
  const t = (task.time || '09:00').split(':').map(Number);
  return new Date(p[0], p[1] - 1, p[2], t[0], t[1]).getTime();
}

/* All the times this task should ring: due moment minus
   each reminder offset (in minutes). Sorted, oldest first. */
function reminderFireTimes(task) {
  const base = dueMomentMs(task);
  if (base === null) return [];
  const offsets = (task.reminders && task.reminders.length) ? task.reminders : [];
  return offsets.map(min => base - min * 60000).sort((a, b) => a - b);
}

/* Which reminders should ring RIGHT NOW?
   Rules: task still open · fire time reached · not rung
   before · not older than 2 hours (no stale rings) ·
   a snoozed task rings again when its snooze ends. */
function dueReminders(state, nowMs) {
  const out = [];
  for (const t of state.tasks) {
    if (t.status === 'done') continue;
    const until = state.snoozed && state.snoozed[t.id];
    if (until) {
      if (nowMs >= until) out.push({ task: t, key: t.id + '@s' + until, snoozeEnd: true });
      continue;
    }
    for (const ft of reminderFireTimes(t)) {
      const key = t.id + '@' + ft;
      if (ft <= nowMs && nowMs - ft < 2 * 3600 * 1000 && !(state.fired && state.fired[key])) {
        out.push({ task: t, key, fireMs: ft });
      }
    }
  }
  return out;
}

export { dueMomentMs, reminderFireTimes, dueReminders };
