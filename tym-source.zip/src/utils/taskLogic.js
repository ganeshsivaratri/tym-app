// ==========================================
// FILE: src/utils/taskLogic.js
// WHAT: Pure logic — no screen code here.
// These functions only take data and give
// data back, so they are easy to test.
// (Proven logic, carried over from TYM v2.)
// ==========================================
import { addDaysStr, dateToStr, nextRepeatDate, pad2, todayStr } from './dates.js';
/* ============================================================
   TYM — Track Your Mind · tasks.js
   What this file does: ALL task logic — create, edit, delete,
   complete, subtasks, repeats, filtering, sorting, stats.
   Pure functions: they take the state, change it, return
   results. No screen code here — screens call these.
   Needs dates.js loaded before it (date math lives there).
   ============================================================ */

/* A unique id for a new task or subtask. */
function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/* ---------- create / read / update / delete ---------- */

/* Build a task object from form fields. Fills safe defaults
   so every task always has the same shape. */
function createTask(fields) {
  return {
    id: makeId(),
    title: (fields.title || '').trim(),
    notes: fields.notes || '',
    listId: fields.listId || 'personal',
    priority: fields.priority || 'med',       // high | med | low
    tags: fields.tags || [],
    due: fields.due || null,                  // 'YYYY-MM-DD'
    time: fields.time || null,                // 'HH:MM'
    repeat: fields.repeat || 'none',          // none|daily|weekdays|weekly|fortnightly|monthly
    repeatBase: fields.repeatBase || 'due',   // next copy from 'due' date or from 'completion'
    reminders: fields.reminders || [],        // minutes before due time: [0, 10, 60, 1440]
    estMinutes: fields.estMinutes || 0,       // time estimate (Plan My Day uses it)
    attachments: fields.attachments || [],    // small images: [{ name, dataUrl }]
    subtasks: (fields.subtasks || []).map(s => ({
      id: s.id || makeId(), title: s.title, done: !!s.done, depth: s.depth ? 1 : 0
    })),
    status: 'todo',                           // todo | doing | done (Board, Stage 4)
    focus: !!fields.focus,                    // pinned in My Day Top 3
    createdAt: Date.now(),
    completedAt: null,
    order: Date.now()
  };
}

function addTaskToState(state, fields) {
  const t = createTask(fields);
  state.tasks.push(t);
  return t;
}

function findTask(state, id) {
  return state.tasks.find(t => t.id === id) || null;
}

/* Update a task's fields. Subtask done-ticks are preserved
   by matching subtask titles (the editor edits titles as text). */
function updateTask(state, id, fields) {
  const t = findTask(state, id);
  if (!t) return null;
  if (fields.subtasks) {
    const old = t.subtasks || [];
    fields.subtasks = fields.subtasks.map(ns => {
      const match = old.find(o => o.title === ns.title);
      return match ? { id: match.id, title: ns.title, done: match.done, depth: ns.depth ? 1 : 0 }
                   : { id: makeId(), title: ns.title, done: false, depth: ns.depth ? 1 : 0 };
    });
  }
  Object.assign(t, fields);
  return t;
}

/* Remove a task. Returns it, so the screen can offer Undo. */
function removeTask(state, id) {
  const i = state.tasks.findIndex(t => t.id === id);
  if (i === -1) return null;
  return state.tasks.splice(i, 1)[0];
}

function restoreTask(state, task) {
  if (task && !findTask(state, task.id)) state.tasks.push(task);
}

/* ---------- completing tasks ---------- */

/* Mark done or not done. Completing also:
   - counts the day in state.completions (streaks/stats)
   - if the task repeats, creates the next occurrence       */
function setTaskDone(state, id, done, now) {
  const t = findTask(state, id);
  if (!t) return null;
  const n = now || new Date();
  if (done && t.status !== 'done') {
    t.status = 'done';
    t.completedAt = n.getTime();
    const key = todayStr(n);
    state.completions[key] = (state.completions[key] || 0) + 1;
    if (t.repeat !== 'none' && t.due) {
      const base = t.repeatBase === 'completion' ? key : t.due;
      let next = nextRepeatDate(base, t.repeat);
      while (next && next <= t.due) next = nextRepeatDate(next, t.repeat);
      while (next && next < key) next = nextRepeatDate(next, t.repeat);
      const copy = createTask({
        title: t.title, notes: t.notes, listId: t.listId, priority: t.priority,
        tags: t.tags.slice(), due: next, time: t.time, repeat: t.repeat,
        repeatBase: t.repeatBase, reminders: t.reminders.slice(),
        estMinutes: t.estMinutes,
        subtasks: t.subtasks.map(s => ({ id: makeId(), title: s.title, done: false, depth: s.depth || 0 }))
      });
      copy.order = t.order + 1;
      state.tasks.push(copy);
    }
  } else if (!done && t.status === 'done') {
    t.status = 'todo';
    if (t.completedAt) {
      const key = dateToStr(new Date(t.completedAt));
      if (state.completions[key]) {
        state.completions[key] -= 1;
        if (state.completions[key] <= 0) delete state.completions[key];
      }
    }
    t.completedAt = null;
  }
  return t;
}

function toggleSubtask(state, taskId, subId) {
  const t = findTask(state, taskId);
  if (!t) return;
  const s = t.subtasks.find(x => x.id === subId);
  if (s) s.done = !s.done;
}

/* { done, total, pct } for a task's subtask progress bar. */
function subtaskProgress(task) {
  const subs = task.subtasks || [];
  const done = subs.filter(s => s.done).length;
  return { done, total: subs.length, pct: subs.length ? Math.round(done / subs.length * 100) : 0 };
}

/* ---------- picking tasks for screens ---------- */

function isOpenTask(t) { return t.status !== 'done'; }

/* Overdue = open, due date passed (or due time passed today). */
function isOverdueTask(t, now) {
  if (!isOpenTask(t) || !t.due) return false;
  const today = todayStr(now);
  if (t.due < today) return true;
  if (t.due === today && t.time) {
    const n = now || new Date();
    return t.time < pad2(n.getHours()) + ':' + pad2(n.getMinutes());
  }
  return false;
}

const PRIORITY_RANK = { high: 0, med: 1, low: 2 };

function sortTasks(tasks, mode) {
  const arr = tasks.slice();
  if (mode === 'priority') {
    arr.sort((a, b) => (PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]) ||
      ((a.due || '9999') < (b.due || '9999') ? -1 : 1));
  } else if (mode === 'created') {
    arr.sort((a, b) => b.createdAt - a.createdAt);
  } else if (mode === 'manual') {
    arr.sort((a, b) => a.order - b.order);
  } else { /* 'due' — the default */
    arr.sort((a, b) => {
      const ad = a.due || '9999-99-99', bd = b.due || '9999-99-99';
      if (ad !== bd) return ad < bd ? -1 : 1;
      return PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority];
    });
  }
  return arr;
}

function searchTasks(tasks, query) {
  const q = (query || '').trim().toLowerCase();
  if (!q) return tasks;
  return tasks.filter(t =>
    t.title.toLowerCase().includes(q) ||
    (t.notes || '').toLowerCase().includes(q) ||
    t.subtasks.some(s => s.title.toLowerCase().includes(q)));
}

/* Everything the Today screen needs, in one call:
   focus (Top 3), overdue, today — all open tasks only. */
function tasksForToday(state, now) {
  const n = now || new Date();
  const today = todayStr(n);
  const open = state.tasks.filter(isOpenTask);
  return {
    focus: sortTasks(open.filter(t => t.focus), 'priority'),
    overdue: sortTasks(open.filter(t => isOverdueTask(t, n)), 'due'),
    today: sortTasks(open.filter(t => t.due === today && !t.focus), 'due')
  };
}

/* Numbers for the stats row + progress ring. */
function dayStats(state, now) {
  const n = now || new Date();
  const today = todayStr(n);
  const dueToday = state.tasks.filter(t => t.due === today);
  const doneDueToday = dueToday.filter(t => t.status === 'done').length;
  // streak: count back from today (or yesterday) while days have completions
  let streak = 0;
  let cursor = today;
  if (!state.completions[cursor]) cursor = addDaysStr(cursor, -1);
  while (state.completions[cursor] > 0) { streak += 1; cursor = addDaysStr(cursor, -1); }
  return {
    openCount: state.tasks.filter(isOpenTask).length,
    dueTodayCount: dueToday.length,
    doneDueToday,
    pctToday: dueToday.length ? Math.round(doneDueToday / dueToday.length * 100) : 0,
    doneToday: state.completions[today] || 0,
    streak,
    totalDone: state.tasks.filter(t => t.status === 'done').length
  };
}

/* Make the functions available to the Node tests. */

export { makeId, createTask, addTaskToState, findTask, updateTask, removeTask, restoreTask, setTaskDone, toggleSubtask, subtaskProgress, isOpenTask, isOverdueTask, sortTasks, searchTasks, tasksForToday, dayStats, PRIORITY_RANK };
