// ==========================================
// FILE: src/utils/planLogic.js
// WHAT: Pure logic — no screen code here.
// These functions only take data and give
// data back, so they are easy to test.
// (Proven logic, carried over from TYM v2.)
// ==========================================
/* ============================================================
   TYM — Track Your Mind · plan.js
   What this file does: SMART PLANNING, as pure functions.
   - arrangeDay: give untimed tasks sensible start times.
   - whatCanIDo: "I have 20 minutes and low energy — what
     should I do?" answered from the open task list.
   The Node tests check both.
   ============================================================ */

const PLAN_RANK = { high: 0, med: 1, low: 2 };

/* 'HH:MM' -> minutes since midnight, and back. */
function timeToMin(t) { const p = t.split(':').map(Number); return p[0] * 60 + p[1]; }
function minToTime(m) {
  return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
}

/* Arrange one day. Timed tasks keep their times (they are
   fixed appointments). Untimed tasks are placed into the
   free gaps, most important first, starting at dayStart.
   Returns [{ id, time }] for the tasks that got a time. */
function arrangeDay(tasks, dateStr, dayStart) {
  const start = timeToMin(dayStart || '09:00');
  const dayTasks = tasks.filter(t => t.status !== 'done' && t.due === dateStr);
  const busy = dayTasks.filter(t => t.time)
    .map(t => [timeToMin(t.time), timeToMin(t.time) + (t.estMinutes || 30)]);
  const untimed = dayTasks.filter(t => !t.time)
    .sort((a, b) => (PLAN_RANK[a.priority] - PLAN_RANK[b.priority]) ||
      ((a.estMinutes || 30) - (b.estMinutes || 30)));

  const placed = [];
  let cursor = start;
  for (const t of untimed) {
    const len = t.estMinutes || 30;
    // Move the cursor past any busy block it would overlap.
    let moved = true;
    while (moved) {
      moved = false;
      for (const [bs, be] of busy) {
        if (cursor < be && cursor + len > bs) { cursor = be; moved = true; }
      }
    }
    placed.push({ id: t.id, time: minToTime(cursor) });
    busy.push([cursor, cursor + len]);
    cursor += len;
  }
  return placed;
}

/* "What can I do now?" — tasks that fit the free minutes.
   energy 'high' prefers big/important work; 'low' prefers
   short, easy wins. Returns tasks, best first. */
function whatCanIDo(tasks, freeMinutes, energy) {
  const fits = tasks.filter(t => t.status !== 'done' && (t.estMinutes || 15) <= freeMinutes);
  return fits.sort((a, b) => {
    const ea = energyScore(a, energy), eb = energyScore(b, energy);
    if (ea !== eb) return eb - ea;
    return PLAN_RANK[a.priority] - PLAN_RANK[b.priority];
  });
}
function energyScore(t, energy) {
  const est = t.estMinutes || 15;
  if (energy === 'high') return (t.priority === 'high' ? 2 : 0) + (est >= 25 ? 1 : 0);
  if (energy === 'low') return (t.priority === 'low' ? 2 : 0) + (est <= 20 ? 1 : 0);
  return t.priority === 'med' ? 1 : 0;
}

export { arrangeDay, whatCanIDo, timeToMin, minToTime };
