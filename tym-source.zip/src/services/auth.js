// ==========================================
// FILE: src/services/auth.js
// WHAT: Login and account work — email +
// password, or "Continue with Google".
// Uses Firebase Authentication (free).
// This file talks to Firebase; screens
// only call these simple functions.
// ==========================================
import { initializeApp } from 'firebase/app';
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword,
  createUserWithEmailAndPassword, signInWithPopup,
  GoogleAuthProvider, signOut
} from 'firebase/auth';
import { FIREBASE_CONFIG, isFirebaseConfigured } from './firebaseConfig.js';

let auth = null;
if (isFirebaseConfigured()) {
  const app = initializeApp(FIREBASE_CONFIG);
  auth = getAuth(app);
}

/* Watch the login state. The callback gets the
   user object, or null when signed out. Returns
   a function that stops watching. */
export function watchUser(callback) {
  if (!auth) { callback(null); return () => {}; }
  return onAuthStateChanged(auth, callback);
}

export async function loginWithEmail(email, password) {
  return signInWithEmailAndPassword(auth, email, password);
}

export async function registerWithEmail(email, password) {
  return createUserWithEmailAndPassword(auth, email, password);
}

export async function loginWithGoogle() {
  return signInWithPopup(auth, new GoogleAuthProvider());
}

export async function logout() {
  return signOut(auth);
}

/* Friendly text for common Firebase auth errors. */
export function authErrorText(error) {
  const code = (error && error.code) || '';
  if (code.includes('invalid-credential') || code.includes('wrong-password') || code.includes('user-not-found')) {
    return 'Email or password is wrong. Check once and try again.';
  }
  if (code.includes('email-already-in-use')) return 'This email already has an account — login instead.';
  if (code.includes('weak-password')) return 'Password is too weak — use at least 6 characters.';
  if (code.includes('invalid-email')) return 'That email does not look right.';
  if (code.includes('popup-closed')) return 'Google window was closed — try again.';
  if (code.includes('network')) return 'Network problem — check the internet and try again.';
  return 'Something went wrong: ' + (error && error.message ? error.message : code);
}
