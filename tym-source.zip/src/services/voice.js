// ==========================================
// FILE: src/services/voice.js
// WHAT: Voice input — speak a task instead
// of typing it.
// In the phone app it uses Android's own
// speech engine (a plugin). In a browser it
// uses the browser's speech recognition.
// speakTask() resolves with the heard text,
// or null when voice is not available.
// ==========================================
import { isNativeApp } from './notifications.js';

export async function speakTask(showToast) {
  // Phone app path: Android speech engine.
  if (isNativeApp() && window.Capacitor.Plugins.SpeechRecognition) {
    const speech = window.Capacitor.Plugins.SpeechRecognition;
    try {
      const ask = speech.requestPermissions ? speech.requestPermissions()
        : (speech.requestPermission ? speech.requestPermission() : null);
      if (ask) {
        const permission = await ask;
        if (permission && permission.speechRecognition &&
            permission.speechRecognition !== 'granted') {
          showToast('Allow mic permission for voice');
          return null;
        }
      }
      showToast('🎙 Listening… speak your task');
      const result = await speech.start({
        language: 'en-IN', maxResults: 1, partialResults: false, popup: false
      });
      return (result && result.matches && result.matches[0]) || null;
    } catch (error) {
      showToast('Voice not available on this phone');
      return null;
    }
  }
  // Browser path: built-in speech recognition (Chrome).
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    showToast('Voice is not supported in this browser');
    return null;
  }
  return new Promise(resolve => {
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    showToast('🎙 Listening… speak your task');
    recognition.onresult = event => resolve(event.results[0][0].transcript);
    recognition.onerror = () => { showToast('Could not hear that — try again'); resolve(null); };
    recognition.onend = () => resolve(null);
    recognition.start();
  });
}
