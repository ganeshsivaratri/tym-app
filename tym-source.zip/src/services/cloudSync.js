// ==========================================
// FILE: src/services/cloudSync.js
// WHAT: Cloud backup + sync for a signed-in
// user. The whole app data is saved as one
// document in Firestore: users/{userId}.
// - On sign-in: newer copy wins (cloud vs
//   this device), the older one is replaced.
// - On any change: the new data is pushed
//   after a short pause (2.5 s debounce).
// Works offline-first: the app always saves
// on the device first; the cloud catches up
// when the internet is back.
// ==========================================
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { FIREBASE_CONFIG, isFirebaseConfigured } from './firebaseConfig.js';
import { parseState, stateToBackupText } from '../store/storage.js';

let database = null;
if (isFirebaseConfigured()) {
  const app = initializeApp(FIREBASE_CONFIG, 'tym-sync');
  database = getFirestore(app);
}

const SAVED_AT_KEY = 'tym-saved-at';
let lastSyncedText = null;
let pushTimer = null;

function localSavedAt() {
  try { return Number(localStorage.getItem(SAVED_AT_KEY) || 0); } catch (e) { return 0; }
}
function markLocalSaved(atMs) {
  try { localStorage.setItem(SAVED_AT_KEY, String(atMs)); } catch (e) {}
}

/* Start syncing for this user. getData() returns the current
   app data; replaceData(newData) swaps it (cloud won).
   Returns a stop function. */
export async function startCloudSync(user, getData, replaceData) {
  if (!database || !user) return () => {};
  const reference = doc(database, 'users', user.uid);
  try {
    const snapshot = await getDoc(reference);
    if (snapshot.exists()) {
      const cloud = snapshot.data();
      if (cloud && cloud.data && (cloud.savedAt || 0) > localSavedAt()) {
        // Cloud is newer — bring it down.
        lastSyncedText = cloud.data;
        replaceData(parseState(cloud.data));
        markLocalSaved(cloud.savedAt);
      } else {
        // This device is newer (or equal) — push it up.
        lastSyncedText = stateToBackupText(getData());
        await setDoc(reference, { data: lastSyncedText, savedAt: localSavedAt() || Date.now() });
      }
    } else {
      // First time: push this device's data up.
      lastSyncedText = stateToBackupText(getData());
      const now = Date.now();
      markLocalSaved(now);
      await setDoc(reference, { data: lastSyncedText, savedAt: now });
    }
  } catch (error) { /* offline or rules — the app keeps working locally */ }
  return () => {};
}

/* Call after every data change while signed in. */
export function scheduleCloudPush(user, data) {
  if (!database || !user) return;
  const text = stateToBackupText(data);
  if (text === lastSyncedText) return; // nothing new (or it came FROM the cloud)
  clearTimeout(pushTimer);
  pushTimer = setTimeout(async () => {
    try {
      const now = Date.now();
      await setDoc(doc(database, 'users', user.uid), { data: text, savedAt: now });
      lastSyncedText = text;
      markLocalSaved(now);
    } catch (error) { /* will retry on the next change */ }
  }, 2500);
}
