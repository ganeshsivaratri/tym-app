// ==========================================
// FILE: src/services/notifications.js
// WHAT: Everything about ringing.
// 1) In the phone app: schedules real phone
//    notifications (they ring when the app
//    is closed).
// 2) In a browser: a small engine checks
//    every 15 seconds and rings the alarm
//    view (page must be open).
// The maths of "when to ring" lives in
// utils/reminderLogic.js — this file only
// makes the sound and the schedule.
// ==========================================
import { reminderFireTimes } from '../utils/reminderLogic.js';

/* Are we inside the phone app (Capacitor)? */
export function isNativeApp() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform &&
    window.Capacitor.isNativePlatform());
}

function localNotifications() {
  return window.Capacitor && window.Capacitor.Plugins &&
    window.Capacitor.Plugins.LocalNotifications;
}

/* Ask the phone for notification permission (app only). */
export async function requestNotificationPermission() {
  if (!isNativeApp()) return false;
  try {
    const result = await localNotifications().requestPermissions();
    return result.display === 'granted';
  } catch (error) { return false; }
}

/* A stable numeric id for one reminder of one task. */
function notificationId(taskId, fireMs) {
  let hash = 0;
  const text = taskId + '@' + fireMs;
  for (let i = 0; i < text.length; i++) hash = (hash * 31 + text.charCodeAt(i)) >>> 0;
  return (hash % 2000000000) + 1;
}

/* Keep the phone's scheduled notifications equal to the
   data: cancel all, then schedule the next 50 reminders. */
export async function syncNativeNotifications(data) {
  if (!isNativeApp()) return;
  const plugin = localNotifications();
  if (!plugin) return;
  try {
    const pending = await plugin.getPending();
    if (pending.notifications && pending.notifications.length) {
      await plugin.cancel(pending);
    }
    const nowMs = Date.now();
    const toSchedule = [];
    for (const task of data.tasks) {
      if (task.status === 'done') continue;
      for (const fireMs of reminderFireTimes(task)) {
        if (fireMs > nowMs) {
          toSchedule.push({
            id: notificationId(task.id, fireMs),
            title: '⏰ ' + task.title,
            body: 'TYM reminder',
            schedule: { at: new Date(fireMs), allowWhileIdle: true }
          });
        }
      }
    }
    toSchedule.sort((a, b) => a.schedule.at - b.schedule.at);
    const first50 = toSchedule.slice(0, 50);
    if (first50.length) await plugin.schedule({ notifications: first50 });
  } catch (error) { /* scheduling is best-effort, never a crash */ }
}

/* ---------- browser alarm sound (WebAudio beep) ---------- */
let audioContext = null;
let beepTimer = null;

export function startAlarmSound() {
  stopAlarmSound();
  try {
    audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
    const beep = () => {
      if (!audioContext) return;
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = 880;
      gain.gain.setValueAtTime(0.0001, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.25, audioContext.currentTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.45);
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.5);
    };
    beep();
    beepTimer = setInterval(beep, 1200);
  } catch (error) { /* sound blocked — the alarm view still shows */ }
  try { if (navigator.vibrate) navigator.vibrate([300, 120, 300, 120, 300]); } catch (error) {}
}

export function stopAlarmSound() {
  if (beepTimer) { clearInterval(beepTimer); beepTimer = null; }
}

/* Browser notification popup (when permission was granted). */
export function showBrowserNotification(title) {
  try {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('⏰ ' + title, { body: 'TYM reminder' });
    }
  } catch (error) { /* notifications are a bonus, never a crash */ }
}
