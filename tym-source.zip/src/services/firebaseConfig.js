// ==========================================
// FILE: src/services/firebaseConfig.js
// WHAT: The address of TYM's Firebase
// project (Google's free backend). These
// values are NOT secret — they only say
// WHICH project the app talks to. The
// real protection is the Firestore rules
// (each user can touch only their own doc).
// Project: tym-track-your-mind (created
// 11 Nov 2026 in the user's Google account).
// ==========================================
export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyCeKkvJMgI2JM30xj-34ZdKSgO1a3aUxCc',
  authDomain: 'tym-track-your-mind.firebaseapp.com',
  projectId: 'tym-track-your-mind',
  storageBucket: 'tym-track-your-mind.firebasestorage.app',
  messagingSenderId: '878922875926',
  appId: '1:878922875926:web:c7407fc13d4cd326e06137'
};

/* True once the real console values are pasted in. */
export function isFirebaseConfigured() {
  return FIREBASE_CONFIG.apiKey !== 'FILL_FROM_FIREBASE_CONSOLE';
}
