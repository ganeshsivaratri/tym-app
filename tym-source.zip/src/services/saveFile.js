// ==========================================
// FILE: src/services/saveFile.js
// WHAT: Gives the user a file (backup JSON,
// calendar .ics). In the phone app this
// opens the Android share sheet — plain
// downloads do nothing inside the app.
// In a browser it does a normal download.
// saveFile() resolves true when the app
// share path handled it.
// ==========================================
import { isNativeApp } from './notifications.js';

export async function saveFile(filename, text, mimeType) {
  if (isNativeApp() && window.Capacitor.Plugins.Filesystem && window.Capacitor.Plugins.Share) {
    try {
      const filesystem = window.Capacitor.Plugins.Filesystem;
      const share = window.Capacitor.Plugins.Share;
      const written = await filesystem.writeFile({
        path: filename, directory: 'CACHE', data: text, encoding: 'utf8'
      });
      await share.share({ files: [written.uri] });
      return true;
    } catch (error) { return false; }
  }
  const blob = new Blob([text], { type: mimeType || 'text/plain' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
  return true;
}
