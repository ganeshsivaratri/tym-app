// ==========================================
// FILE: src/App.jsx
// WHAT: The app shell — sidebar, top area,
// bottom bar, and the place where the
// active screen is shown. It also starts
// the reminder engine and the theme.
// Screen content lives in src/screens/.
// ==========================================
import React, { useEffect, useRef, useState } from 'react';
import { AppProvider, useAppStore } from './store/AppStore.jsx';
import { SCREENS, BOTTOM_BAR_IDS } from './screens/screenList.js';
import TaskEditor from './components/TaskEditor.jsx';
import Toast from './components/Toast.jsx';
import AlarmOverlay from './components/AlarmOverlay.jsx';
import CommandPalette from './components/CommandPalette.jsx';
import Login from './screens/Login/Login.jsx';
import Onboarding from './screens/Onboarding/Onboarding.jsx';
import { watchUser } from './services/auth.js';
import { isFirebaseConfigured } from './services/firebaseConfig.js';
import { startCloudSync, scheduleCloudPush } from './services/cloudSync.js';
import { dueReminders } from './utils/reminderLogic.js';
import {
  isNativeApp, syncNativeNotifications,
  startAlarmSound, stopAlarmSound, showBrowserNotification
} from './services/notifications.js';
import './App.css';

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}

function Shell() {
  const store = useAppStore();
  const { data, changeData, setRingingTask, setEditingTask, editingTask } = store;

  /* Watch the Firebase login state (Stage 3). */
  useEffect(() => {
    if (!isFirebaseConfigured()) { store.setUser(null); return; }
    // Safety: if Firebase has not answered in 4 seconds
    // (slow network), show the login screen instead of
    // an endless loading screen.
    const safetyTimer = setTimeout(() => {
      if (store.user === 'loading') store.setUser(null);
    }, 4000);
    const stopWatching = watchUser(user => {
      clearTimeout(safetyTimer);
      store.setUser(user);
      if (user) store.setLoginRequested(false);
    });
    return () => { clearTimeout(safetyTimer); stopWatching(); };
  }, []);

  const [activeScreenId, setActiveScreenId] = useState('today');
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const dataRef = useRef(data);
  dataRef.current = data;
  const ringingRef = useRef(null);
  ringingRef.current = store.ringingTask;

  /* Theme: light / dark / auto (dark 19:00–07:00). */
  useEffect(() => {
    const applyTheme = () => {
      const setting = dataRef.current.settings.theme || 'light';
      const hour = new Date().getHours();
      const resolved = setting === 'auto'
        ? (hour >= 19 || hour < 7 ? 'dark' : 'light')
        : setting;
      document.documentElement.dataset.theme = resolved;
    };
    applyTheme();
    const timer = setInterval(applyTheme, 60000);
    return () => clearInterval(timer);
  }, [data.settings.theme]);

  /* Phone app: keep native notifications in step with data. */
  useEffect(() => { syncNativeNotifications(data); }, [data]);

  /* Cloud sync (Stage 4): start when a user signs in,
     push after changes while signed in. */
  const userId = store.user && store.user.uid;
  useEffect(() => {
    if (!userId) return;
    startCloudSync(store.user, () => dataRef.current, store.actions.replaceData);
  }, [userId]);
  useEffect(() => {
    if (userId) scheduleCloudPush(store.user, data);
  }, [data, userId]);

  /* Browser: check every 15 s whether a reminder should ring. */
  useEffect(() => {
    const check = () => {
      if (isNativeApp() || ringingRef.current) return;
      const due = dueReminders(dataRef.current, Date.now());
      if (due.length) {
        const first = due[0];
        changeData(draft => {
          draft.fired[first.key] = true;
          if (first.snoozeEnd) delete draft.snoozed[first.task.id];
        });
        setRingingTask(first.task);
        showBrowserNotification(first.task.title);
      }
    };
    const timer = setInterval(check, 15000);
    check();
    return () => clearInterval(timer);
  }, []);

  /* Alarm sound follows the ringing task. */
  useEffect(() => {
    if (store.ringingTask) startAlarmSound();
    else stopAlarmSound();
  }, [store.ringingTask]);

  /* Keyboard: Ctrl+K palette · Esc closes · n = new task. */
  useEffect(() => {
    const onKey = event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setPaletteOpen(open => !open);
      } else if (event.key === 'Escape') {
        setPaletteOpen(false);
      } else if (event.key === 'n' && !event.ctrlKey && !event.metaKey &&
        !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || '')) {
        setEditingTask(null);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [setEditingTask]);

  const groups = [];
  for (const screen of SCREENS) if (!groups.includes(screen.group)) groups.push(screen.group);
  const ActiveScreen = (SCREENS.find(s => s.id === activeScreenId) || SCREENS[0]).component;
  const bottomScreens = BOTTOM_BAR_IDS
    .map(id => SCREENS.find(s => s.id === id))
    .filter(Boolean);
  const cycleTheme = () => {
    const order = ['light', 'dark', 'auto'];
    const next = order[(order.indexOf(data.settings.theme || 'light') + 1) % order.length];
    changeData(draft => { draft.settings.theme = next; });
    store.showToast('Theme: ' + next);
  };

  /* First run ever → the 3 welcome slides. */
  if (!store.onboarded) {
    return <Onboarding finishOnboarding={store.finishOnboarding} />;
  }
  /* Login gate: signed out (and not a guest) → the login screen. */
  if (store.user === 'loading') {
    return <div className="app-loading">🧠 TYM is loading…</div>;
  }
  if (!store.user && (!store.guestMode || store.loginRequested)) {
    return <Login continueAsGuest={store.continueAsGuest} />;
  }

  return (
    <div>
      <div className="layout">
        <aside className="sidebar">
          <div className="brand"><span className="brand-mark">🧠</span>TYM<small>Track Your Mind</small></div>
          <nav>
            {groups.map(group => (
              <div key={group} className="nav-group">
                <h4>{group}</h4>
                {SCREENS.filter(s => s.group === group).map(screen => (
                  <button key={screen.id}
                    className={'nav-item' + (screen.id === activeScreenId ? ' active' : '')}
                    onClick={() => setActiveScreenId(screen.id)}>
                    <span>{screen.icon} {screen.name}</span>
                  </button>
                ))}
              </div>
            ))}
          </nav>
          <div className="side-foot">
            <button className="btn" onClick={cycleTheme}>🌙 Theme: {data.settings.theme || 'light'}</button>
          </div>
        </aside>
        <main className="main">
          <button className="mobile-menu-btn" onClick={() => setMenuOpen(true)}>☰ All screens</button>
          <ActiveScreen goToScreen={setActiveScreenId} />
        </main>
      </div>

      <nav className="bottombar">
        {bottomScreens.map(screen => (
          <a key={screen.id} href="#" className={screen.id === activeScreenId ? 'active' : ''}
            onClick={event => { event.preventDefault(); setActiveScreenId(screen.id); }}>
            <span className="bb-icon">{screen.icon}</span>{screen.name}
          </a>
        ))}
      </nav>

      {menuOpen && (
        <div className="mobile-menu" onClick={() => setMenuOpen(false)}>
          <div className="mobile-menu-card" onClick={event => event.stopPropagation()}>
            <h3>Screens</h3>
            {SCREENS.map(screen => (
              <button key={screen.id} className="pal-item"
                onClick={() => { setActiveScreenId(screen.id); setMenuOpen(false); }}>
                {screen.icon}  {screen.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {editingTask !== undefined && <TaskEditor />}
      {store.ringingTask && <AlarmOverlay />}
      {paletteOpen && (
        <CommandPalette screens={SCREENS} goToScreen={setActiveScreenId}
          closePalette={() => setPaletteOpen(false)} />
      )}
      <Toast />
    </div>
  );
}
