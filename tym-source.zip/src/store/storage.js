// ==========================================
// FILE: src/store/storage.js
// WHAT: Saves and loads the whole app data
// in the device storage (one JSON text).
// Also: daily snapshots + backup text.
// Same format as TYM v2 — old backups work.
// ==========================================
import { DEFAULT_LISTS } from './defaultData.js';
/* The name under which the state is saved in localStorage.
   If the state shape ever changes in a big way, bump v1 → v2
   and write a migration below. */
const TYM_STORAGE_KEY = 'tym-state-v1';

/* ---------- create a fresh, empty state ---------- */
function createDefaultState() {
  return {
    tasks: [],        // every task object (shape defined in DESIGN.md)
    lists: DEFAULT_LISTS.map(l => ({ id: l.id, name: l.name, color: l.color })),
    habits: [],       // Stage 5
    routines: [],     // Stage 5
    subjects: [],     // Stage 6
    timetable: [],    // Stage 6
    focusLog: [],     // Pomodoro sessions: { date, minutes }
    completions: {},  // { 'YYYY-MM-DD': how many tasks finished that day }
    templates: [],    // saved task templates (Stage 4)
    habitLog: {},     // { habitId: { 'YYYY-MM-DD': true } } (Stage 5)
    routineLog: {},   // { 'YYYY-MM-DD': { routineId: [done item indexes] } } (Stage 5)
    exams: [],        // { id, subject, date } (Stage 6)
    fired: {},        // reminder keys already rung: { 'taskId@ms': true }
    snoozed: {},      // { taskId: untilMs } after a snooze
    dayDoneCelebrated: {}, // { "YYYY-MM-DD": true } Day Complete shown (Stage 7)
    settings: { theme: 'light', sortDefault: 'due' }
  };
}

/* ---------- check: is this object a usable TYM state? ---------- */
function isValidState(s) {
  return !!s
    && Array.isArray(s.tasks)
    && Array.isArray(s.lists)
    && typeof s.settings === 'object' && s.settings !== null;
}

/* Turn saved text back into a state. Bad text → fresh state.
   The app must never crash because of a broken save file. */
function parseState(text) {
  try {
    const s = JSON.parse(text);
    if (isValidState(s)) return s;
  } catch (e) { /* fall through to a fresh state */ }
  return createDefaultState();
}

/* ---------- load / save (browser only) ---------- */
function loadState() {
  try {
    const raw = localStorage.getItem(TYM_STORAGE_KEY);
    if (raw) return parseState(raw);
  } catch (e) { /* storage blocked → run on a fresh state */ }
  return createDefaultState();
}

function saveState(state) {
  try {
    localStorage.setItem(TYM_STORAGE_KEY, JSON.stringify(state));
  } catch (e) { /* storage full/blocked → app keeps running in memory */ }
}

/* ---------- backup: export / import as a JSON file ---------- */
function stateToBackupText(state) {
  return JSON.stringify(state, null, 2);
}

/* ---------- automatic snapshots ----------
   Every day the app keeps one snapshot of the state (the
   newest 3 are kept). If something ever goes wrong, the
   user can restore one from Settings. Rotation is a pure
   function so the tests can check it. */
const TYM_SNAPSHOT_KEY = 'tym-snapshots-v1';

function rotateSnapshots(snaps, entry, keep) {
  const list = (snaps || []).filter(x => x.day !== entry.day).concat(entry);
  return list.slice(-(keep || 3));
}

function maybeSnapshot(state, now) {
  try {
    const day = todayStr(now);
    const raw = localStorage.getItem(TYM_SNAPSHOT_KEY);
    const snaps = raw ? JSON.parse(raw) : [];
    if (snaps.length && snaps[snaps.length - 1].day === day) return;
    const next = rotateSnapshots(snaps, { day, at: Date.now(), data: JSON.stringify(state) });
    localStorage.setItem(TYM_SNAPSHOT_KEY, JSON.stringify(next));
  } catch (e) { /* snapshots are a safety net, never a crash source */ }
}

function readSnapshots() {
  try {
    const raw = localStorage.getItem(TYM_SNAPSHOT_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}

export { TYM_STORAGE_KEY, createDefaultState, isValidState, parseState, stateToBackupText, rotateSnapshots, loadState, saveState, maybeSnapshot, readSnapshots };
