// ==========================================
// FILE: src/store/defaultData.js
// WHAT: Starter data only — the lists,
// routines and habit ideas a fresh app
// begins with. No logic lives here.
// ==========================================
/* The three lists every new user starts with.
   The user can rename, recolour, add and delete lists later. */
const DEFAULT_LISTS = [
  { id: 'personal', name: 'Personal', color: '#6d5cff' },
  { id: 'work',     name: 'Work',     color: '#0ea5e9' },
  { id: 'study',    name: 'Study',    color: '#f59e0b' }
];

/* A ready-made morning routine. Routines reset fresh every day
   (built in Stage 5 — Habits screen). */
const ROUTINE_TEMPLATES = [
  {
    id: 'morning',
    name: 'Morning Routine',
    items: ['Wake up', 'Drink water', 'Exercise / walk', 'Shower', 'Plan Top 3 for today']
  },
  {
    id: 'night',
    name: 'Night Routine',
    items: ['Review today', 'Move unfinished tasks', 'Set tomorrow Top 3', 'No phone 30 min', 'Sleep on time']
  }
];

/* Starter habits a user can pick from (Stage 5). */
const HABIT_IDEAS = ['Read 10 pages', 'Exercise', 'Meditate 5 min', 'No sugar', 'Study 1 hour', 'Write journal'];

export { DEFAULT_LISTS, ROUTINE_TEMPLATES, HABIT_IDEAS };
