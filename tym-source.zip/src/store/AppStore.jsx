// ==========================================
// FILE: src/store/AppStore.jsx
// WHAT: The heart of the app. It holds ALL
// the data in one place (the "store") and
// gives every screen the same actions:
// add a task, tick it, delete it, and so on.
// Rule of the app: data lives ONLY here.
// Screens ask the store — they never keep
// their own copy of the data.
// ==========================================
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { loadState, saveState, maybeSnapshot, createDefaultState } from './storage.js';
import * as taskLogic from '../utils/taskLogic.js';
import { todayStr } from '../utils/dates.js';

const AppContext = createContext(null);

// Any screen can call: const store = useAppStore();
export function useAppStore() {
  return useContext(AppContext);
}

export function AppProvider({ children }) {
  // The one data object for the whole app.
  const [data, setData] = useState(() => {
    const loaded = loadState();
    maybeSnapshot(loaded, new Date());
    return loaded;
  });
  // Small popup message at the bottom (with an Undo button sometimes).
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);
  // The task whose alarm is ringing right now (or null).
  const [ringingTask, setRingingTask] = useState(null);
  // The signed-in user (null = signed out, 'loading' at start).
  const [user, setUser] = useState('loading');
  // A guest chose "continue without an account" on this device.
  const [guestMode, setGuestMode] = useState(
    () => { try { return localStorage.getItem('tym-guest') === '1'; } catch (e) { return false; } });
  // True once the first-run welcome slides were seen.
  const [onboarded, setOnboarded] = useState(
    () => { try { return localStorage.getItem('tym-onboarded') === '1'; } catch (e) { return false; } });
  // True when a guest taps "Sign in" in Settings.
  const [loginRequested, setLoginRequested] = useState(false);
  // The task open in the editor (undefined = editor closed,
  // null = new task, object = editing that task).
  const [editingTask, setEditingTask] = useState(undefined);

  // Save after every change — no Save button anywhere.
  useEffect(() => { saveState(data); }, [data]);

  // Run a change on a copy of the data, then keep the copy.
  // (The proven logic helpers change objects in place,
  // so we hand them a clone and adopt the result.)
  const changeData = useCallback((changeFunction) => {
    setData(previous => {
      const copy = JSON.parse(JSON.stringify(previous));
      changeFunction(copy);
      return copy;
    });
  }, []);

  const showToast = useCallback((message, actionLabel, onAction) => {
    clearTimeout(toastTimer.current);
    setToast({ message, actionLabel, onAction });
    toastTimer.current = setTimeout(() => setToast(null), 4200);
  }, []);

  const actions = useMemo(() => ({
    // --- tasks ---
    addTask(taskFields) {
      let created = null;
      changeData(draft => { created = taskLogic.addTaskToState(draft, taskFields); });
      return created;
    },
    updateTask(taskId, taskFields) {
      changeData(draft => taskLogic.updateTask(draft, taskId, taskFields));
    },
    toggleTaskDone(task) {
      changeData(draft => taskLogic.setTaskDone(draft, task.id, task.status !== 'done', new Date()));
      if (task.status !== 'done') showToast('Done 🎉');
    },
    deleteTask(task) {
      let removed = null;
      changeData(draft => { removed = taskLogic.removeTask(draft, task.id); });
      if (removed) {
        showToast('Task deleted', 'Undo', () => {
          changeData(draft => taskLogic.restoreTask(draft, removed));
        });
      }
    },
    toggleTaskPin(task) {
      changeData(draft => {
        const found = taskLogic.findTask(draft, task.id);
        if (found) found.focus = !found.focus;
      });
    },
    addTemplate(taskFields) {
      changeData(draft => {
        draft.templates.push({
          id: taskLogic.makeId(), title: taskFields.title, notes: taskFields.notes,
          listId: taskFields.listId, priority: taskFields.priority,
          estMinutes: taskFields.estMinutes, repeat: taskFields.repeat,
          tags: (taskFields.tags || []).slice(),
          subtasks: (taskFields.subtasks || []).map(s => ({ title: s.title, depth: s.depth || 0 }))
        });
      });
    },
    deleteTemplate(templateId) {
      changeData(draft => {
        draft.templates = draft.templates.filter(t => t.id !== templateId);
      });
    },
    // --- whole-data actions (Settings uses these) ---
    replaceData(newData) { setData(newData); },
    eraseAll() {
      try { localStorage.removeItem('tym-state-v1'); } catch (error) {}
      setData(createDefaultState());
    },
    logFocusSession(minutes, taskId) {
      changeData(draft => {
        draft.focusLog.push({ date: todayStr(new Date()), minutes, taskId: taskId || null });
      });
    },
    toggleSubtask(task, subtaskIndex) {
      changeData(draft => taskLogic.toggleSubtask(draft, task.id, subtaskIndex));
    },
    moveAllOverdueToToday() {
      const now = new Date();
      let movedCount = 0;
      let oldDates = [];
      changeData(draft => {
        const overdueTasks = draft.tasks.filter(t => taskLogic.isOverdueTask(t, now));
        oldDates = overdueTasks.map(t => ({ id: t.id, due: t.due }));
        overdueTasks.forEach(t => { t.due = todayStr(now); });
        movedCount = overdueTasks.length;
      });
      if (movedCount) {
        showToast(movedCount + ' tasks moved to today', 'Undo', () => {
          changeData(draft => {
            oldDates.forEach(old => {
              const found = taskLogic.findTask(draft, old.id);
              if (found) found.due = old.due;
            });
          });
        });
      }
    }
  }), [changeData, showToast]);

  const value = {
    data, changeData, actions, showToast,
    user, setUser, guestMode, setGuestMode,
    loginRequested, setLoginRequested,
    onboarded,
    finishOnboarding() {
      try { localStorage.setItem('tym-onboarded', '1'); } catch (e) {}
      setOnboarded(true);
    },
    continueAsGuest() {
      try { localStorage.setItem('tym-guest', '1'); } catch (e) {}
      setGuestMode(true);
    },
    toast, setToast,
    ringingTask, setRingingTask,
    editingTask, setEditingTask
  };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
