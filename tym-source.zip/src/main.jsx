// ==========================================
// FILE: src/main.jsx
// WHAT: The starting point of the app.
// It puts the React app on the page.
// Nothing else happens here.
// ==========================================
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './theme.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
