// ==========================================
// FILE: src/screens/Timeline/timelineLogic.js
// WHAT: Brain of the Timeline screen —
// splits one day's tasks into timed and
// untimed, and counts the planned minutes.
// The arranging maths lives in
// utils/planLogic.js.
// ==========================================
import { sortTasks } from '../../utils/taskLogic.js';

export function splitDayTasks(data, dateText) {
  const dayTasks = data.tasks.filter(t => t.due === dateText && t.status !== 'done');
  return {
    timed: dayTasks.filter(t => t.time).sort((a, b) => a.time < b.time ? -1 : 1),
    untimed: sortTasks(dayTasks.filter(t => !t.time), 'priority'),
    plannedMinutes: dayTasks.reduce((sum, t) => sum + (t.estMinutes || 30), 0)
  };
}

export function formatMinutes(totalMinutes) {
  return Math.floor(totalMinutes / 60) + 'h ' + (totalMinutes % 60) + 'm';
}
