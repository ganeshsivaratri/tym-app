// ==========================================
// FILE: src/screens/Timeline/Timeline.jsx
// WHAT: The Timeline screen — one day laid
// out hour by hour, with "Plan My Day"
// (arranges untimed tasks) and "What can
// I do now?" (fits tasks into free time).
// ==========================================
import React, { useMemo, useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import TaskCard from '../../components/TaskCard.jsx';
import { arrangeDay, whatCanIDo } from '../../utils/planLogic.js';
import { findTask } from '../../utils/taskLogic.js';
import { todayStr, pad2 } from '../../utils/dates.js';
import { splitDayTasks, formatMinutes } from './timelineLogic.js';
import './timeline.css';

export default function Timeline() {
  const { data, setEditingTask, showToast, changeData } = useAppStore();
  const [dateText, setDateText] = useState(todayStr(new Date()));
  const [freeMinutes, setFreeMinutes] = useState(30);
  const [energy, setEnergy] = useState('med');
  const [picks, setPicks] = useState(null);

  const { timed, untimed, plannedMinutes } = useMemo(
    () => splitDayTasks(data, dateText), [data, dateText]);

  function planMyDay() {
    const placed = arrangeDay(data.tasks, dateText, '09:00');
    if (!placed.length) { showToast('Nothing to arrange — all tasks have times'); return; }
    const oldTimes = placed.map(p => ({ id: p.id, time: findTask(data, p.id)?.time || null }));
    changeData(draft => {
      for (const p of placed) {
        const task = findTask(draft, p.id);
        if (task) task.time = p.time;
      }
    });
    showToast('Day planned ✨', 'Undo', () => {
      changeData(draft => {
        for (const old of oldTimes) {
          const task = findTask(draft, old.id);
          if (task) task.time = old.time;
        }
      });
    });
  }

  function findPicks() {
    setPicks(whatCanIDo(data.tasks, freeMinutes, energy).slice(0, 5));
  }

  const hours = [];
  for (let h = 6; h <= 22; h++) hours.push(h);

  return (
    <div>
      <h1>🕐 Timeline</h1>
      <div className="toolbar">
        <input className="field tl-date" type="date" value={dateText}
          onChange={e => setDateText(e.target.value || todayStr(new Date()))} />
        <button className="btn btn-primary" onClick={planMyDay}>✨ Plan My Day</button>
        <span className="pill tl-pill">Planned: {formatMinutes(plannedMinutes)}</span>
      </div>

      <div className="card tl-card">
        <h2>⏱ What can I do now?</h2>
        <div className="toolbar tl-toolbar">
          <input className="field tl-free" type="number" min="5" step="5" value={freeMinutes}
            onChange={e => setFreeMinutes(parseInt(e.target.value, 10) || 30)} />
          <span className="tl-muted">free minutes · energy</span>
          <select className="field tl-energy" value={energy} onChange={e => setEnergy(e.target.value)}>
            <option value="high">High 🔋</option>
            <option value="med">Medium</option>
            <option value="low">Low 🪫</option>
          </select>
          <button className="btn" onClick={findPicks}>Find</button>
        </div>
        {picks !== null && (
          <div style={{ marginTop: 10 }}>
            {picks.length === 0
              ? <p className="tl-muted">Nothing fits that slot — enjoy the break. ☕</p>
              : picks.map(task => <TaskCard key={task.id} task={task} />)}
          </div>
        )}
      </div>

      {untimed.length > 0 && (
        <section>
          <div className="section-title">No time set</div>
          {untimed.map(task => <TaskCard key={task.id} task={task} />)}
        </section>
      )}

      <div className="card">
        {hours.map(hour => {
          const here = timed.filter(t => t.time.slice(0, 2) === pad2(hour));
          return (
            <div key={hour} className="tl-row">
              <div className="tl-hour">{pad2(hour)}:00</div>
              <div className="tl-slot">
                {here.length === 0
                  ? <span className="tl-free">free</span>
                  : here.map(task => (
                    <div key={task.id} className={'tl-item prio-border-' + task.priority}>
                      <b>{task.time}</b> {task.title}
                      {task.estMinutes > 0 && <span className="pill">⏱ {task.estMinutes}m</span>}
                      <button className="icon-btn" onClick={() => setEditingTask(task)}>✏️</button>
                    </div>
                  ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
