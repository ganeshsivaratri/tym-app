// ==========================================
// FILE: src/screens/Exams/examsLogic.js
// WHAT: Brain of the Exams screen — days
// left per exam and the revision rounds
// (7, 3 and 1 days before the exam).
// ==========================================
import { todayStr, addDaysStr, daysBetween } from '../../utils/dates.js';

export function examView(exam, now) {
  const days = daysBetween(todayStr(now), exam.date);
  const label = days < 0 ? 'done' : days === 0 ? 'TODAY 🔥' : days === 1 ? 'tomorrow' : days + ' days to go';
  const dateLabel = (() => {
    const parts = exam.date.split('-').map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2])
      .toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
  })();
  return { days, label, dateLabel };
}

/* The revision rounds that are still in the future. */
export function revisionRounds(exam, now) {
  const today = todayStr(now);
  return [
    { at: addDaysStr(exam.date, -7), name: 'Round 1 — full revision' },
    { at: addDaysStr(exam.date, -3), name: 'Round 2 — weak areas' },
    { at: addDaysStr(exam.date, -1), name: 'Final — formulas & key points' }
  ].filter(round => round.at >= today);
}
