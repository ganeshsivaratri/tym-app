// ==========================================
// FILE: src/screens/Exams/Exams.jsx
// WHAT: The Exams screen — countdown cards
// for every exam, and a one-tap revision
// plan (tasks at exam−7, exam−3, exam−1).
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { makeId } from '../../utils/taskLogic.js';
import { examView, revisionRounds } from './examsLogic.js';
import './exams.css';

export default function Exams() {
  const { data, actions, changeData, showToast } = useAppStore();
  const [subject, setSubject] = useState('');
  const [date, setDate] = useState('');
  const now = new Date();
  const exams = data.exams.slice().sort((a, b) => a.date < b.date ? -1 : 1);
  const studyListId = data.lists.some(l => l.id === 'study') ? 'study' : data.lists[0]?.id;

  function addExam() {
    if (!subject.trim() || !date) { showToast('Add a subject and a date'); return; }
    changeData(draft => {
      draft.exams.push({ id: makeId(), subject: subject.trim(), date });
    });
    setSubject('');
    setDate('');
  }
  function createPlan(exam) {
    const rounds = revisionRounds(exam, new Date());
    if (!rounds.length) { showToast('Exam is too close — revise today 💪'); return; }
    rounds.forEach(round => actions.addTask({
      title: exam.subject + ': ' + round.name,
      due: round.at, listId: studyListId, priority: 'high', tags: ['revision', 'exam']
    }));
    showToast('Revision plan created: ' + rounds.length + ' tasks 🗓');
  }
  function deleteExam(examId) {
    changeData(draft => {
      draft.exams = draft.exams.filter(x => x.id !== examId);
    });
  }

  return (
    <div>
      <h1>⏳ Exams</h1>
      <div className="toolbar">
        <input className="field" placeholder="Subject — e.g. Compiler Design" value={subject}
          onChange={e => setSubject(e.target.value)} />
        <input className="field exams-date" type="date" value={date} onChange={e => setDate(e.target.value)} />
        <button className="btn btn-primary" onClick={addExam}>Add exam</button>
      </div>
      {exams.length === 0
        ? <div className="card empty"><div className="empty-art">⏳</div>
            <p>No exams yet. Add one above and the countdown begins.</p></div>
        : (
          <div className="exam-grid">
            {exams.map(exam => {
              const view = examView(exam, now);
              return (
                <div key={exam.id} className="card exam-card">
                  <div className="exam-days">{view.days < 0 ? '✓' : view.days}</div>
                  <div className="exam-label">{view.days >= 0 ? 'days' : ''}</div>
                  <h2 className="exam-subject">{exam.subject}</h2>
                  <p className="exam-meta">{view.dateLabel} · {view.label}</p>
                  <button className="btn" onClick={() => createPlan(exam)}>🗓 Revision plan</button>
                  <button className="icon-btn" title="Delete exam" onClick={() => deleteExam(exam.id)}>🗑</button>
                </div>
              );
            })}
          </div>
        )}
    </div>
  );
}
