// ==========================================
// FILE: src/screens/Login/Login.jsx
// WHAT: The login screen — shown before
// the app when a user is signed out.
// Email + password, or Google. A guest
// can also continue without an account
// (data stays on this device only).
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { loginWithEmail, registerWithEmail, loginWithGoogle, authErrorText } from '../../services/auth.js';
import { isNativeApp } from '../../services/notifications.js';
import './login.css';

export default function Login({ continueAsGuest }) {
  const { showToast } = useAppStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  /* Errors show ON this card, in red — a toast alone was
     invisible on this screen, so failures looked silent. */
  const [errorText, setErrorText] = useState('');

  async function runAuth(action) {
    setBusy(true);
    setErrorText('');
    try { await action(); }
    catch (error) {
      const code = (error && error.code) || '';
      setErrorText(authErrorText(error) + (code ? ' [' + code + ']' : ''));
      showToast(authErrorText(error));
    }
    setBusy(false);
  }

  /* Google's popup sign-in is blocked inside Android
     WebViews (the app shell) — say so plainly instead of
     failing silently. On the web it works normally. */
  function handleGoogle() {
    if (isNativeApp()) {
      setErrorText('Google sign-in does not work inside the Android app yet. Please use email + password here — the same account also works with Google on the web version.');
      return;
    }
    runAuth(loginWithGoogle);
  }

  return (
    <div className="login-wrap">
      <div className="card login-card">
        <div className="login-brand">🧠</div>
        <h1 className="login-title">TYM</h1>
        <p className="login-sub">Track Your Mind — your tasks, habits and focus, in one place.</p>

        <label className="f-label">Email</label>
        <input className="field" type="email" value={email} placeholder="you@example.com"
          onChange={e => setEmail(e.target.value)} />
        <label className="f-label">Password</label>
        <input className="field" type="password" value={password} placeholder="••••••••"
          onChange={e => setPassword(e.target.value)} />

        <button className="btn btn-primary login-btn" disabled={busy}
          onClick={() => runAuth(() => loginWithEmail(email.trim(), password))}>
          Login</button>
        <button className="btn login-btn" disabled={busy}
          onClick={() => runAuth(() => registerWithEmail(email.trim(), password))}>
          Create account</button>
        <button className="btn login-btn" disabled={busy}
          onClick={handleGoogle}>
          Continue with Google</button>

        {errorText ? <p className="login-error">{errorText}</p> : null}

        <button className="login-guest" onClick={continueAsGuest}>
          Continue without an account →
        </button>
        <p className="login-note">With an account, your data backs up to the cloud and
          follows you to any phone. Without one, it stays only on this device.</p>
      </div>
    </div>
  );
}
