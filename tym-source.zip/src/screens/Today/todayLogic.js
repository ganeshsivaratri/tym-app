// ==========================================
// FILE: src/screens/Today/todayLogic.js
// WHAT: Brain of the Today screen.
// It prepares everything the screen shows:
// the greeting, today's task groups, the
// stats and the pinned Top 3 tasks.
// It does NOT draw anything.
// ==========================================
import { tasksForToday, dayStats, isOpenTask, sortTasks } from '../../utils/taskLogic.js';
import { todayStr, addDaysStr } from '../../utils/dates.js';

/* "Good morning ☀️" style greeting for the hour. */
export function greetingFor(now) {
  const hour = now.getHours();
  if (hour < 5) return { emoji: '🌙', text: 'Still up' };
  if (hour < 12) return { emoji: '☀️', text: 'Good morning' };
  if (hour < 17) return { emoji: '🌤️', text: 'Good afternoon' };
  if (hour < 21) return { emoji: '🌆', text: 'Good evening' };
  return { emoji: '🌙', text: 'Good night' };
}

/* "Monday 10 November" style date line. */
export function dateLineFor(now) {
  return now.toLocaleDateString('en-IN', {
    weekday: 'long', day: 'numeric', month: 'long'
  });
}

/* Everything the Today screen needs, in one object. */
export function buildTodayView(data, now) {
  const groups = tasksForToday(data, now); // { focus, overdue, today }
  // Tomorrow is not part of tasksForToday, so add it here:
  const tomorrowDate = addDaysStr(todayStr(now), 1);
  groups.tomorrow = sortTasks(
    data.tasks.filter(t => isOpenTask(t) && t.due === tomorrowDate && !t.focus), 'due');
  return {
    groups,
    stats: dayStats(data, now),             // done count, streak, % of today
    pinnedTasks: data.tasks.filter(t => t.focus && t.status !== 'done')
  };
}
