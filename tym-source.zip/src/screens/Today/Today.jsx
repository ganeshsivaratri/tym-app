// ==========================================
// FILE: src/screens/Today/Today.jsx
// WHAT: The Today screen (what the user
// sees first). Quick add, My Day Top 3,
// today's progress, and today's tasks.
// Thinking happens in todayLogic.js —
// this file only shows and handles taps.
// ==========================================
import React, { useMemo, useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import TaskCard from '../../components/TaskCard.jsx';
import { parseQuickAdd } from '../../utils/textParse.js';
import { buildTodayView, greetingFor, dateLineFor } from './todayLogic.js';
import { speakTask } from '../../services/voice.js';
import { isNativeApp } from '../../services/notifications.js';
import './today.css';

export default function Today() {
  const { data, actions, setEditingTask, showToast, changeData } = useAppStore();
  const [quickText, setQuickText] = useState('');
  const now = new Date();
  const view = useMemo(() => buildTodayView(data, new Date()), [data]);
  const greeting = greetingFor(now);

  function quickAdd(textToAdd) {
    const text = (textToAdd != null ? textToAdd : quickText).trim();
    if (!text) return;
    const fields = parseQuickAdd(text, new Date());
    actions.addTask({ ...fields, listId: data.lists[0]?.id || 'personal' });
    setQuickText('');
    showToast('Task added ✓');
  }

  async function voiceAdd() {
    const heard = await speakTask(showToast);
    if (heard) quickAdd(heard);
  }

  const allTodayDone = view.stats.dueTodayCount > 0 &&
    view.stats.doneDueToday === view.stats.dueTodayCount;
  const todayKey = now.toISOString().slice(0, 10);
  const showDayComplete = allTodayDone && !data.dayDoneCelebrated[todayKey];

  return (
    <div>
      <h1>{greeting.emoji} Today</h1>
      <p className="greeting">{greeting.text} · {dateLineFor(now)}</p>

      <div className="quick">
        <input className="field" placeholder="Type here…" value={quickText}
          onChange={e => setQuickText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') quickAdd(); }} />
        <button className="btn btn-primary" onClick={() => quickAdd()}>Add</button>
        <button className="btn" title="Speak your task" onClick={voiceAdd}>🎙</button>
        <button className="btn" onClick={() => setEditingTask(null)}>＋ Full Task</button>
        {!isNativeApp() && (
          <button className="btn" title="Print my day" onClick={() => window.print()}>🖨</button>
        )}
      </div>

      <div className="focus-banner">
        <h2>🎯 My Day — Top 3</h2>
        {view.pinnedTasks.length === 0
          ? <div className="fb-task">Pin up to 3 tasks with 📌 to plan your day.</div>
          : view.pinnedTasks.map(task => <TaskCard key={task.id} task={task} />)}
      </div>

      <div className="card ring-wrap">
        <Ring percent={view.stats.pctToday} />
        <div>
          <div className="ring-num">{view.stats.pctToday}% of today done</div>
          <div className="ring-sub">{view.stats.doneDueToday} of {view.stats.dueTodayCount} tasks due today complete</div>
          <div className="ring-sub">🔥 {view.stats.streak} day streak · {view.stats.openCount} open tasks</div>
        </div>
      </div>

      {view.groups.overdue.length > 0 && (
        <section>
          <div className="section-title">⚠️ Overdue
            <button className="btn move-btn" onClick={() => actions.moveAllOverdueToToday()}>📅 Move all to today</button>
          </div>
          {view.groups.overdue.map(task => <TaskCard key={task.id} task={task} />)}
        </section>
      )}

      <div className="section-title">📅 Today</div>
      {view.groups.today.length === 0
        ? <div className="card empty"><div className="empty-art">🌅</div>
            <p>Nothing due today. Add a task above, or enjoy the calm.</p></div>
        : view.groups.today.map(task => <TaskCard key={task.id} task={task} />)}

      {view.groups.tomorrow.length > 0 && (
        <section>
          <div className="section-title">🌅 Tomorrow</div>
          {view.groups.tomorrow.map(task => <TaskCard key={task.id} task={task} />)}
        </section>
      )}

      {showDayComplete && (
        <div className="day-complete">
          <div className="dc-emoji">🎉</div>
          <div className="dc-title">Day Complete!</div>
          <p>Every task due today is done. Rest well — tomorrow is a fresh page.</p>
          <button className="btn btn-primary" onClick={() =>
            changeData(draft => { draft.dayDoneCelebrated[todayKey] = true; })}>Close</button>
        </div>
      )}
    </div>
  );
}

/* The round progress ring (SVG circle). */
function Ring({ percent }) {
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const filled = circumference * (percent / 100);
  return (
    <svg className="ring" width="84" height="84" viewBox="0 0 84 84">
      <circle className="ring-bg" cx="42" cy="42" r={radius} />
      <circle className="ring-fg" cx="42" cy="42" r={radius}
        strokeDasharray={filled + ' ' + circumference}
        transform="rotate(-90 42 42)" />
    </svg>
  );
}
