// ==========================================
// FILE: src/screens/screenList.js
// WHAT: The list of all screens in the app.
// The sidebar, the phone bottom bar and the
// Ctrl+K jumper all read this one list —
// add a screen here and it appears in all
// three places.
// ==========================================
import Today from './Today/Today.jsx';
import All from './All/All.jsx';
import Calendar from './Calendar/Calendar.jsx';
import Board from './Board/Board.jsx';
import Matrix from './Matrix/Matrix.jsx';
import Timeline from './Timeline/Timeline.jsx';
import Habits from './Habits/Habits.jsx';
import Focus from './Focus/Focus.jsx';
import Review from './Review/Review.jsx';
import Study from './Study/Study.jsx';
import Exams from './Exams/Exams.jsx';
import Timetable from './Timetable/Timetable.jsx';
import Completed from './Completed/Completed.jsx';
import Guide from './Guide/Guide.jsx';
import Settings from './Settings/Settings.jsx';

export const SCREENS = [
  { id: 'today', name: 'Today', icon: '☀️', group: 'Plan', component: Today },
  { id: 'all', name: 'All Tasks', icon: '🗂️', group: 'Plan', component: All },
  { id: 'calendar', name: 'Calendar', icon: '📅', group: 'Plan', component: Calendar },
  { id: 'board', name: 'Board', icon: '📋', group: 'Views', component: Board },
  { id: 'matrix', name: 'Matrix', icon: '🎯', group: 'Views', component: Matrix },
  { id: 'timeline', name: 'Timeline', icon: '🕐', group: 'Views', component: Timeline },
  { id: 'habits', name: 'Habits', icon: '🔥', group: 'Grow', component: Habits },
  { id: 'focus', name: 'Focus', icon: '🍅', group: 'Grow', component: Focus },
  { id: 'review', name: 'Review', icon: '📊', group: 'Grow', component: Review },
  { id: 'study', name: 'Study', icon: '📚', group: 'Students', component: Study },
  { id: 'exams', name: 'Exams', icon: '⏳', group: 'Students', component: Exams },
  { id: 'timetable', name: 'Timetable', icon: '🏫', group: 'Students', component: Timetable },
  { id: 'completed', name: 'Completed', icon: '✅', group: 'More', component: Completed },
  { id: 'guide', name: 'Guide', icon: '❓', group: 'More', component: Guide },
  { id: 'settings', name: 'Settings', icon: '⚙️', group: 'More', component: Settings }
];

// The 5 screens shown in the phone bottom bar.
export const BOTTOM_BAR_IDS = ['today', 'calendar', 'habits', 'focus', 'settings'];
