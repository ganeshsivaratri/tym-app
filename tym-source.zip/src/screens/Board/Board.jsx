// ==========================================
// FILE: src/screens/Board/Board.jsx
// WHAT: The Board screen — Kanban columns
// To do / Doing / Done. Drag a card to
// another column to move it. Dropping
// into Done completes the task properly
// (streaks and repeats still work).
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { BOARD_COLUMNS, tasksInColumn } from './boardLogic.js';
import { dueLabel } from '../../utils/dates.js';
import './board.css';

export default function Board() {
  const { data, actions, setEditingTask, changeData } = useAppStore();
  const [dragOverColumn, setDragOverColumn] = useState(null);

  function dropTask(taskId, columnId) {
    const task = data.tasks.find(t => t.id === taskId);
    if (!task || task.status === columnId) return;
    if (columnId === 'done') {
      actions.toggleTaskDone({ ...task, status: 'todo' });
    } else if (task.status === 'done') {
      actions.toggleTaskDone({ ...task, status: 'done' });
      changeData(draft => {
        const found = draft.tasks.find(t => t.id === taskId);
        if (found) found.status = columnId;
      });
    } else {
      changeData(draft => {
        const found = draft.tasks.find(t => t.id === taskId);
        if (found) found.status = columnId;
      });
    }
  }

  return (
    <div>
      <h1>📋 Board</h1>
      <div className="board">
        {BOARD_COLUMNS.map(column => {
          const tasks = tasksInColumn(data, column.id);
          return (
            <div key={column.id}
              className={'board-col' + (dragOverColumn === column.id ? ' dragover' : '')}
              onDragOver={e => { e.preventDefault(); setDragOverColumn(column.id); }}
              onDragLeave={() => setDragOverColumn(null)}
              onDrop={e => {
                e.preventDefault();
                setDragOverColumn(null);
                dropTask(e.dataTransfer.getData('text/tym-task'), column.id);
              }}>
              <h3>{column.icon} {column.name} <span className="badge">{tasks.length}</span></h3>
              {tasks.length === 0 && <p className="board-empty">Drop tasks here</p>}
              {tasks.map(task => (
                <div key={task.id} className="board-card" draggable
                  onDragStart={e => e.dataTransfer.setData('text/tym-task', task.id)}>
                  <div className="board-card-title">{task.title}</div>
                  <div className="task-meta">
                    <span className={'pill prio-' + task.priority}>{task.priority}</span>
                    {task.due && <span className="pill">{dueLabel(task.due, new Date())}</span>}
                    <button className="icon-btn" onClick={() => setEditingTask(task)}>✏️</button>
                  </div>
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
