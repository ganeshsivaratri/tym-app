// ==========================================
// FILE: src/screens/Board/boardLogic.js
// WHAT: Brain of the Board screen — the
// three Kanban columns and which tasks
// belong in each.
// ==========================================
import { sortTasks } from '../../utils/taskLogic.js';

export const BOARD_COLUMNS = [
  { id: 'todo', name: 'To do', icon: '📝' },
  { id: 'doing', name: 'Doing', icon: '🚧' },
  { id: 'done', name: 'Done', icon: '✅' }
];

export function tasksInColumn(data, columnId) {
  return sortTasks(data.tasks.filter(t => t.status === columnId), 'priority');
}
