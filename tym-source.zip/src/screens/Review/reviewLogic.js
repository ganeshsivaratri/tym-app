// ==========================================
// FILE: src/screens/Review/reviewLogic.js
// WHAT: Brain of the Review screen —
// prepares the XP card, the week bars,
// the year heatmap and the habit rows.
// All maths lives in utils/progressLogic.
// ==========================================
import { weekSummary, lastNDays, longestStreak, totalXP, levelFor } from '../../utils/progressLogic.js';
import { dayStats } from '../../utils/taskLogic.js';

export function buildReview(data, now) {
  const week = weekSummary(data.completions, now);
  const yearDays = lastNDays(364, now);
  const maxYearCount = Math.max(1, ...yearDays.map(d => data.completions[d] || 0));
  const last28 = lastNDays(28, now);
  const xp = totalXP(data);
  return {
    stats: dayStats(data, now),
    week,
    weekTotal: week.reduce((sum, d) => sum + d.count, 0),
    weekMax: Math.max(1, ...week.map(d => d.count)),
    longestStreak: longestStreak(data.completions),
    focusTotal: data.focusLog.reduce((sum, s) => sum + s.minutes, 0),
    focusWeek: data.focusLog
      .filter(s => lastNDays(7, now).includes(s.date))
      .reduce((sum, s) => sum + s.minutes, 0),
    yearCells: yearDays.map(date => {
      const count = data.completions[date] || 0;
      return {
        date, count,
        level: count === 0 ? 0 : Math.min(4, Math.ceil(count / maxYearCount * 4))
      };
    }),
    habitRows: data.habits.map(habit => {
      const log = data.habitLog[habit.id] || {};
      return {
        name: habit.name,
        doneCount: last28.filter(d => log[d]).length,
        days: last28.map(date => ({ date, done: !!log[date] }))
      };
    }),
    xp,
    level: levelFor(xp)
  };
}

/* "M" style one-letter weekday for a date text. */
export function weekdayLetter(dateText) {
  const parts = dateText.split('-').map(Number);
  return new Date(parts[0], parts[1] - 1, parts[2])
    .toLocaleDateString('en-IN', { weekday: 'narrow' });
}
