// ==========================================
// FILE: src/screens/Review/Review.jsx
// WHAT: The Review screen — proof of work:
// XP level, this week's bars, a year
// heatmap, focus time and habit dots.
// Every number is real, from the store.
// ==========================================
import React, { useMemo } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { buildReview, weekdayLetter } from './reviewLogic.js';
import './review.css';

export default function Review() {
  const { data } = useAppStore();
  const review = useMemo(() => buildReview(data, new Date()), [data]);
  const { stats, level } = review;

  return (
    <div>
      <h1>📊 Review</h1>

      <div className="card xp-card">
        <div>
          <div className="ring-num">{level.current.name}</div>
          <div className="review-muted">{review.xp} XP
            {level.next ? ' · ' + (level.next.xp - review.xp) + ' XP to ' + level.next.name : ' · top level!'}</div>
        </div>
        <div className="progress review-progress">
          <div style={{ width: level.pctToNext + '%' }}></div>
        </div>
      </div>

      <div className="stat-grid review-stats">
        <div className="stat"><b>{stats.totalDone}</b><span>tasks done (all time)</span></div>
        <div className="stat"><b>{review.weekTotal}</b><span>done this week</span></div>
        <div className="stat"><b>{review.longestStreak} 🔥</b><span>longest streak</span></div>
        <div className="stat"><b>{review.focusTotal}m</b><span>focus time ({review.focusWeek}m this week)</span></div>
      </div>

      <div className="card review-card">
        <h2>This week</h2>
        <div className="bars">
          {review.week.map(day => (
            <div key={day.date} className="bar-col">
              <div className="bar" title={day.date + ': ' + day.count}
                style={{ height: Math.max(4, Math.round(day.count / review.weekMax * 100)) + '%' }}></div>
              <span>{weekdayLetter(day.date)}</span><b>{day.count}</b>
            </div>
          ))}
        </div>
      </div>

      <div className="card review-card">
        <h2>Your year of showing up</h2>
        <div className="heat-wrap">
          {review.yearCells.map(cell => (
            <span key={cell.date} className={'heat heat-' + cell.level}
              title={cell.date + ': ' + cell.count + ' done'}></span>
          ))}
        </div>
        <p className="review-note">Each square is a day. Darker = more tasks finished.</p>
      </div>

      {review.habitRows.length > 0 && (
        <div className="card review-card">
          <h2>Habits — last 28 days</h2>
          {review.habitRows.map(row => (
            <div key={row.name} className="habit-review">
              <span className="habit-review-name">{row.name} · {row.doneCount}/28</span>
              <span className="habit-dots">
                {row.days.map(day => (
                  <span key={day.date} className={'habit-dot' + (day.done ? ' on' : '')} title={day.date}></span>
                ))}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
