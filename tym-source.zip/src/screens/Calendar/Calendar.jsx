// ==========================================
// FILE: src/screens/Calendar/Calendar.jsx
// WHAT: The Calendar screen — a month grid
// with task counts per day. Click a day
// to see its tasks. Drag a task onto a
// day to move it there.
// ==========================================
import React, { useMemo, useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import TaskCard from '../../components/TaskCard.jsx';
import { sortTasks } from '../../utils/taskLogic.js';
import { todayStr, dueLabel } from '../../utils/dates.js';
import { monthCells, dayHeading, WEEKDAY_NAMES } from './calendarLogic.js';
import './calendar.css';

export default function Calendar() {
  const { data, changeData, showToast } = useAppStore();
  const start = new Date();
  const [year, setYear] = useState(start.getFullYear());
  const [month, setMonth] = useState(start.getMonth());
  const [selectedDay, setSelectedDay] = useState(todayStr(start));

  const { monthName, cells } = useMemo(
    () => monthCells(year, month, data.tasks), [year, month, data.tasks]);
  const dayTasks = sortTasks(
    data.tasks.filter(t => t.due === selectedDay && t.status !== 'done'), 'due');
  const doneCount = data.tasks.filter(
    t => t.due === selectedDay && t.status === 'done').length;
  const today = todayStr(new Date());

  function moveMonth(delta) {
    let newMonth = month + delta;
    let newYear = year;
    if (newMonth < 0) { newMonth = 11; newYear -= 1; }
    if (newMonth > 11) { newMonth = 0; newYear += 1; }
    setMonth(newMonth);
    setYear(newYear);
  }
  function goToday() {
    const now = new Date();
    setYear(now.getFullYear());
    setMonth(now.getMonth());
    setSelectedDay(todayStr(now));
  }
  function dropOnDay(event, dateText) {
    event.preventDefault();
    const taskId = event.dataTransfer.getData('text/tym-task');
    changeData(draft => {
      const task = draft.tasks.find(t => t.id === taskId);
      if (task && task.due !== dateText) {
        task.due = dateText;
        showToast('Moved to ' + dueLabel(dateText, new Date()));
      }
    });
  }

  return (
    <div>
      <h1>📅 Calendar</h1>
      <div className="cal-head">
        <button className="btn" onClick={() => moveMonth(-1)}>‹</button>
        <h2 style={{ margin: 0 }}>{monthName}</h2>
        <button className="btn" onClick={() => moveMonth(1)}>›</button>
        <button className="btn" onClick={goToday}>Today</button>
      </div>
      <div className="cal-grid cal-week">
        {WEEKDAY_NAMES.map(name => <div key={name}>{name}</div>)}
      </div>
      <div className="cal-grid">
        {cells.map(cell => cell.blank
          ? <div key={cell.key} className="cal-cell cal-blank"></div>
          : (
            <button key={cell.key}
              className={'cal-cell' + (cell.dateText === today ? ' cal-today' : '') +
                (cell.dateText === selectedDay ? ' cal-sel' : '')}
              onClick={() => setSelectedDay(cell.dateText)}
              onDragOver={e => e.preventDefault()}
              onDrop={e => dropOnDay(e, cell.dateText)}>
              <span className="cal-num">{cell.dayNumber}</span>
              {cell.count > 0 && (
                <span className="cal-dots">{'●'.repeat(Math.min(cell.count, 5))}
                  <span className="cal-count">{cell.count}</span></span>
              )}
            </button>
          ))}
      </div>
      <div className="section-title">
        {dueLabel(selectedDay, new Date())} — {dayHeading(selectedDay)}
        {doneCount > 0 ? ' · ' + doneCount + ' done' : ''}
      </div>
      {dayTasks.length === 0
        ? <div className="card empty"><p>No open tasks this day. Drag a task card onto a day to move it.</p></div>
        : dayTasks.map(task => (
          <div key={task.id} draggable
            onDragStart={e => e.dataTransfer.setData('text/tym-task', task.id)}>
            <TaskCard task={task} />
          </div>
        ))}
    </div>
  );
}
