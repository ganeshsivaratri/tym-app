// ==========================================
// FILE: src/screens/Calendar/calendarLogic.js
// WHAT: Brain of the Calendar screen —
// builds the month grid numbers (which
// days exist, how many tasks each has)
// and the day names for the header.
// ==========================================
import { pad2 } from '../../utils/dates.js';

export const WEEKDAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/* All the cells of one month view. */
export function monthCells(year, month, tasks) {
  const firstDay = new Date(year, month, 1);
  const leadBlanks = (firstDay.getDay() + 6) % 7; // weeks start on Monday
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Count open tasks per day.
  const counts = {};
  for (const task of tasks) {
    if (task.status === 'done' || !task.due) continue;
    counts[task.due] = (counts[task.due] || 0) + 1;
  }

  const cells = [];
  for (let i = 0; i < leadBlanks; i++) cells.push({ blank: true, key: 'b' + i });
  for (let day = 1; day <= daysInMonth; day++) {
    const dateText = year + '-' + pad2(month + 1) + '-' + pad2(day);
    cells.push({ blank: false, key: dateText, dateText, dayNumber: day, count: counts[dateText] || 0 });
  }
  return {
    monthName: firstDay.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' }),
    cells
  };
}

/* "Monday 10 November" for the selected day's heading. */
export function dayHeading(dateText) {
  const parts = dateText.split('-').map(Number);
  return new Date(parts[0], parts[1] - 1, parts[2])
    .toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });
}
