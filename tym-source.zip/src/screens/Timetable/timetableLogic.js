// ==========================================
// FILE: src/screens/Timetable/timetableLogic.js
// WHAT: Brain of the Timetable screen —
// day names and today's column index.
// Days are stored as 0 = Monday … 6 = Sunday.
// ==========================================
export const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export function todayIndex(now) {
  return (now.getDay() + 6) % 7; // Monday = 0
}

export function entriesForDay(data, dayIndex) {
  return data.timetable
    .filter(entry => entry.day === dayIndex)
    .sort((a, b) => a.start < b.start ? -1 : 1);
}
