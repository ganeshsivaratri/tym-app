// ==========================================
// FILE: src/screens/Timetable/Timetable.jsx
// WHAT: The Timetable screen — the weekly
// class schedule as a 7-column grid.
// Today's column is highlighted.
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { makeId } from '../../utils/taskLogic.js';
import { DAY_NAMES, todayIndex, entriesForDay } from './timetableLogic.js';
import './timetable.css';

export default function Timetable() {
  const { data, changeData, showToast } = useAppStore();
  const today = todayIndex(new Date());
  const [form, setForm] = useState({ day: today, start: '09:00', end: '10:00', name: '', room: '' });
  const set = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  function addEntry() {
    if (!form.name.trim()) { showToast('Add the class name'); return; }
    changeData(draft => {
      draft.timetable.push({
        id: makeId(), day: Number(form.day), start: form.start || '09:00',
        end: form.end || '10:00', name: form.name.trim(), room: form.room.trim()
      });
    });
    set('name', '');
    set('room', '');
  }
  function deleteEntry(entryId) {
    changeData(draft => {
      draft.timetable = draft.timetable.filter(e => e.id !== entryId);
    });
  }

  return (
    <div>
      <h1>🏫 Timetable</h1>
      <div className="toolbar">
        <select className="field tt-day" value={form.day} onChange={e => set('day', e.target.value)}>
          {DAY_NAMES.map((name, index) => <option key={name} value={index}>{name}</option>)}
        </select>
        <input className="field tt-time" type="time" value={form.start} onChange={e => set('start', e.target.value)} />
        <input className="field tt-time" type="time" value={form.end} onChange={e => set('end', e.target.value)} />
        <input className="field" placeholder="Class / subject" value={form.name}
          onChange={e => set('name', e.target.value)} />
        <input className="field tt-room" placeholder="Room" value={form.room}
          onChange={e => set('room', e.target.value)} />
        <button className="btn btn-primary" onClick={addEntry}>Add</button>
      </div>
      <div className="tt-grid">
        {DAY_NAMES.map((name, index) => {
          const entries = entriesForDay(data, index);
          return (
            <div key={name} className={'tt-col' + (index === today ? ' tt-today' : '')}>
              <h4>{name.slice(0, 3)}{index === today ? ' ·' : ''}</h4>
              {entries.length === 0 && <p className="board-empty">—</p>}
              {entries.map(entry => (
                <div key={entry.id} className="tt-block">
                  <b>{entry.start}–{entry.end}</b><br />
                  {entry.name}
                  {entry.room && <><br /><span>{entry.room}</span></>}
                  <button className="icon-btn" title="Delete" onClick={() => deleteEntry(entry.id)}>✕</button>
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
