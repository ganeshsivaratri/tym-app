// ==========================================
// FILE: src/screens/Study/studyLogic.js
// WHAT: Brain of the Study screen —
// progress % per subject and overall.
// ==========================================
export function subjectPercent(subject) {
  if (!subject.chapters.length) return 0;
  const done = subject.chapters.filter(c => c.done).length;
  return Math.round(done / subject.chapters.length * 100);
}

export function overallPercent(subjects) {
  if (!subjects.length) return 0;
  const sum = subjects.reduce((total, s) => total + subjectPercent(s), 0);
  return Math.round(sum / subjects.length);
}
