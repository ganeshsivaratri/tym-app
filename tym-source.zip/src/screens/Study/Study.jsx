// ==========================================
// FILE: src/screens/Study/Study.jsx
// WHAT: The Study screen — subjects with
// chapters and a progress bar each.
// Tick a chapter done and TYM creates a
// "Revise" task for 3 days later (spaced
// revision — one review beats forgetting).
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { makeId } from '../../utils/taskLogic.js';
import { todayStr, addDaysStr } from '../../utils/dates.js';
import { subjectPercent, overallPercent } from './studyLogic.js';
import './study.css';

export default function Study() {
  const { data, actions, changeData, showToast } = useAppStore();
  const [newSubjectName, setNewSubjectName] = useState('');
  const [chapterTexts, setChapterTexts] = useState({});

  function addSubject() {
    const name = newSubjectName.trim();
    if (!name) return;
    changeData(draft => {
      draft.subjects.push({ id: makeId(), name, chapters: [] });
    });
    setNewSubjectName('');
  }
  function deleteSubject(subjectId) {
    changeData(draft => {
      draft.subjects = draft.subjects.filter(s => s.id !== subjectId);
    });
  }
  function addChapter(subjectId) {
    const title = (chapterTexts[subjectId] || '').trim();
    if (!title) return;
    changeData(draft => {
      const subject = draft.subjects.find(s => s.id === subjectId);
      if (subject) subject.chapters.push({ id: makeId(), title, done: false });
    });
    setChapterTexts(prev => ({ ...prev, [subjectId]: '' }));
  }
  function toggleChapter(subject, chapter, checked) {
    changeData(draft => {
      const foundSubject = draft.subjects.find(s => s.id === subject.id);
      const foundChapter = foundSubject && foundSubject.chapters.find(c => c.id === chapter.id);
      if (foundChapter) foundChapter.done = checked;
    });
    if (checked) {
      actions.addTask({
        title: 'Revise: ' + chapter.title + ' (' + subject.name + ')',
        due: addDaysStr(todayStr(new Date()), 3),
        listId: data.lists.some(l => l.id === 'study') ? 'study' : data.lists[0]?.id,
        priority: 'med', tags: ['revision']
      });
      showToast('Chapter done 🎉 Revision task set for +3 days');
    }
  }

  return (
    <div>
      <h1>📚 Study</h1>
      <div className="toolbar">
        <input className="field" placeholder="New subject — e.g. Operating Systems" value={newSubjectName}
          onChange={e => setNewSubjectName(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') addSubject(); }} />
        <button className="btn btn-primary" onClick={addSubject}>Add subject</button>
        {data.subjects.length > 0 && (
          <span className="pill study-pill">Overall: {overallPercent(data.subjects)}%</span>
        )}
      </div>

      {data.subjects.length === 0 && (
        <div className="card empty"><div className="empty-art">📚</div>
          <p>No subjects yet. Add your first subject above, then its chapters.</p></div>
      )}
      {data.subjects.map(subject => (
        <div key={subject.id} className="card study-card">
          <div className="study-head">
            <h2>{subject.name}</h2>
            <span>
              <span className="badge">{subjectPercent(subject)}% · {subject.chapters.filter(c => c.done).length}/{subject.chapters.length} chapters</span>
              <button className="icon-btn" title="Delete subject" onClick={() => deleteSubject(subject.id)}>🗑</button>
            </span>
          </div>
          <div className="progress study-progress">
            <div style={{ width: subjectPercent(subject) + '%' }}></div>
          </div>
          {subject.chapters.map(chapter => (
            <label key={chapter.id} className="sub">
              <input type="checkbox" checked={chapter.done}
                onChange={e => toggleChapter(subject, chapter, e.target.checked)} />
              <span className={chapter.done ? 'sub-done' : ''}>{chapter.title}</span>
            </label>
          ))}
          <div className="toolbar study-toolbar">
            <input className="field" placeholder="Add a chapter…" value={chapterTexts[subject.id] || ''}
              onChange={e => setChapterTexts(prev => ({ ...prev, [subject.id]: e.target.value }))}
              onKeyDown={e => { if (e.key === 'Enter') addChapter(subject.id); }} />
            <button className="btn" onClick={() => addChapter(subject.id)}>Add chapter</button>
          </div>
        </div>
      ))}
    </div>
  );
}
