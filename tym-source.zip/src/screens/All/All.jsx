// ==========================================
// FILE: src/screens/All/All.jsx
// WHAT: The All Tasks screen — every open
// task, with search, a list filter and a
// sort picker. Default view groups tasks
// by when they are due.
// ==========================================
import React, { useMemo, useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import TaskCard from '../../components/TaskCard.jsx';
import { sortTasks, findTask } from '../../utils/taskLogic.js';
import { groupTasksByWhen, visibleTasks } from './allLogic.js';
import './all.css';

const SORT_OPTIONS = [
  { value: 'group', label: 'Grouped by when' },
  { value: 'due', label: 'By due date' },
  { value: 'priority', label: 'By priority' },
  { value: 'manual', label: 'My order (drag)' },
  { value: 'created', label: 'Recently added' },
  { value: 'title', label: 'By title' }
];

export default function All() {
  const { data, setEditingTask, changeData } = useAppStore();
  const [query, setQuery] = useState('');
  const [listFilter, setListFilter] = useState('all');
  const [sortMode, setSortMode] = useState(() => data.settings.sortDefault || 'group');
  const [draggedId, setDraggedId] = useState(null);

  const filtered = useMemo(
    () => visibleTasks(data, listFilter, query), [data, listFilter, query]);
  const grouped = sortMode === 'group' && !query.trim();
  const flatList = useMemo(
    () => grouped ? [] : sortTasks(filtered, sortMode), [filtered, sortMode, grouped]);
  const groups = useMemo(
    () => grouped ? groupTasksByWhen(filtered, new Date()) : [], [filtered, grouped]);

  /* Drag-to-reorder: rewrite the order numbers in the store. */
  function moveDraggedOver(targetTask, event) {
    if (!draggedId || draggedId === targetTask.id) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const after = (event.clientY - rect.top) > rect.height / 2;
    changeData(draft => {
      const ordered = sortTasks(draft.tasks.filter(t => t.status !== 'done'), 'manual');
      const dragged = findTask(draft, draggedId);
      const without = ordered.filter(t => t.id !== draggedId);
      let index = without.findIndex(t => t.id === targetTask.id) + (after ? 1 : 0);
      without.splice(index, 0, dragged);
      without.forEach((t, i) => { t.order = i + 1; });
    });
  }

  const card = task => {
    const theCard = <TaskCard task={task} />;
    if (sortMode !== 'manual' || query) return theCard;
    return (
      <div key={task.id} draggable
        onDragStart={() => setDraggedId(task.id)}
        onDragEnd={() => setDraggedId(null)}
        onDragOver={event => { event.preventDefault(); moveDraggedOver(task, event); }}>
        {theCard}
      </div>
    );
  };

  return (
    <div>
      <h1>🗂️ All Tasks</h1>
      <div className="toolbar">
        <input className="field" placeholder="Search tasks…" value={query}
          onChange={e => setQuery(e.target.value)} />
        <select className="field all-sort" value={sortMode} onChange={e => setSortMode(e.target.value)}>
          {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <button className="btn btn-primary" onClick={() => setEditingTask(null)}>＋ New Task</button>
      </div>
      <div className="toolbar">
        <button className={'btn' + (listFilter === 'all' ? ' btn-primary' : '')}
          onClick={() => setListFilter('all')}>All lists</button>
        {data.lists.map(list => (
          <button key={list.id} className={'btn' + (listFilter === list.id ? ' btn-primary' : '')}
            onClick={() => setListFilter(list.id)}>{list.name}</button>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="card empty"><div className="empty-art">🗂️</div>
          <p>{query ? 'No tasks match your search.' : 'No open tasks here.'}</p></div>
      )}
      {grouped && groups.map(group => (
        <section key={group.name}>
          <div className="section-title">{group.name} · {group.items.length}</div>
          {group.items.map(task => <TaskCard key={task.id} task={task} />)}
        </section>
      ))}
      {!grouped && flatList.map(card)}
    </div>
  );
}
