// ==========================================
// FILE: src/screens/All/allLogic.js
// WHAT: Brain of the All Tasks screen.
// Filters open tasks by list and search,
// then either sorts them or groups them
// by WHEN they are due.
// ==========================================
import { isOpenTask, isOverdueTask, sortTasks, searchTasks } from '../../utils/taskLogic.js';
import { todayStr, addDaysStr } from '../../utils/dates.js';

/* The "grouped by when" sections of the screen. */
export function groupTasksByWhen(tasks, now) {
  const today = todayStr(now);
  const buckets = [
    { name: '⚠️ Overdue', items: tasks.filter(t => isOverdueTask(t, now)) },
    { name: '📅 Today', items: tasks.filter(t => t.due === today && !isOverdueTask(t, now)) },
    { name: '🌅 Tomorrow', items: tasks.filter(t => t.due === addDaysStr(today, 1)) },
    { name: '🗓 This week', items: tasks.filter(t => t.due && t.due > addDaysStr(today, 1) && t.due <= addDaysStr(today, 7)) },
    { name: '🔭 Later', items: tasks.filter(t => t.due && t.due > addDaysStr(today, 7)) },
    { name: '📥 No date', items: tasks.filter(t => !t.due) }
  ];
  return buckets
    .filter(bucket => bucket.items.length)
    .map(bucket => ({ ...bucket, items: sortTasks(bucket.items, 'due') }));
}

/* The filtered list the screen shows. */
export function visibleTasks(data, listFilter, query) {
  let tasks = data.tasks.filter(isOpenTask);
  if (listFilter !== 'all') tasks = tasks.filter(t => t.listId === listFilter);
  return searchTasks(tasks, query);
}
