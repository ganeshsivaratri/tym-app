// ==========================================
// FILE: src/screens/Focus/Focus.jsx
// WHAT: The Focus screen — a Pomodoro
// timer tied to a task. Work, then break.
// Finished work rounds are written to the
// focus log (the Review screen reads it).
// Extras: rain ambience (made live with
// WebAudio, no file) and full screen.
// ==========================================
import React, { useEffect, useRef, useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { formatClock, breakMinutesFor, focusToday } from './focusLogic.js';
import './focus.css';

const WORK_PRESETS = [15, 25, 50];

export default function Focus() {
  const { data, actions, showToast } = useAppStore();
  const [mode, setMode] = useState('work');         // 'work' | 'break'
  const [workMinutes, setWorkMinutes] = useState(25);
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [taskId, setTaskId] = useState('');
  const [noiseOn, setNoiseOn] = useState(false);
  const timerRef = useRef(null);
  const noiseRef = useRef(null);
  const breakMinutes = breakMinutesFor(workMinutes);
  const today = focusToday(data, new Date());
  const openTasks = data.tasks.filter(t => t.status !== 'done');

  function stopTimer() {
    setRunning(false);
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    document.title = 'TYM — Track Your Mind';
  }
  function switchMode(nextMode) {
    stopTimer();
    setMode(nextMode);
    setSecondsLeft((nextMode === 'work' ? workMinutes : breakMinutes) * 60);
  }
  function roundDone() {
    stopTimer();
    try { if (navigator.vibrate) navigator.vibrate([200, 80, 200, 80, 400]); } catch (e) {}
    if (mode === 'work') {
      actions.logFocusSession(workMinutes, taskId || null);
      showToast('Session done 🎉 Logged ' + workMinutes + ' focus minutes');
      switchMode('break');
    } else {
      showToast('Break over — back to it 💪');
      switchMode('work');
    }
  }
  function toggleRun() {
    if (running) { stopTimer(); return; }
    setRunning(true);
    timerRef.current = setInterval(() => setSecondsLeft(s => s - 1), 1000);
  }
  useEffect(() => {
    if (running) document.title = formatClock(secondsLeft) + ' · TYM Focus';
    if (running && secondsLeft <= 0) roundDone();
  }, [secondsLeft, running]);
  useEffect(() => () => { // leaving the screen stops everything
    if (timerRef.current) clearInterval(timerRef.current);
    if (noiseRef.current) { noiseRef.current.source.stop(); noiseRef.current = null; }
    document.title = 'TYM — Track Your Mind';
  }, []);

  function pickPreset(minutes) {
    if (running) { showToast('Pause first to change length'); return; }
    setWorkMinutes(minutes);
    if (mode === 'work') setSecondsLeft(minutes * 60);
  }
  function toggleNoise() {
    if (noiseRef.current) {
      noiseRef.current.source.stop();
      noiseRef.current = null;
      setNoiseOn(false);
      return;
    }
    try {
      const context = new (window.AudioContext || window.webkitAudioContext)();
      const length = context.sampleRate * 2;
      const buffer = context.createBuffer(1, length, context.sampleRate);
      const channel = buffer.getChannelData(0);
      let last = 0;
      for (let i = 0; i < length; i++) { // brown-ish noise = soft rain
        const white = Math.random() * 2 - 1;
        last = (last + 0.02 * white) / 1.02;
        channel[i] = last * 3.2;
      }
      const source = context.createBufferSource();
      source.buffer = buffer;
      source.loop = true;
      const gain = context.createGain();
      gain.gain.value = 0.16;
      source.connect(gain);
      gain.connect(context.destination);
      source.start();
      noiseRef.current = { source, context };
      setNoiseOn(true);
    } catch (error) { showToast('Ambience is not available here'); }
  }

  return (
    <div>
      <h1>🍅 Focus</h1>
      <div className="focus-wrap card">
        <div className="focus-modes">
          <button className={'btn' + (mode === 'work' ? ' btn-primary' : '')}
            onClick={() => switchMode('work')}>🍅 Work {workMinutes}m</button>
          <button className={'btn' + (mode === 'break' ? ' btn-primary' : '')}
            onClick={() => switchMode('break')}>☕ Break {breakMinutes}m</button>
        </div>
        <div className="focus-modes focus-presets">
          {WORK_PRESETS.map(minutes => (
            <button key={minutes} className={'btn' + (workMinutes === minutes ? ' btn-primary' : '')}
              onClick={() => pickPreset(minutes)}>{minutes} min</button>
          ))}
        </div>
        <div className="focus-clock">{formatClock(secondsLeft)}</div>
        <label className="focus-label">Focusing on</label>
        <select className="field focus-task" value={taskId} onChange={e => setTaskId(e.target.value)}>
          <option value="">— no task, just focus —</option>
          {openTasks.map(task => <option key={task.id} value={task.id}>{task.title}</option>)}
        </select>
        <div className="focus-actions">
          <button className="btn btn-primary focus-toggle" onClick={toggleRun}>
            {running ? '⏸ Pause' : '▶ Start'}
          </button>
          <button className="btn" onClick={() => switchMode(mode)}>↺ Reset</button>
          <button className="btn" onClick={toggleNoise}>🌧 Ambience: {noiseOn ? 'on' : 'off'}</button>
          <button className="btn" onClick={() => {
            if (document.fullscreenElement) document.exitFullscreen();
            else document.documentElement.requestFullscreen();
          }}>⛶ Full screen</button>
        </div>
        <p className="focus-today">Today: {today.sessionCount} sessions · {today.minutes} focus minutes</p>
      </div>
    </div>
  );
}
