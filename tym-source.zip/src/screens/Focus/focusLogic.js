// ==========================================
// FILE: src/screens/Focus/focusLogic.js
// WHAT: Brain of the Focus screen — the
// clock text and today's focus totals.
// The timer itself lives in Focus.jsx.
// ==========================================
import { pad2, todayStr } from '../../utils/dates.js';

/* "25:00" from a number of seconds. */
export function formatClock(totalSeconds) {
  const seconds = Math.max(0, totalSeconds);
  return pad2(Math.floor(seconds / 60)) + ':' + pad2(seconds % 60);
}

/* Break length for a work length: a fifth, at least 3 min. */
export function breakMinutesFor(workMinutes) {
  return Math.max(3, Math.round(workMinutes / 5));
}

/* Sessions and minutes already focused today. */
export function focusToday(data, now) {
  const today = todayStr(now);
  const sessions = data.focusLog.filter(s => s.date === today);
  return {
    sessionCount: sessions.length,
    minutes: sessions.reduce((sum, s) => sum + s.minutes, 0)
  };
}
