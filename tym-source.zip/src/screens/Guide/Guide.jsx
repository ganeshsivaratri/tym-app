// ==========================================
// FILE: src/screens/Guide/Guide.jsx
// WHAT: The Guide screen — teaches the app
// in simple words, one card per feature,
// each with an example and an Open button.
// The card text lives in guideContent.js.
// ==========================================
import React from 'react';
import { GUIDE_CARDS } from './guideContent.js';
import './guide.css';

export default function Guide({ goToScreen }) {
  return (
    <div>
      <h1>❓ Guide</h1>
      <div>
        {GUIDE_CARDS.map(card => (
          <div key={card.name} className="card guide-card">
            <h2>{card.icon} {card.name}</h2>
            <p className="guide-what">{card.what}</p>
            <p className="guide-example">💡 {card.example}</p>
            {card.screen && (
              <button className="btn" onClick={() => goToScreen(card.screen)}>Open →</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
