// ==========================================
// FILE: src/screens/Settings/settingsLogic.js
// WHAT: Brain of the Settings screen —
// the sample day builder and the CSV rows
// → tasks converter. Drawing is in
// Settings.jsx; save/load in the store.
// ==========================================
import { parseCSV } from '../../utils/csvParse.js';
import { todayStr, addDaysStr } from '../../utils/dates.js';

/* The sample day: 4 tasks + 1 habit, all tagged
   'sample' so they can be removed in one tap. */
export function sampleDayFields(now) {
  const today = todayStr(now);
  return [
    { title: 'Pay the electricity bill', due: today, time: '18:00',
      priority: 'high', listId: 'personal', reminders: [0, 60], tags: ['sample'] },
    { title: 'Revise Unit 3 — Operating Systems', due: today,
      priority: 'med', listId: 'study', estMinutes: 50, tags: ['sample'],
      subtasks: [{ title: 'Read notes' }, { title: 'Solve 5 previous questions' }] },
    { title: 'Evening walk 20 minutes', due: today,
      priority: 'low', listId: 'personal', tags: ['sample'] },
    { title: 'Submit assignment', due: addDaysStr(today, 1),
      priority: 'high', listId: 'study', tags: ['sample'] }
  ];
}

export function isSampleTask(task) {
  return (task.tags || []).includes('sample');
}

/* Turn CSV text (Todoist / TickTick export) into task
   fields. Finds a title column and a date column. */
export function taskFieldsFromCSV(csvText) {
  const rows = parseCSV(csvText);
  if (!rows.length) return [];
  const header = rows[0].map(h => h.trim().toLowerCase());
  const titleIndex = header.findIndex(h => ['task', 'content', 'title', 'name'].includes(h));
  const dateIndex = header.findIndex(h => ['date', 'due', 'due date', 'scheduled'].includes(h));
  const fields = [];
  for (const row of rows.slice(1)) {
    const title = (titleIndex >= 0 ? row[titleIndex] : row[0] || '').trim();
    if (!title) continue;
    let due = null;
    if (dateIndex >= 0 && /^\d{4}-\d{2}-\d{2}/.test((row[dateIndex] || '').trim())) {
      due = row[dateIndex].trim().slice(0, 10);
    }
    fields.push({ title, due, listId: 'personal' });
  }
  return fields;
}
