// ==========================================
// FILE: src/screens/Settings/Settings.jsx
// WHAT: The Settings screen — theme, lists,
// notifications, backup + snapshots, sample
// day, CSV import, and the danger zone.
// The data work goes through the store;
// file downloads go through services.
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { readSnapshots, parseState, stateToBackupText } from '../../store/storage.js';
import { buildICS } from '../../utils/calendarFile.js';
import { makeId } from '../../utils/taskLogic.js';
import { saveFile } from '../../services/saveFile.js';
import { isNativeApp, requestNotificationPermission } from '../../services/notifications.js';
import { sampleDayFields, isSampleTask, taskFieldsFromCSV } from './settingsLogic.js';
import { logout } from '../../services/auth.js';
import './settings.css';

export default function Settings({ goToScreen }) {
  const { data, actions, changeData, showToast, user, setGuestMode, setLoginRequested } = useAppStore();
  const [newListName, setNewListName] = useState('');
  const [csvResult, setCsvResult] = useState('');
  const snapshots = readSnapshots().slice().reverse();

  const notificationState = isNativeApp()
    ? 'app mode — phone notifications'
    : (!('Notification' in window) ? 'not supported in this browser'
      : 'permission: ' + Notification.permission);

  async function enableNotifications() {
    if (isNativeApp()) await requestNotificationPermission();
    else if ('Notification' in window) await Notification.requestPermission();
    showToast('Notifications setting updated 🔔');
  }
  function addList() {
    const name = newListName.trim();
    if (!name) return;
    changeData(draft => {
      draft.lists.push({ id: makeId(), name, color: '#6d5cff' });
    });
    setNewListName('');
  }
  function renameList(list) {
    const name = window.prompt('Rename list', list.name);
    if (name && name.trim()) {
      changeData(draft => {
        const found = draft.lists.find(l => l.id === list.id);
        if (found) found.name = name.trim();
      });
    }
  }
  function recolorList(listId, color) {
    changeData(draft => {
      const found = draft.lists.find(l => l.id === listId);
      if (found) found.color = color;
    });
  }
  function deleteList(listId) {
    if (data.lists.length <= 1) { showToast('Keep at least one list'); return; }
    const fallback = data.lists.find(l => l.id !== listId);
    changeData(draft => {
      draft.tasks.forEach(t => { if (t.listId === listId) t.listId = fallback.id; });
      draft.lists = draft.lists.filter(l => l.id !== listId);
    });
    showToast('List deleted — its tasks moved to ' + fallback.name);
  }
  async function exportBackup() {
    const shared = await saveFile('tym-backup.json', stateToBackupText(data), 'application/json');
    if (shared) showToast('Backup ready — save it somewhere safe 💾');
  }
  function importBackup(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      actions.replaceData(parseState(String(reader.result)));
      showToast('Backup imported 💾');
    };
    reader.readAsText(file);
  }
  function restoreSnapshot(snapshot) {
    if (!window.confirm('Restore the snapshot from ' + snapshot.day + '? Current data will be replaced.')) return;
    actions.replaceData(parseState(snapshot.data));
    showToast('Snapshot restored 📸');
  }
  async function exportCalendar() {
    const shared = await saveFile('tym-tasks.ics', buildICS(data.tasks), 'text/calendar');
    if (shared) showToast('Calendar file ready 📆');
  }
  function loadSampleDay() {
    sampleDayFields(new Date()).forEach(fields => actions.addTask(fields));
    changeData(draft => {
      draft.habits.push({ id: makeId(), name: '🌱 Read 10 pages', createdAt: Date.now() });
    });
    showToast('Sample day loaded 🌱 — see the Today screen');
  }
  function removeSampleDay() {
    changeData(draft => {
      draft.tasks = draft.tasks.filter(t => !isSampleTask(t));
      draft.habits = draft.habits.filter(h => !h.name.startsWith('🌱'));
    });
    showToast('Sample data removed');
  }
  function importCSV(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const fieldsList = taskFieldsFromCSV(String(reader.result));
      fieldsList.forEach(fields => actions.addTask(fields));
      setCsvResult(fieldsList.length + ' tasks imported');
      showToast('Imported ' + fieldsList.length + ' tasks 📥');
    };
    reader.readAsText(file);
  }
  function eraseEverything() {
    if (!window.confirm('Erase EVERYTHING in TYM on this device? This cannot be undone.')) return;
    actions.eraseAll();
    showToast('Fresh start — everything erased');
  }

  return (
    <div>
      <h1>⚙️ Settings</h1>

      <div className="card settings-card">
        <h2>👤 Account</h2>
        {user
          ? <>
              <p className="settings-muted">Signed in as <b>{user.email}</b>. Your data backs up to the cloud.</p>
              <button className="btn" onClick={async () => {
                await logout();
                try { localStorage.removeItem('tym-guest'); } catch (e) {}
                setGuestMode(false);
                showToast('Signed out');
              }}>Sign out</button>
            </>
          : <>
              <p className="settings-muted">You are using TYM as a guest — data lives only on this device.</p>
              <button className="btn btn-primary" onClick={() => setLoginRequested(true)}>Sign in / Create account</button>
            </>}
      </div>

      <div className="card settings-card">
        <h2>❓ New here?</h2>
        <p className="settings-muted">Every feature in simple words, with examples.</p>
        <button className="btn btn-primary" onClick={() => goToScreen('guide')}>Open the Guide →</button>
      </div>

      <div className="card settings-card">
        <h2>🎨 Appearance</h2>
        <p className="settings-muted">Auto = dark from 7 PM to 7 AM, light the rest of the day.</p>
        <div className="toolbar settings-toolbar">
          <select className="field settings-theme" value={data.settings.theme || 'light'}
            onChange={e => {
              const theme = e.target.value;
              changeData(draft => { draft.settings.theme = theme; });
              showToast('Theme: ' + theme);
            }}>
            <option value="light">☀️ Light</option>
            <option value="dark">🌙 Dark</option>
            <option value="auto">🌓 Auto (by time)</option>
          </select>
        </div>
      </div>

      <div className="card settings-card">
        <h2>🔔 Notifications</h2>
        <p className="settings-muted">Browser reminders need permission. In the Android app, alarms ring even when TYM is closed.</p>
        <button className="btn" onClick={enableNotifications}>Enable notifications</button>
        <span className="pill settings-pill">{notificationState}</span>
      </div>

      <div className="card settings-card">
        <h2>🗂 My lists</h2>
        {data.lists.map(list => (
          <div key={list.id} className="task">
            <span className="dot settings-dot" style={{ background: list.color }}></span>
            <div className="task-main">
              <div className="task-title">{list.name}</div>
              <div className="settings-count">{data.tasks.filter(t => t.listId === list.id).length} tasks</div>
            </div>
            <input type="color" value={list.color} title="Colour"
              onChange={e => recolorList(list.id, e.target.value)} />
            <button className="icon-btn" onClick={() => renameList(list)}>✏️</button>
            <button className="icon-btn" onClick={() => deleteList(list.id)}>🗑</button>
          </div>
        ))}
        <div className="toolbar settings-toolbar">
          <input className="field" placeholder="New list name" value={newListName}
            onChange={e => setNewListName(e.target.value)} />
          <button className="btn btn-primary" onClick={addList}>Add list</button>
        </div>
      </div>

      <div className="card settings-card">
        <h2>💾 Backup</h2>
        <p className="settings-muted">Your data lives only on this device. Export a backup file regularly.</p>
        <button className="btn" onClick={exportBackup}>⬇ Export backup (JSON)</button>
        <label className="btn settings-label-btn">⬆ Import backup
          <input type="file" accept=".json" hidden onChange={importBackup} /></label>
      </div>

      <div className="card settings-card">
        <h2>🛡 Automatic snapshots</h2>
        <p className="settings-muted">TYM quietly saves one snapshot per day (last 3 kept). Restore one if something ever goes wrong.</p>
        {snapshots.length === 0
          ? <p className="settings-muted">No snapshots yet — the first one is taken today.</p>
          : snapshots.map(snapshot => (
            <div key={snapshot.day} className="task">
              <div className="task-main"><div className="task-title">📸 {snapshot.day}</div></div>
              <button className="btn" onClick={() => restoreSnapshot(snapshot)}>Restore</button>
            </div>
          ))}
      </div>

      <div className="card settings-card">
        <h2>📆 Calendar export</h2>
        <p className="settings-muted">Download your dated tasks as an .ics file and import it into Google Calendar.</p>
        <button className="btn" onClick={exportCalendar}>⬇ Export tasks (.ics)</button>
      </div>

      <div className="card settings-card">
        <h2>🌱 Sample day</h2>
        <p className="settings-muted">New here? Load a small sample day to see TYM alive — remove it any time with one tap.</p>
        <button className="btn" onClick={loadSampleDay}>Load sample day</button>
        <button className="btn" onClick={removeSampleDay}>Remove sample data</button>
      </div>

      <div className="card settings-card">
        <h2>📥 Import tasks from CSV</h2>
        <p className="settings-muted">Works with Todoist and TickTick exports — title and due-date columns are picked up.</p>
        <label className="btn settings-label-btn">Choose CSV file
          <input type="file" accept=".csv" hidden onChange={importCSV} /></label>
        {csvResult && <span className="pill settings-pill">{csvResult}</span>}
      </div>

      <div className="card settings-card">
        <h2>⌨️ Shortcuts</h2>
        <p className="settings-muted settings-shortcuts">
          Ctrl+K — command palette<br />n — new task · Esc — close popups</p>
      </div>

      <div className="card">
        <h2>⚠️ Danger zone</h2>
        <p className="settings-muted">Erase every task, habit and setting on this device. Export a backup first if unsure.</p>
        <button className="btn danger" onClick={eraseEverything}>Erase everything</button>
      </div>

      <p className="settings-version">TYM — Track Your Mind · App version <b>v3.1</b> (React rebuild)</p>
    </div>
  );
}
