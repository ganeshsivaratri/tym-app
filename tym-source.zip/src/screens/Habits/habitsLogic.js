// ==========================================
// FILE: src/screens/Habits/habitsLogic.js
// WHAT: Brain of the Habits screen —
// streaks and the last-7-days dots for
// each habit, routine progress for today.
// The streak maths lives in
// utils/progressLogic.js.
// ==========================================
import { lastNDays, habitStreak } from '../../utils/progressLogic.js';
import { todayStr } from '../../utils/dates.js';

export function habitView(data, habit, now) {
  const log = data.habitLog[habit.id] || {};
  return {
    streak: habitStreak(log, now),
    last7: lastNDays(7, now).map(date => ({ date, done: !!log[date] })),
    doneToday: !!log[todayStr(now)]
  };
}

export function routineProgress(data, routine, now) {
  const today = todayStr(now);
  const doneIndexes = (data.routineLog[today] || {})[routine.id] || [];
  const percent = routine.items.length
    ? Math.round(doneIndexes.length / routine.items.length * 100)
    : 0;
  return { doneIndexes, percent };
}
