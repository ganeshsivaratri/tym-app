// ==========================================
// FILE: src/screens/Habits/Habits.jsx
// WHAT: The Habits screen — daily habits
// with streaks, plus morning/night
// routines that reset fresh every day.
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { ROUTINE_TEMPLATES, HABIT_IDEAS } from '../../store/defaultData.js';
import { makeId } from '../../utils/taskLogic.js';
import { todayStr } from '../../utils/dates.js';
import { habitView, routineProgress } from './habitsLogic.js';
import './habits.css';

export default function Habits() {
  const { data, changeData } = useAppStore();
  const [newHabitName, setNewHabitName] = useState('');
  const now = new Date();
  const today = todayStr(now);

  function addHabit(name) {
    const clean = (name || '').trim();
    if (!clean) return;
    changeData(draft => {
      draft.habits.push({ id: makeId(), name: clean, createdAt: Date.now() });
    });
    setNewHabitName('');
  }
  function toggleHabitToday(habitId) {
    changeData(draft => {
      draft.habitLog[habitId] = draft.habitLog[habitId] || {};
      if (draft.habitLog[habitId][today]) delete draft.habitLog[habitId][today];
      else draft.habitLog[habitId][today] = true;
    });
  }
  function deleteHabit(habitId) {
    changeData(draft => {
      draft.habits = draft.habits.filter(h => h.id !== habitId);
      delete draft.habitLog[habitId];
    });
  }
  function startRoutine(template) {
    changeData(draft => {
      draft.routines.push({ id: template.id, name: template.name, items: template.items.slice() });
    });
  }
  function deleteRoutine(routineId) {
    changeData(draft => {
      draft.routines = draft.routines.filter(r => r.id !== routineId);
    });
  }
  function toggleRoutineItem(routineId, itemIndex, checked) {
    changeData(draft => {
      draft.routineLog[today] = draft.routineLog[today] || {};
      const current = draft.routineLog[today][routineId] || [];
      draft.routineLog[today][routineId] = checked
        ? [...new Set([...current, itemIndex])]
        : current.filter(i => i !== itemIndex);
    });
  }

  const availableTemplates = ROUTINE_TEMPLATES.filter(
    template => !data.routines.some(r => r.id === template.id));

  return (
    <div>
      <h1>🔥 Habits</h1>
      <div className="toolbar">
        <input className="field" placeholder="New habit — e.g. Read 10 pages" value={newHabitName}
          onChange={e => setNewHabitName(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') addHabit(newHabitName); }} />
        <button className="btn btn-primary" onClick={() => addHabit(newHabitName)}>Add habit</button>
      </div>
      <div className="toolbar">
        {HABIT_IDEAS.map(idea => (
          <button key={idea} className="btn" onClick={() => addHabit(idea)}>{idea}</button>
        ))}
      </div>

      {data.habits.length === 0 && (
        <div className="card empty"><div className="empty-art">🔥</div>
          <p>No habits yet. Add one above — small and daily wins.</p></div>
      )}
      {data.habits.map(habit => {
        const view = habitView(data, habit, now);
        return (
          <div key={habit.id} className="task">
            <div className="task-main">
              <div className="task-title">{habit.name}
                <span className="pill">🔥 {view.streak} day streak</span></div>
              <div className="habit-dots">
                {view.last7.map(day => (
                  <span key={day.date} className={'habit-dot' + (day.done ? ' on' : '')} title={day.date}></span>
                ))}
                <span className="habit-week">last 7 days</span>
              </div>
            </div>
            <button className={'btn' + (view.doneToday ? ' btn-primary' : '')}
              onClick={() => toggleHabitToday(habit.id)}>
              {view.doneToday ? '✓ Done today' : 'Mark today'}
            </button>
            <button className="icon-btn" title="Delete habit" onClick={() => deleteHabit(habit.id)}>🗑</button>
          </div>
        );
      })}

      <div className="section-title">Daily routines</div>
      {data.routines.map(routine => {
        const progress = routineProgress(data, routine, now);
        return (
          <div key={routine.id} className="card routine-card">
            <h2>{routine.name} <span className="badge">{progress.percent}%</span></h2>
            <div className="progress routine-progress">
              <div style={{ width: progress.percent + '%' }}></div>
            </div>
            {routine.items.map((item, index) => (
              <label key={index} className="sub">
                <input type="checkbox" checked={progress.doneIndexes.includes(index)}
                  onChange={e => toggleRoutineItem(routine.id, index, e.target.checked)} />
                <span className={progress.doneIndexes.includes(index) ? 'sub-done' : ''}>{item}</span>
              </label>
            ))}
            <div style={{ marginTop: 8 }}>
              <button className="icon-btn" onClick={() => deleteRoutine(routine.id)}>🗑 Remove routine</button>
            </div>
          </div>
        );
      })}
      {availableTemplates.length > 0
        ? <div className="toolbar">
            {availableTemplates.map(template => (
              <button key={template.id} className="btn" onClick={() => startRoutine(template)}>
                ＋ {template.name}</button>
            ))}
          </div>
        : <p className="habits-muted">Routines reset fresh every morning, automatically.</p>}
    </div>
  );
}
