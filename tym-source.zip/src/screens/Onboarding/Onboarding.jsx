// ==========================================
// FILE: src/screens/Onboarding/Onboarding.jsx
// WHAT: The first-run welcome — 3 slides
// that say what TYM does, in simple words.
// Shown once, on the very first launch.
// After it: the login screen.
// ==========================================
import React, { useState } from 'react';
import './onboarding.css';

const SLIDES = [
  { emoji: '🧠', title: 'Your mind, tracked',
    text: 'Write a task in simple words — "Pay fees tomorrow 5pm" — TYM sets the date and time itself.' },
  { emoji: '⏰', title: 'Alarms that ring',
    text: 'Set a reminder and TYM rings like an alarm at the time. In the app, it rings even when TYM is closed.' },
  { emoji: '🔥', title: 'Habits, focus, proof',
    text: 'Daily habits with streaks, a focus timer for study, and a Review screen that shows your progress and XP.' }
];

export default function Onboarding({ finishOnboarding }) {
  const [slideIndex, setSlideIndex] = useState(0);
  const slide = SLIDES[slideIndex];
  const isLast = slideIndex === SLIDES.length - 1;

  return (
    <div className="onboarding-wrap">
      <div className="card onboarding-card">
        <div className="onboarding-emoji">{slide.emoji}</div>
        <h1 className="onboarding-title">{slide.title}</h1>
        <p className="onboarding-text">{slide.text}</p>
        <div className="onboarding-dots">
          {SLIDES.map((_, i) => (
            <span key={i} className={'onboarding-dot' + (i === slideIndex ? ' on' : '')}></span>
          ))}
        </div>
        {isLast
          ? <button className="btn btn-primary onboarding-btn" onClick={finishOnboarding}>Start using TYM →</button>
          : <>
              <button className="btn btn-primary onboarding-btn"
                onClick={() => setSlideIndex(slideIndex + 1)}>Next →</button>
              <button className="onboarding-skip" onClick={finishOnboarding}>Skip</button>
            </>}
      </div>
    </div>
  );
}
