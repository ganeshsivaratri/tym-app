// ==========================================
// FILE: src/screens/Completed/Completed.jsx
// WHAT: The Completed screen — every task
// marked done, newest first. Untick to
// reopen, or clear them all (with Undo).
// ==========================================
import React from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import TaskCard from '../../components/TaskCard.jsx';
import { restoreTask } from '../../utils/taskLogic.js';
import { completedTasks } from './completedLogic.js';
import './completed.css';

export default function Completed() {
  const { data, changeData, showToast } = useAppStore();
  const done = completedTasks(data);

  function clearAll() {
    const removed = data.tasks.filter(t => t.status === 'done');
    changeData(draft => {
      draft.tasks = draft.tasks.filter(t => t.status !== 'done');
    });
    showToast('Cleared ' + removed.length + ' completed tasks', 'Undo', () => {
      changeData(draft => removed.forEach(t => restoreTask(draft, t)));
    });
  }

  return (
    <div>
      <h1>✅ Completed</h1>
      {done.length === 0
        ? <div className="card empty"><div className="empty-art">✅</div>
            <p>Nothing completed yet. Your finished tasks will collect here.</p></div>
        : (
          <div>
            <div className="completed-bar">
              <button className="btn" onClick={clearAll}>🧹 Clear all completed ({done.length})</button>
            </div>
            {done.map(task => <TaskCard key={task.id} task={task} />)}
          </div>
        )}
    </div>
  );
}
