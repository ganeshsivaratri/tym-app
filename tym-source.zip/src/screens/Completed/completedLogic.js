// ==========================================
// FILE: src/screens/Completed/completedLogic.js
// WHAT: Brain of the Completed screen —
// finished tasks, newest first.
// ==========================================
export function completedTasks(data) {
  return data.tasks
    .filter(t => t.status === 'done')
    .sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0));
}
