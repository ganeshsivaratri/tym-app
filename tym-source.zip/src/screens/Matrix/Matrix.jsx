// ==========================================
// FILE: src/screens/Matrix/Matrix.jsx
// WHAT: The Matrix screen — urgent ×
// important grid. Drag a card to another
// box and the task's priority and due
// date change to match the box.
// ==========================================
import React from 'react';
import { useAppStore } from '../../store/AppStore.jsx';
import { QUADRANTS, quadrantOf, applyQuadrant } from './matrixLogic.js';
import { dueLabel } from '../../utils/dates.js';
import './matrix.css';

export default function Matrix() {
  const { data, setEditingTask, changeData } = useAppStore();
  const now = new Date();
  const openTasks = data.tasks.filter(t => t.status !== 'done');

  function dropTask(taskId, quadrantId) {
    const quadrant = QUADRANTS.find(q => q.id === quadrantId);
    changeData(draft => {
      const task = draft.tasks.find(t => t.id === taskId);
      if (task) applyQuadrant(task, quadrant, new Date());
    });
  }

  return (
    <div>
      <h1>🎯 Matrix</h1>
      <p className="matrix-hint">Drag a card to another box — its priority and due date change to match.</p>
      <div className="matrix">
        {QUADRANTS.map(quadrant => {
          const tasks = openTasks.filter(t => quadrantOf(t, now) === quadrant.id);
          return (
            <div key={quadrant.id} className="matrix-cell"
              onDragOver={e => e.preventDefault()}
              onDrop={e => { e.preventDefault(); dropTask(e.dataTransfer.getData('text/tym-task'), quadrant.id); }}>
              <h3>{quadrant.icon} {quadrant.name} <span className="badge">{tasks.length}</span></h3>
              {tasks.length === 0 && <p className="board-empty">—</p>}
              {tasks.map(task => (
                <div key={task.id} className="board-card" draggable
                  onDragStart={e => e.dataTransfer.setData('text/tym-task', task.id)}>
                  <div className="board-card-title">{task.title}</div>
                  <div className="task-meta">
                    <span className="pill">{task.due ? dueLabel(task.due, new Date()) : 'no date'}</span>
                    <button className="icon-btn" onClick={() => setEditingTask(task)}>✏️</button>
                  </div>
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
