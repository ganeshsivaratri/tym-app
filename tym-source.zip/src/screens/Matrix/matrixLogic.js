// ==========================================
// FILE: src/screens/Matrix/matrixLogic.js
// WHAT: Brain of the Matrix screen —
// Eisenhower's urgent × important grid.
// Urgent = overdue, or due within 2 days.
// Important = high priority.
// ==========================================
import { todayStr, addDaysStr, daysBetween } from '../../utils/dates.js';

export const QUADRANTS = [
  { id: 'do', name: 'Do first', icon: '🔥', urgent: true, important: true },
  { id: 'plan', name: 'Plan', icon: '🗓️', urgent: false, important: true },
  { id: 'quick', name: 'Quick / delegate', icon: '⚡', urgent: true, important: false },
  { id: 'later', name: 'Later', icon: '🧊', urgent: false, important: false }
];

export function isUrgent(task, now) {
  if (!task.due) return false;
  return daysBetween(todayStr(now), task.due) <= 2;
}

export function quadrantOf(task, now) {
  const urgent = isUrgent(task, now);
  const important = task.priority === 'high';
  return QUADRANTS.find(q => q.urgent === urgent && q.important === important).id;
}

/* When a card is dropped into a quadrant, the task
   changes to match: important → high priority,
   urgent → due today, not urgent → due in a week. */
export function applyQuadrant(task, quadrant, now) {
  const today = todayStr(now);
  task.priority = quadrant.important
    ? 'high'
    : (task.priority === 'high' ? 'med' : task.priority);
  if (quadrant.urgent && (!task.due || task.due > addDaysStr(today, 2))) task.due = today;
  if (!quadrant.urgent && task.due && task.due <= addDaysStr(today, 2)) {
    task.due = addDaysStr(today, 7);
  }
}
