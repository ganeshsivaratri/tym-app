// ==========================================
// FILE: src/components/AlarmOverlay.jsx
// WHAT: The full-screen alarm that shows
// when a reminder rings. Two choices:
// Done (finish the task) or Snooze 10 min.
// The sound is started/stopped by App.
// ==========================================
import React from 'react';
import { useAppStore } from '../store/AppStore.jsx';

export default function AlarmOverlay() {
  const { data, actions, ringingTask, setRingingTask, changeData } = useAppStore();
  if (!ringingTask) return null;
  const task = data.tasks.find(t => t.id === ringingTask.id) || ringingTask;

  function done() {
    actions.toggleTaskDone({ ...task, status: 'todo' });
    setRingingTask(null);
  }
  function snooze() {
    changeData(draft => {
      draft.snoozed[task.id] = Date.now() + 10 * 60000;
      Object.keys(draft.fired).forEach(key => {
        if (key.startsWith(task.id + '@')) delete draft.fired[key];
      });
    });
    setRingingTask(null);
  }

  return (
    <div className="alarm-view show">
      <div className="alarm-emoji">⏰</div>
      <div className="alarm-title">{task.title}</div>
      <div className="alarm-sub">{task.due || ''} {task.time || ''}</div>
      <div className="alarm-actions">
        <button className="btn btn-primary" onClick={done}>✓ Done</button>
        <button className="btn" onClick={snooze}>😴 Snooze 10 min</button>
      </div>
    </div>
  );
}
