// ==========================================
// FILE: src/components/CommandPalette.jsx
// WHAT: The Ctrl+K quick jumper. Type to
// find a screen or a task. Pick a screen to
// go there; pick a task to open its editor.
// ==========================================
import React, { useMemo, useState } from 'react';
import { useAppStore } from '../store/AppStore.jsx';
import { searchTasks } from '../utils/taskLogic.js';

export default function CommandPalette({ screens, goToScreen, closePalette }) {
  const { data, setEditingTask } = useAppStore();
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const screenHits = screens
      .filter(s => !q || s.name.toLowerCase().includes(q))
      .map(s => ({ kind: 'screen', label: s.icon + '  Go to ' + s.name, screen: s }));
    if (!q) return screenHits;
    const taskHits = searchTasks(data.tasks.filter(t => t.status !== 'done'), q)
      .slice(0, 5)
      .map(t => ({ kind: 'task', label: '✏️  Task: ' + t.title, task: t }));
    return [...screenHits, ...taskHits];
  }, [query, screens, data.tasks]);

  function pick(result) {
    closePalette();
    if (result.kind === 'screen') goToScreen(result.screen.id);
    else setEditingTask(result.task);
  }

  return (
    <div className="modal-backdrop" onClick={closePalette}>
      <div className="modal palette-card" onClick={e => e.stopPropagation()}>
        <input className="field" autoFocus placeholder="Type a screen or task…"
          value={query} onChange={e => setQuery(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && results[0]) pick(results[0]); }} />
        <div style={{ marginTop: 8 }}>
          {results.map((result, i) => (
            <button key={i} className="pal-item" onClick={() => pick(result)}>{result.label}</button>
          ))}
          {results.length === 0 && <p className="pal-hint">No matches.</p>}
        </div>
        <p className="pal-hint">Ctrl+K opens this · Esc closes · Enter picks the first</p>
      </div>
    </div>
  );
}
