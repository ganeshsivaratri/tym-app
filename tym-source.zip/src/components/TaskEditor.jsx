// ==========================================
// FILE: src/components/TaskEditor.jsx
// WHAT: The pop-up form for adding or
// editing one task — every field of a task
// lives here. Save goes to the store;
// this file only collects the fields.
// ==========================================
import React, { useState } from 'react';
import { useAppStore } from '../store/AppStore.jsx';
import { findTask } from '../utils/taskLogic.js';

const REMINDER_CHOICES = [
  { minutes: 0, label: 'At time' }, { minutes: 10, label: '10 min before' },
  { minutes: 30, label: '30 min before' }, { minutes: 60, label: '1 hour before' },
  { minutes: 1440, label: '1 day before' }
];
const REPEAT_CHOICES = ['none', 'daily', 'weekdays', 'weekly', 'fortnightly', 'monthly'];

export default function TaskEditor() {
  const { data, actions, setEditingTask, showToast } = useAppStore();
  const task = useAppStore().editingTask; // null = new task, object = edit
  const isNew = task === null;

  const [form, setForm] = useState(() => ({
    title: task?.title || '',
    notes: task?.notes || '',
    listId: task?.listId || data.lists[0]?.id || 'personal',
    priority: task?.priority || 'med',
    due: task?.due || '',
    time: task?.time || '',
    estMinutes: task?.estMinutes || '',
    repeat: task?.repeat || 'none',
    repeatBase: task?.repeatBase || 'due',
    reminders: task?.reminders || [],
    tags: (task?.tags || []).join(', '),
    focus: !!task?.focus,
    attachments: task?.attachments || [],
    subtasks: (task?.subtasks || []).map(s => '  '.repeat(s.depth || 0) + s.title).join('\n')
  }));

  const set = (field, value) => setForm(prev => ({ ...prev, [field]: value }));
  const close = () => setEditingTask(undefined);

  function toggleReminder(minutes) {
    setForm(prev => ({
      ...prev,
      reminders: prev.reminders.includes(minutes)
        ? prev.reminders.filter(m => m !== minutes)
        : [...prev.reminders, minutes].sort((a, b) => a - b)
    }));
  }

  function addAttachment(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (String(reader.result).length > 300000) {
        showToast('Image too big — pick a smaller one (under ~300 KB)');
        return;
      }
      set('attachments', [...form.attachments, reader.result]);
    };
    reader.readAsDataURL(file);
  }

  function collectFields() {
    return {
      title: form.title.trim(),
      notes: form.notes.trim(),
      listId: form.listId,
      priority: form.priority,
      due: form.due || null,
      time: form.time || null,
      estMinutes: parseInt(form.estMinutes, 10) || 0,
      repeat: form.repeat,
      repeatBase: form.repeatBase,
      reminders: form.reminders,
      tags: form.tags.split(',').map(s => s.trim().toLowerCase()).filter(Boolean),
      focus: form.focus,
      attachments: form.attachments,
      subtasks: form.subtasks.split('\n')
        .filter(line => line.trim())
        .map(line => ({ title: line.trim(), depth: /^(\s{2,}|\t)/.test(line) ? 1 : 0, done: false }))
        // keep the done state of subtasks that did not change
        .map((sub, i) => ({ ...sub, done: !!(task && task.subtasks && task.subtasks[i] && task.subtasks[i].done && task.subtasks[i].title === sub.title) }))
    };
  }

  function save() {
    const fields = collectFields();
    if (!fields.title) { showToast('Give the task a title first'); return; }
    if (isNew) actions.addTask(fields);
    else actions.updateTask(task.id, fields);
    close();
  }

  function saveAsTemplate() {
    const fields = collectFields();
    if (!fields.title) { showToast('Give the task a title first'); return; }
    actions.addTemplate(fields);
    showToast('Template saved 📋');
  }

  function applyTemplate(templateId) {
    const template = data.templates.find(t => t.id === templateId);
    if (!template) return;
    setForm(prev => ({
      ...prev,
      title: template.title || '', notes: template.notes || '',
      listId: template.listId || prev.listId, priority: template.priority || 'med',
      estMinutes: template.estMinutes || '', repeat: template.repeat || 'none',
      tags: (template.tags || []).join(', '),
      subtasks: (template.subtasks || []).map(s => '  '.repeat(s.depth || 0) + s.title).join('\n')
    }));
  }

  return (
    <div className="modal-backdrop" onClick={close}>
      <div className="modal" onClick={event => event.stopPropagation()}>
        <h2>{isNew ? '＋ New Task' : '✏️ Edit Task'}</h2>
        <label className="f-label">Title</label>
        <input className="field" value={form.title} autoFocus
          onChange={e => set('title', e.target.value)} placeholder="What needs doing?" />
        <div className="f-grid">
          <div><label className="f-label">Date</label>
            <input className="field" type="date" value={form.due} onChange={e => set('due', e.target.value)} /></div>
          <div><label className="f-label">Time</label>
            <input className="field" type="time" value={form.time} onChange={e => set('time', e.target.value)} /></div>
          <div><label className="f-label">Priority</label>
            <select className="field" value={form.priority} onChange={e => set('priority', e.target.value)}>
              <option value="high">High</option><option value="med">Med</option><option value="low">Low</option>
            </select></div>
          <div><label className="f-label">List</label>
            <select className="field" value={form.listId} onChange={e => set('listId', e.target.value)}>
              {data.lists.map(list => <option key={list.id} value={list.id}>{list.name}</option>)}
            </select></div>
          <div><label className="f-label">Repeat</label>
            <select className="field" value={form.repeat} onChange={e => set('repeat', e.target.value)}>
              {REPEAT_CHOICES.map(r => <option key={r} value={r}>{r}</option>)}
            </select></div>
          <div><label className="f-label">Estimate (minutes)</label>
            <input className="field" type="number" min="0" value={form.estMinutes}
              onChange={e => set('estMinutes', e.target.value)} /></div>
        </div>
        {form.repeat !== 'none' && (
          <label className="sub" style={{ marginTop: 8 }}>
            <input type="checkbox" checked={form.repeatBase === 'completion'}
              onChange={e => set('repeatBase', e.target.checked ? 'completion' : 'due')} />
            {' '}Next time counts from when I finish (not the due date)
          </label>
        )}
        <label className="f-label">Reminders</label>
        <div className="f-row">
          {REMINDER_CHOICES.map(choice => (
            <label key={choice.minutes} className="sub" style={{ marginRight: 10 }}>
              <input type="checkbox" checked={form.reminders.includes(choice.minutes)}
                onChange={() => toggleReminder(choice.minutes)} /> {choice.label}
            </label>
          ))}
        </div>
        <label className="f-label">Tags (comma separated)</label>
        <input className="field" value={form.tags} onChange={e => set('tags', e.target.value)} placeholder="college, fees" />
        <label className="f-label">Subtasks (one per line — start a line with 2 spaces to nest it)</label>
        <textarea className="field" rows="3" value={form.subtasks}
          onChange={e => set('subtasks', e.target.value)} placeholder={'Read notes\n  Solve 5 old questions'} />
        <label className="f-label">Notes (Markdown works)</label>
        <textarea className="field" rows="3" value={form.notes}
          onChange={e => set('notes', e.target.value)} />
        <label className="sub" style={{ marginTop: 8 }}>
          <input type="checkbox" checked={form.focus} onChange={e => set('focus', e.target.checked)} />
          {' '}📌 Pin to My Day (Top 3)
        </label>
        <label className="f-label">Photo (small)</label>
        <div className="att-row">
          {form.attachments.map((src, i) => (
            <span key={i} className="att-wrap">
              <img className="att-img" src={src} alt="attachment" />
              <button className="att-x" onClick={() => set('attachments', form.attachments.filter((_, j) => j !== i))}>×</button>
            </span>
          ))}
          <label className="btn" style={{ display: 'inline-block' }}>＋ Add photo
            <input type="file" accept="image/*" hidden onChange={addAttachment} /></label>
        </div>
        {data.templates.length > 0 && (
          <div className="f-row" style={{ marginTop: 10 }}>
            <select className="field" defaultValue="" onChange={e => applyTemplate(e.target.value)}>
              <option value="">📋 Use a template…</option>
              {data.templates.map(t => <option key={t.id} value={t.id}>{t.title}</option>)}
            </select>
          </div>
        )}
        <div className="modal-actions">
          {!isNew && <button className="btn danger" onClick={() => { actions.deleteTask(findTask(data, task.id) || task); close(); }}>🗑 Delete</button>}
          <span style={{ flex: 1 }}></span>
          <button className="btn" onClick={saveAsTemplate}>Save as template</button>
          <button className="btn" onClick={close}>Cancel</button>
          <button className="btn btn-primary" onClick={save}>Save</button>
        </div>
      </div>
    </div>
  );
}
