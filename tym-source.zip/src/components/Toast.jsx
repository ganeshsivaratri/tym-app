// ==========================================
// FILE: src/components/Toast.jsx
// WHAT: The small message bar at the bottom
// ("Task deleted · Undo"). It reads the
// toast from the store and shows it.
// ==========================================
import React from 'react';
import { useAppStore } from '../store/AppStore.jsx';

export default function Toast() {
  const { toast, setToast } = useAppStore();
  if (!toast) return null;
  return (
    <div className="toast show" role="status">
      <span>{toast.message}</span>
      {toast.actionLabel && (
        <button className="toast-action" onClick={() => { toast.onAction && toast.onAction(); setToast(null); }}>
          {toast.actionLabel}
        </button>
      )}
    </div>
  );
}
