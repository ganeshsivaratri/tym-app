// ==========================================
// FILE: src/components/TaskCard.jsx
// WHAT: One task shown as a card.
// Used by Today, All, Board and more —
// build once, use everywhere (LEGO rule).
// Taps: tick = done · 📍 = pin to Top 3 ·
// ✏️ = edit · 🗑 = delete. Swipe works too:
// right = done, left = delete.
// ==========================================
import React, { useRef } from 'react';
import { useAppStore } from '../store/AppStore.jsx';
import { dueLabel } from '../utils/dates.js';
import { subtaskProgress } from '../utils/taskLogic.js';
import { mdRender } from '../utils/markdown.js';

const PRIORITY_TEXT = { high: 'High', med: 'Med', low: 'Low' };

export default function TaskCard({ task }) {
  const { data, actions, setEditingTask } = useAppStore();
  const touchStartX = useRef(null);

  const list = data.lists.find(l => l.id === task.listId);
  const progress = subtaskProgress(task);
  const isDone = task.status === 'done';
  const overdue = !isDone && task.due && task.due < new Date().toISOString().slice(0, 10) && !isToday(task.due);
  const dueText = task.due ? dueLabel(task.due, new Date()) : '';

  function onTouchStart(e) { touchStartX.current = e.touches[0].clientX; }
  function onTouchEnd(e) {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    touchStartX.current = null;
    if (dx > 80) actions.toggleTaskDone(task);
    else if (dx < -80) actions.deleteTask(task);
  }

  return (
    <div className={'task' + (isDone ? ' done' : '')} data-card={task.id}
      onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <input type="checkbox" className="check" checked={isDone}
        onChange={() => actions.toggleTaskDone(task)} aria-label="Mark done" />
      <div className="task-main">
        <div className="task-title">{task.title}</div>
        <div className="task-meta">
          {task.due && <span className={'pill due' + (overdue ? ' overdue' : '')}>📅 {dueText}{task.time ? ' · ' + task.time : ''}</span>}
          <span className={'pill prio-' + task.priority}>{PRIORITY_TEXT[task.priority] || 'Med'}</span>
          {list && <span className="pill"><span className="dot" style={{ background: list.color }}></span>{list.name}</span>}
          {task.repeat && task.repeat !== 'none' && <span className="pill">🔁 {task.repeat}</span>}
          {task.reminders && task.reminders.length > 0 && <span className="pill">🔔 ×{task.reminders.length}</span>}
          {task.estMinutes > 0 && <span className="pill">⏱ {task.estMinutes}m</span>}
          {(task.tags || []).map(tag => <span key={tag} className="pill">#{tag}</span>)}
          {task.attachments && task.attachments.length > 0 && <span className="pill">📎 {task.attachments.length}</span>}
        </div>
        {task.notes && <div className="task-notes" dangerouslySetInnerHTML={{ __html: mdRender(task.notes) }} />}
        {task.attachments && task.attachments.length > 0 && (
          <div className="att-row">
            {task.attachments.map((src, i) => <img key={i} className="att-img" src={src} alt="attachment" />)}
          </div>
        )}
        {task.subtasks && task.subtasks.length > 0 && (
          <div className="subs">
            <div className="sub-progress">{progress.done}/{progress.total} subtasks</div>
            {task.subtasks.map((sub, i) => (
              <label key={i} className={'sub' + (sub.done ? ' done' : '')} style={{ marginLeft: (sub.depth || 0) * 18 }}>
                <input type="checkbox" checked={!!sub.done}
                  onChange={() => actions.toggleSubtask(task, i)} /> {sub.title}
              </label>
            ))}
          </div>
        )}
      </div>
      <div className="task-actions">
        <button className={'icon-btn' + (task.focus ? ' pin-on' : '')} title="Pin to My Day (Top 3)"
          onClick={() => actions.toggleTaskPin(task)}>📌</button>
        <button className="icon-btn" title="Edit" onClick={() => setEditingTask(task)}>✏️</button>
        <button className="icon-btn" title="Delete" onClick={() => actions.deleteTask(task)}>🗑</button>
      </div>
    </div>
  );
}

function isToday(dateText) {
  const now = new Date();
  const today = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
  return dateText === today;
}
