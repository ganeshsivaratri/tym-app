#!/usr/bin/env python3
"""Build tym-app.html — the whole TYM app in ONE file.

Why: so the app can be opened straight from a chat attachment /
a phone browser without a server. The multi-file version in
this folder stays the source of truth; re-run this script
after any change to rebuild the single file.

How it works: CSS and shared JS are inlined. Each screen's JS
is wrapped in its own scope (so their `render` functions do
not collide) and registered with a small router that swaps
screens instead of loading new pages.
"""
import re, os

BASE = os.path.dirname(os.path.abspath(__file__))
def read(p): return open(os.path.join(BASE, p)).read()

SHARED = ['data.js','store.js','dates.js','tasks.js','site.js','md.js',
          'taskcard.js','editor.js','native.js','reminders.js','parse.js',
          'progress.js','plan.js']
SCREENS = ['today','all','calendar','board','matrix','timeline','habits',
           'focus','review','study','exams','timetable','completed','settings']

def wrap_screen(sid):
    src = read(f'assets/js/{sid}.js')
    if sid == 'all':
        src = src.replace('newTaskBtn', 'newTaskBtnAll')  # id clash with Today's button
    src = src.replace("document.addEventListener('DOMContentLoaded', render);",
                      f"__tymRegister('{sid}', render);")
    src = src.replace("document.addEventListener('DOMContentLoaded', () => {",
                      f"__tymInit('{sid}', () => {{")
    src = src.replace("document.addEventListener('tym:changed', render);", "")
    src = src.replace("document.addEventListener('tym:changed', () => { if (!fRunning) render(); });", "")
    src += f"\n__tymRegister('{sid}', render);\n"
    return f"<script>\n/* ===== screen: {sid} ===== */\n(function(){{\n{src}\n}})();\n</script>"

ROUTER_HEAD = """
<script>
/* ===== TYM single-file router (registry) =====
   This MUST come before the screen scripts: each screen
   registers its render/init functions here as it loads. */
window.__tymRenders = {};
window.__tymInits = {};
window.__tymInited = {};
window.__tymActive = 'today';
function __tymRegister(id, fn) { window.__tymRenders[id] = fn; }
function __tymInit(id, fn) { window.__tymInits[id] = fn; }
</script>
"""

ROUTER = """
<script>
/* ===== TYM single-file router (navigation) ===== */
const TYM_META = {
  today:    ['\\u2600\\uFE0F Today', ''],
  all:      ['\\uD83D\\uDDC2\\uFE0F All Tasks', 'Search, filter and reorder everything you have open.'],
  calendar: ['\\uD83D\\uDCC5 Calendar', 'Month view of your tasks — drag a task onto a day to move it.'],
  board:    ['\\uD83D\\uDCCB Board', 'Kanban columns — drag tasks from To do to Done.'],
  matrix:   ['\\uD83C\\uDFAF Matrix', 'Urgent x Important — the Eisenhower view.'],
  timeline: ['\\uD83D\\uDD50 Timeline', 'Your day, hour by hour — with Plan My Day.'],
  habits:   ['\\uD83D\\uDD25 Habits', 'Daily habits, streaks and morning routines.'],
  focus:    ['\\uD83C\\uDF45 Focus', 'Pomodoro timer tied to your current task.'],
  review:   ['\\uD83D\\uDCCA Review', 'Week graph, year heatmap and focus minutes.'],
  study:    ['\\uD83D\\uDCDA Study', 'Subjects and chapters, with progress per subject.'],
  exams:    ['\\u23F3 Exams', 'Countdowns and one-tap revision plans.'],
  timetable:['\\uD83C\\uDFEB Timetable', 'Your weekly class schedule.'],
  completed:['\\u2705 Completed', 'Everything you have finished. Well done.'],
  settings: ['\\u2699\\uFE0F Settings', 'Theme, lists, notifications, backup and imports.']
};
function tymActivate(id) {
  if (!TYM_META[id]) id = 'today';
  window.__tymActive = id;
  document.body.dataset.screen = id;
  buildSidebar(); buildBottomBar();
  document.getElementById('screenTitle').textContent = TYM_META[id][0];
  if (id !== 'today') document.getElementById('greetingLine').textContent = TYM_META[id][1];
  document.getElementById('quickBar').style.display = id === 'today' ? '' : 'none';
  document.getElementById('allToolbar').style.display = id === 'all' ? '' : 'none';
  if (window.__tymInits[id] && !window.__tymInited[id]) {
    window.__tymInited[id] = true; window.__tymInits[id]();
  } else if (window.__tymRenders[id]) {
    window.__tymRenders[id]();
  }
  window.scrollTo(0, 0);
}
document.addEventListener('click', e => {
  const go = e.target.closest('[data-goto]');
  if (go) {
    e.preventDefault(); e.stopPropagation();
    const s = TYM_SCREENS.find(x => x.file === go.dataset.goto);
    if (s) tymActivate(s.id);
    return;
  }
  const a = e.target.closest('#bottomBar a');
  if (a) {
    e.preventDefault();
    const s = TYM_SCREENS.find(x => a.getAttribute('href') === x.file);
    if (s) tymActivate(s.id);
  }
}, true);
document.addEventListener('tym:changed', () => {
  const r = window.__tymRenders[window.__tymActive];
  if (r) r();
});
document.addEventListener('DOMContentLoaded', () => tymActivate('today'));
</script>
"""

html = read('index.html')
# inline the stylesheet, drop external-only links
html = html.replace('<link rel="manifest" href="site.webmanifest">\n', '')
html = re.sub(r'<link rel="icon"[^>]*>\n', '', html)
html = html.replace('<link rel="stylesheet" href="assets/css/styles.css">',
                    '<style>\n' + read('assets/css/styles.css') + '\n</style>')
# title + ids for the router
html = html.replace('<h1>☀️ Today</h1>', '<h1 id="screenTitle">☀️ Today</h1>')
html = html.replace('<div class="quick">', '<div class="quick" id="quickBar">')
# All Tasks toolbar (from all.html), hidden unless that screen is active
all_main = re.search(r'<div class="toolbar">.*?<div id="screenContent"></div>',
                     read('all.html'), re.S).group(0)
all_toolbar = all_main.replace('<div id="screenContent"></div>', '') \
                      .replace('id="newTaskBtn"', 'id="newTaskBtnAll"')
html = html.replace('<div id="screenContent"></div>',
                    f'<div id="allToolbar" style="display:none">{all_toolbar}</div>\n    <div id="screenContent"></div>')
# drop every external script tag, then append the bundle
html = re.sub(r'<script src="assets/js/[^"]+"></script>\n?', '', html)
bundle = '\n'.join(f'<script>\n{read("assets/js/" + f)}\n</script>' for f in SHARED)
bundle += '\n' + ROUTER_HEAD + '\n'.join(wrap_screen(s) for s in SCREENS) + '\n' + ROUTER
html = html.replace('</body>', bundle + '\n</body>')
open(os.path.join(BASE, 'tym-app.html'), 'w').write(html)
print('tym-app.html built:', len(html), 'bytes')
